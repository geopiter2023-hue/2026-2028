import { useState, useEffect, useCallback } from 'react';

interface Session {
  id: string;
  userAgent: string;
  device: string;
  screen: string;
  entryTime: string;
  exitTime: string | null;
  duration: string;
}

function detectDevice(ua: string): string {
  if (/iPhone|iPod/.test(ua)) return 'iPhone';
  if (/iPad/.test(ua)) return 'iPad';
  if (/Android.*Mobile/.test(ua)) return 'Android Phone';
  if (/Android/.test(ua)) return 'Android Tablet';
  if (/Windows Phone/.test(ua)) return 'Windows Phone';
  if (/Macintosh|Mac OS/.test(ua)) return 'Mac';
  if (/Windows/.test(ua)) return 'Windows PC';
  if (/Linux/.test(ua)) return 'Linux';
  return 'Other';
}

function formatDuration(ms: number): string {
  if (ms < 0) return '—';
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  if (h > 0) return `${h}ч ${m % 60}м ${s % 60}с`;
  if (m > 0) return `${m}м ${s % 60}с`;
  return `${s}с`;
}

export function trackSession() {
  const STORAGE_KEY = 'sintec_analytics';
  const sessionId = Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
  const startTime = Date.now();

  const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  data.push({
    id: sessionId,
    userAgent: navigator.userAgent,
    device: detectDevice(navigator.userAgent),
    screen: `${window.screen.width}x${window.screen.height}`,
    entryTime: new Date().toISOString(),
    exitTime: null,
    duration: null,
  });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));

  window.addEventListener('beforeunload', () => {
    const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    const session = all.find((s: Session) => s.id === sessionId);
    if (session) {
      session.exitTime = new Date().toISOString();
      session.duration = formatDuration(Date.now() - startTime);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
    }
  });
}

export default function HiddenAdmin() {
  const [showLogin, setShowLogin] = useState(false);
  const [password, setPassword] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [sessions, setSessions] = useState<Session[]>([]);

  const loadData = useCallback(() => {
    const data = JSON.parse(localStorage.getItem('sintec_analytics') || '[]');
    const now = Date.now();
    data.forEach((s: Session) => {
      if (!s.exitTime && s.entryTime) {
        const elapsed = now - new Date(s.entryTime).getTime();
        s.duration = formatDuration(elapsed);
      }
    });
    setSessions(data.reverse());
  }, []);

  useEffect(() => {
    if (isAuthenticated) loadData();
  }, [isAuthenticated, loadData]);

  useEffect(() => {
    const interval = setInterval(() => {
      if (isAuthenticated) loadData();
    }, 5000);
    return () => clearInterval(interval);
  }, [isAuthenticated, loadData]);

  const handleLogin = () => {
    if (password === '1987') {
      setIsAuthenticated(true);
      setShowLogin(false);
      loadData();
    } else {
      setPassword('');
    }
  };

  const clearData = () => {
    if (window.confirm('Удалить все данные аналитики?')) {
      localStorage.removeItem('sintec_analytics');
      setSessions([]);
    }
  };

  const handleClose = () => {
    setIsAuthenticated(false);
    setPassword('');
  };

  if (isAuthenticated) {
    return (
      <div className="fixed inset-0 z-[9999] bg-black/80 flex items-start justify-center overflow-y-auto py-8">
        <div className="bg-white w-full max-w-[800px] mx-4 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-oswald font-bold text-2xl text-black uppercase">Аналитика посещений</h2>
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-400">{sessions.length} сессий</span>
              <button onClick={loadData} className="px-3 py-1 bg-blue-900 text-white text-xs font-medium">Обновить</button>
              <button onClick={clearData} className="px-3 py-1 bg-red-600 text-white text-xs font-medium">Очистить</button>
              <button onClick={handleClose} className="px-3 py-1 bg-gray-200 text-black text-xs font-medium">Закрыть</button>
            </div>
          </div>

          {sessions.length === 0 ? (
            <p className="text-gray-400 text-center py-8">Пока нет данных о посещениях</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="p-2 text-left font-medium text-gray-500">#</th>
                    <th className="p-2 text-left font-medium text-gray-500">Устройство</th>
                    <th className="p-2 text-left font-medium text-gray-500">Экран</th>
                    <th className="p-2 text-left font-medium text-gray-500">Вход</th>
                    <th className="p-2 text-left font-medium text-gray-500">Выход</th>
                    <th className="p-2 text-left font-medium text-gray-500">Время на сайте</th>
                    <th className="p-2 text-left font-medium text-gray-500">User-Agent</th>
                  </tr>
                </thead>
                <tbody>
                  {sessions.map((s, i) => (
                    <tr key={s.id} className="border-t border-gray-100">
                      <td className="p-2 text-gray-400">{sessions.length - i}</td>
                      <td className="p-2">
                        <span className="px-2 py-0.5 bg-blue-50 text-blue-800 font-medium">{s.device}</span>
                      </td>
                      <td className="p-2 text-gray-600">{s.screen}</td>
                      <td className="p-2 text-gray-600">{new Date(s.entryTime).toLocaleTimeString('ru-RU')}</td>
                      <td className="p-2 text-gray-600">{s.exitTime ? new Date(s.exitTime).toLocaleTimeString('ru-RU') : 'Онлайн'}</td>
                      <td className="p-2">
                        <span className={!s.exitTime ? 'text-green-600 font-medium' : 'text-gray-600'}>{s.duration}</span>
                      </td>
                      <td className="p-2 text-gray-400 max-w-[200px] truncate" title={s.userAgent}>{s.userAgent}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Admin trigger button */}
      <button
        onClick={() => setShowLogin(true)}
        className="fixed bottom-4 right-4 w-10 h-10 bg-gray-800 hover:bg-red-600 text-white rounded-full flex items-center justify-center shadow-lg z-[9998] transition-all duration-300 hover:scale-110"
        title="Админ-панель"
      >
        <span className="text-sm">&#x2699;</span>
      </button>

      {/* Password modal */}
      {showLogin && (
        <div className="fixed inset-0 z-[9999] bg-black/60 flex items-center justify-center">
          <div className="bg-white p-6 w-[280px]">
            <h3 className="font-oswald font-bold text-lg text-black uppercase mb-4 text-center">Вход</h3>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
              placeholder="Пароль"
              className="w-full p-2 border border-gray-300 text-sm mb-4 focus:outline-none focus:border-red-500"
              autoFocus
            />
            <div className="flex gap-2">
              <button
                onClick={handleLogin}
                className="flex-1 p-2 bg-red-600 text-white text-sm font-medium"
              >
                Войти
              </button>
              <button
                onClick={() => { setShowLogin(false); setPassword(''); }}
                className="flex-1 p-2 bg-gray-200 text-black text-sm"
              >
                Отмена
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
