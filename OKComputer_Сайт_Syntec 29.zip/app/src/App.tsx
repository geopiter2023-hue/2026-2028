import { useEffect } from 'react';
import Home from './pages/Home';
import HiddenAdmin, { trackSession } from './components/HiddenAdmin';
import PasswordGate from './components/PasswordGate';

export default function App() {
  useEffect(() => {
    trackSession().catch(() => {});
  }, []);

  return (
    <PasswordGate>
      <Home />
      <HiddenAdmin />
    </PasswordGate>
  );
}
