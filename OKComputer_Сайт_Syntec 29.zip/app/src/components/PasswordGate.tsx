import { useState, useEffect } from 'react';

const VALID_PASSWORDS = ['7771', '7773', '0334'];
const STORAGE_KEY = 'sintec_auth';

export default function PasswordGate({ children }: { children: React.ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [shake, setShake] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored === '1') {
      setIsAuthenticated(true);
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (VALID_PASSWORDS.includes(password)) {
      localStorage.setItem(STORAGE_KEY, '1');
      setIsAuthenticated(true);
    } else {
      setError('Неверный пароль. Попробуйте снова.');
      setShake(true);
      setTimeout(() => setShake(false), 400);
      setPassword('');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem(STORAGE_KEY);
    setIsAuthenticated(false);
    setPassword('');
    setError('');
  };

  if (isAuthenticated) {
    return (
      <>
        {children}
        {/* Logout button - fixed bottom right */}
        <button
          onClick={handleLogout}
          className="fixed bottom-4 right-4 z-[9999] px-3 py-1.5 bg-gray-800/80 text-white text-[10px] font-bold uppercase tracking-wider hover:bg-red-600 transition-colors"
          title="Выйти из системы"
        >
          &#x2715; ВЫХОД
        </button>
      </>
    );
  }

  return (
    <div className="fixed inset-0 z-[10000] bg-black flex items-center justify-center">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5" style={{
        backgroundImage: `repeating-linear-gradient(45deg, #CC0000 0, #CC0000 1px, transparent 0, transparent 50%)`,
        backgroundSize: '20px 20px'
      }} />

      <div className={`relative w-full max-w-sm mx-4 ${shake ? 'animate-shake' : ''}`}>
        {/* Card */}
        <div className="bg-white p-8 shadow-2xl">
          {/* Logo area */}
          <div className="text-center mb-6">
            <div className="inline-block px-4 py-1.5 border border-red-200 bg-red-50 mb-4">
              <span className="text-xs font-medium text-red-600 uppercase tracking-widest">SINTEC 2027</span>
            </div>
            <h1 className="font-oswald font-bold text-2xl text-black uppercase tracking-wide">
              СТРАТЕГИЧЕСКИЙ ПОРТАЛ
            </h1>
            <p className="text-xs text-gray-400 mt-2">
              Доступ ограничен. Введите пароль.
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <input
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError('');
                }}
                placeholder="Введите пароль"
                maxLength={10}
                className="w-full px-4 py-3 border border-gray-300 text-center text-lg font-mono tracking-[0.3em] text-black placeholder:text-gray-300 placeholder:tracking-normal placeholder:text-sm focus:outline-none focus:border-red-600 transition-colors"
                autoFocus
              />
            </div>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 text-xs text-red-600 text-center">
                {error}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3 bg-red-600 text-white font-oswald font-bold text-sm uppercase tracking-wider hover:bg-red-700 transition-colors"
            >
              ВОЙТИ
            </button>
          </form>

          {/* Hint */}
          <div className="mt-6 pt-4 border-t border-gray-100 text-center">
            <p className="text-[10px] text-gray-400">
              Если у вас нет пароля — обратитесь к администратору
            </p>
          </div>
        </div>

        {/* Red accent bar */}
        <div className="h-1 bg-red-600" />
      </div>

      {/* Shake animation */}
      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-8px); }
          50% { transform: translateX(8px); }
          75% { transform: translateX(-4px); }
        }
        .animate-shake {
          animation: shake 0.35s ease-in-out;
        }
      `}</style>
    </div>
  );
}
