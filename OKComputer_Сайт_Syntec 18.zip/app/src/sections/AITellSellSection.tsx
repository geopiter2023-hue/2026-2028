const capabilities = [
  { num: '01', text: 'Переговоры с клиентами' },
  { num: '02', text: 'Работа с возражениями' },
  { num: '03', text: 'Презентация продукта' },
  { num: '04', text: 'Закрытие сделки' },
  { num: '05', text: 'Продуктовая консультация' },
  { num: '06', text: 'Управление командой' },
  { num: '07', text: 'Анализ эффективности' },
  { num: '08', text: 'Развитие навыков' },
  { num: '09', text: 'Построение доверия' },
  { num: '10', text: 'Влияние на решения' },
  { num: '11', text: 'Адаптация стиля' },
  { num: '12', text: 'Постоянная практика' },
];

export default function AITellSellSection() {
  return (
    <section className="py-16 px-4 bg-gradient-to-br from-red-600 via-red-700 to-red-900">
      <div className="max-w-[900px] mx-auto">
        {/* Logo centered */}
        <div className="flex justify-center mb-8">
          <div className="w-24 h-24 lg:w-32 lg:h-32 bg-white rounded-full flex items-center justify-center shadow-2xl border-4 border-white/20">
            <div className="text-center">
              <span className="font-oswald font-bold text-red-600 text-2xl lg:text-3xl block leading-none">SIN</span>
              <span className="font-oswald font-bold text-red-600 text-2xl lg:text-3xl block leading-none">TEC</span>
            </div>
          </div>
        </div>

        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 bg-white/10 border border-white/20">
            <span className="text-xs font-medium text-white uppercase tracking-widest">&#x1F916; AI Тренажёр</span>
          </div>
          <h2 className="font-oswald font-bold text-3xl lg:text-4xl text-white mb-2">TELLSELL</h2>
          <p className="text-sm text-white/70 max-w-lg mx-auto">AI-симулятор переговоров для постоянного развития сотрудников</p>
        </div>

        {/* Matrix grid */}
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 mb-8">
          {capabilities.map((c, i) => (
            <div
              key={i}
              className="group p-4 bg-white/10 border border-white/20 hover:bg-white/20 transition-all cursor-default"
            >
              <div className="flex items-start gap-3">
                <span className="font-oswald font-bold text-white/40 text-sm">{c.num}</span>
                <span className="text-white text-sm font-medium group-hover:text-white transition-colors">
                  {c.text}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom stats */}
        <div className="grid grid-cols-3 gap-3 max-w-[400px] mx-auto">
          {[
            { val: '12', label: 'Сценариев' },
            { val: '24/7', label: 'Доступ' },
            { val: '100%', label: 'Охват' },
          ].map((s, i) => (
            <div key={i} className="p-3 bg-white/10 border border-white/20 text-center">
              <span className="font-oswald font-bold text-xl text-white">{s.val}</span>
              <p className="text-[10px] text-white/50 uppercase tracking-wider mt-1">{s.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
