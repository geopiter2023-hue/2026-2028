import Navigation from '../components/Navigation';
import HeroSection from '../sections/HeroSection';
import B2CSection from '../sections/B2CSection';
import B2CToolsSection from '../sections/B2CToolsSection';
import B2CAnalyticsSection from '../sections/B2CAnalyticsSection';
import B2CControlSection from '../sections/B2CControlSection';
import B2CMarketSection from '../sections/B2CMarketSection';
import TrainersSection from '../sections/TrainersSection';
// import B2BSection from '../sections/B2BSection';
// import CTOSection from '../sections/CTOSection';
import OnlineSection from '../sections/OnlineSection';
// import NetworksSection from '../sections/NetworksSection';
// import ExportSection from '../sections/ExportSection';
import DistributorSection from '../sections/DistributorSection';
import BrandsSection from '../sections/BrandsSection';
import BrandStoresSection from '../sections/BrandStoresSection';
// import StatsSection from '../sections/StatsSection';
import ValuesSection from '../sections/ValuesSection';
import AITellSellSection from '../sections/AITellSellSection';
import FooterSection from '../sections/FooterSection';
import TransitionLine from '../components/TransitionLine';

export default function Home() {
  return (
    <div className="relative bg-white min-h-screen">
      <Navigation />
      <HeroSection />
      <B2CSection />
      <B2CToolsSection />
      <B2CAnalyticsSection />
      <B2CControlSection />
      <B2CMarketSection />
      <TrainersSection />
      {/* B2B, CTO, Networks, Export temporarily hidden */}
      <OnlineSection />
      <TransitionLine color="#cc5200" />
      <DistributorSection />
      <TransitionLine color="#9933cc" />
      <BrandsSection />
      <BrandStoresSection />
      <TransitionLine color="#FF0000" />
      {/* <StatsSection /> */}
      <AITellSellSection />
      <ValuesSection />
      <FooterSection />
    </div>
  );
}
