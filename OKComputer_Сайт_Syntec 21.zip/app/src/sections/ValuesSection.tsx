const values = [
  { word: 'РАЗВИТИЕ', size: 'text-xl', color: 'text-red-600', weight: 'font-bold' },
  { word: 'СТРАТЕГИЯ', size: 'text-sm', color: 'text-gray-400', weight: 'font-normal' },
  { word: 'ЦЕЛИ', size: 'text-lg', color: 'text-black', weight: 'font-bold' },
  { word: 'ЭФФЕКТИВНОСТЬ', size: 'text-base', color: 'text-red-600', weight: 'font-bold' },
  { word: 'ЛИДЕРСТВО', size: 'text-xl', color: 'text-red-700', weight: 'font-bold' },
  { word: 'ИНФОРМАТИВНОСТЬ', size: 'text-xs', color: 'text-gray-400', weight: 'font-normal' },
  { word: 'СПЛОЧЁННОСТЬ', size: 'text-sm', color: 'text-red-500', weight: 'font-semibold' },
  { word: 'ОТВЕТСТВЕННОСТЬ', size: 'text-base', color: 'text-black', weight: 'font-bold' },
  { word: 'ТЕХНОЛОГИИ', size: 'text-xs', color: 'text-gray-400', weight: 'font-normal' },
  { word: 'КАЧЕСТВО', size: 'text-sm', color: 'text-red-600', weight: 'font-bold' },
  { word: 'СМЕЛОСТЬ', size: 'text-sm', color: 'text-gray-500', weight: 'font-normal' },
  { word: 'НАУКА', size: 'text-xs', color: 'text-gray-400', weight: 'font-normal' },
  { word: 'ЭКОЛОГИЯ', size: 'text-xs', color: 'text-gray-400', weight: 'font-normal' },
  { word: 'РЕЗУЛЬТАТ', size: 'text-3xl', color: 'text-black', weight: 'font-bold' },
  { word: 'РЕСУРСЫ', size: 'text-xs', color: 'text-gray-400', weight: 'font-normal' },
  { word: 'УСПЕХ', size: 'text-sm', color: 'text-gray-500', weight: 'font-normal' },
  { word: 'ЧЕСТНОСТЬ', size: 'text-lg', color: 'text-red-600', weight: 'font-bold' },
  { word: 'ТВОРЧЕСТВО', size: 'text-sm', color: 'text-gray-500', weight: 'font-normal' },
  { word: 'ОТКРЫТОСТЬ', size: 'text-base', color: 'text-red-500', weight: 'font-semibold' },
  { word: 'СПРАВЕДЛИВОСТЬ', size: 'text-sm', color: 'text-gray-400', weight: 'font-normal' },
  { word: 'ПАРТНЁРСТВО', size: 'text-lg', color: 'text-red-700', weight: 'font-bold' },
  { word: 'БЕЗОПАСНОСТЬ', size: 'text-sm', color: 'text-gray-400', weight: 'font-normal' },
  { word: 'КОМАНДА', size: 'text-3xl', color: 'text-red-600', weight: 'font-bold' },
  { word: 'ЛЮБОВЬ К БРЕНДУ', size: 'text-base', color: 'text-red-500', weight: 'font-bold' },
  { word: 'БРЕНД', size: 'text-xl', color: 'text-black', weight: 'font-bold' },
  { word: 'РОСТ', size: 'text-2xl', color: 'text-red-600', weight: 'font-bold' },
  { word: 'СОВЕРШЕНСТВО В КАЖДОМ ШАГЕ', size: 'text-sm', color: 'text-red-600', weight: 'font-bold' },
  { word: 'ГИБКОСТЬ', size: 'text-base', color: 'text-gray-500', weight: 'font-normal' },
  { word: 'УВЕРЕННОСТЬ', size: 'text-lg', color: 'text-red-500', weight: 'font-semibold' },
  { word: 'ПОДДЕРЖКА', size: 'text-base', color: 'text-gray-600', weight: 'font-medium' },
];

export default function ValuesSection() {
  return (
    <section className="py-16 px-4 bg-white">
      <div className="max-w-[900px] mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 border border-red-200 bg-red-50">
            <span className="text-xs font-medium text-red-600 uppercase tracking-widest">&#x2764; Ценности</span>
          </div>
          <h2 className="font-oswald font-bold text-3xl lg:text-4xl text-black mb-2">ЦЕННОСТИ</h2>
          <p className="text-sm text-gray-500">То, что помогает нам расти, развиваться и любить бренд</p>
        </div>

        {/* Word cloud wall */}
        <div className="p-8 lg:p-12 bg-gray-50 border border-gray-200">
          {/* Word cloud */}
          <div className="flex flex-wrap items-baseline justify-center gap-x-3 gap-y-2 lg:gap-x-4 lg:gap-y-3">
            {values.map((v, i) => (
              <span
                key={i}
                className={`${v.size} ${v.color} ${v.weight} whitespace-nowrap hover:text-red-600 transition-colors cursor-default`}
              >
                {v.word}
              </span>
            ))}
          </div>
        </div>

        {/* Bottom tags */}
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          {[
            'Рост через развитие',
            'Любовь к бренду',
            'Команда — основа успеха',
            'Результат в каждом действии',
          ].map((tag, i) => (
            <span key={i} className="px-3 py-1 bg-red-50 border border-red-200 text-red-600 text-xs font-medium">
              {tag}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
