const tools = [
  {
    num: '01',
    emoji: '\u{1F5FA}',
    title: 'Чёткие границы территории',
    color: '#CC0000',
    details: [
      'Каждый торговый представитель закреплён за конкретным районом с фиксированным списком торговых точек',
      'В CRM системе отображается маршрут визитов с GPS-координатами каждой точки',
      'Территориальный менеджер контролирует охват: ни одна точка не пропущена',
      'При расширении региона происходит перераспределение точек между ТП',
    ],
  },
  {
    num: '02',
    emoji: '\u{1F4CA}',
    title: 'Ежедневная прозрачная отчётность',
    color: '#8B3A00',
    details: [
      'ТП заполняет отчёт по каждому визиту: время, результат, заказ, фото выкладки',
      'Менеджер видит отчёты в реальном времени — контроль качества визитов',
      'Фотоотчёты мерчендайзинга — подтверждение правильной выкладки по шахматке',
      'Автоматические дашборды: выполнение плана, охват территории, конверсия визитов в заказы',
    ],
  },
  {
    num: '03',
    emoji: '\u{1F3C6}',
    title: 'Статус выполнения KPI',
    color: '#005f7f',
    details: [
      'Каждый сотрудник видит свой личный KPI в личном кабинете: объём, план, процент выполнения',
      'Рейтинговая таблица — позиция среди всех сотрудников отдела по эффективности',
      'Система автоматически рассчитывает прогноз выполнения плана на основе текущей динамики',
      'Руководитель получает сводку по всей команде: кто выполняет, кто отстаёт',
    ],
  },
  {
    num: '04',
    emoji: '\u{1F4CB}',
    title: 'Задачи на каждого клиента',
    color: '#5c6b00',
    details: [
      'CRM автоматически генерирует задачи для каждой торговой точки на основе сегмента и истории',
      'Задачи разбиты на конкретные визиты: визит 1 — презентация новинки, визит 2 — контроль выкладки',
      'ТП видит список задач на день перед выездом на территорию',
      'После выполнения задачи отмечаются в системе — формируется история развития точки',
    ],
  },
  {
    num: '05',
    emoji: '\u{1F4E6}',
    title: 'Маркетинговая поддержка',
    color: '#6b238f',
    details: [
      'ТП получает доступ к библиотеке промо-материалов: каталоги, пробники, плакаты',
      'Актуальные акции и спецпредложения для торговых точек — информация в мобильном приложении',
      'POS-материалы: стенды, ценники, дисплеи для правильной выкладки',
      'Маркетинговый календарь — план промо-активностей на месяц с материалами для каждой точки',
    ],
  },
];

export default function B2CToolsSection() {
  return (
    <section className="py-16 px-4 bg-gray-50">
      <div className="max-w-[1000px] mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 border border-red-200 bg-red-50">
            <span className="text-xs font-medium text-red-600 uppercase tracking-widest">&#x1F6E0; Рабочие инструменты</span>
          </div>
          <h2 className="font-oswald font-bold text-3xl lg:text-4xl text-black mb-2">ИНСТРУМЕНТЫ B2C</h2>
          <p className="text-sm text-gray-500 max-w-lg mx-auto">Для территориальных менеджеров и торговых представителей</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {tools.map((t, i) => (
            <details key={i} className={`group border border-gray-200 bg-white cursor-pointer ${i === 0 || i === 3 ? 'lg:col-span-2' : ''}`}>
              <summary className="flex items-center gap-3 p-4 list-none">
                <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center font-oswald font-bold text-white text-sm" style={{ backgroundColor: t.color }}>
                  {t.num}
                </div>
                <span className="text-xl flex-shrink-0">{t.emoji}</span>
                <h4 className="font-oswald font-bold text-sm text-black uppercase flex-1">{t.title}</h4>
                <span className="text-gray-400 group-open:rotate-180 transition-transform text-sm">&#x25BC;</span>
              </summary>
              <div className="px-4 pb-4">
                <div className="h-px w-full bg-gray-200 mb-3 ml-16" />
                <ul className="space-y-2 ml-16">
                  {t.details.map((d, j) => (
                    <li key={j} className="flex items-start gap-2 text-sm text-gray-600">
                      <span style={{ color: t.color }}>&#x2714;</span>
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}
