export default function HeroSection() {
  return (
    <section className="relative h-screen w-full flex items-center justify-center bg-white">
      <div className="absolute inset-0 bg-gradient-to-b from-gray-50 via-white to-gray-50" />
      <div className="relative z-10 text-center px-4">
        <div className="inline-flex items-center gap-2 px-6 py-2 mb-8 rounded-full border border-red-300 bg-red-50">
          <img src="/images/sintec-logo.jpg" alt="SINTEC" className="h-5 w-auto" />
          <span className="text-xs font-medium text-red-600 uppercase tracking-widest">SINTEC</span>
        </div>
        <h1 className="font-oswald font-bold text-black leading-[0.9] tracking-tight mb-4" style={{ fontSize: 'clamp(40px, 11vw, 160px)' }}>
          B2B EXCELLENCE
        </h1>
        <p className="text-lg text-gray-500 mb-2 tracking-wide">Стратегия продаж</p>
        <p className="font-oswald font-bold text-2xl lg:text-3xl text-red-600 mb-10 tracking-wider">2026 — 2028</p>
        <a href="#b2c" className="inline-flex items-center justify-center w-12 h-12 rounded-full border border-red-300 text-red-600 hover:bg-red-600 hover:text-white transition-all duration-300">&#x2193;</a>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-white to-transparent" />
    </section>
  );
}
