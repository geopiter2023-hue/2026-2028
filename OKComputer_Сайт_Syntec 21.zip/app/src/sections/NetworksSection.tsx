import { useState } from 'react';
import KPIModal from '../components/KPIModal';

const modules = [
  {
    num: '01',
    emoji: '\u{1F3EC}',
    title: 'Локальные сети',
    color: '#6b2c91',
    details: [
      'Работа с региональными торговыми сетями: заключение договоров, согласование условий, ведение отношений',
      'Листинг SKU: согласование ассортимента SINTEC, TAKAYAMA, MIRAX, ROLF, Автокосметика SINTEC для каждой локальной сети',
      'Контроль доли полки: регулярный аудит полочного пространства — целевой показатель не ниже контрактного',
      'Соблюдение контрактных условий: проверка соблюдения согласованных цен, выкладки, промо-активностей',
      'Развитие партнёрства: ежемесячные встречи, пересмотр условий, расширение ассортимента в рамках локальных сетей',
    ],
  },
  {
    num: '02',
    emoji: '\u{1F3ED}',
    title: 'Национальные сети',
    color: '#7b3399',
    details: [
      'Работа с федеральными торговыми сетями: переговоры на центральном уровне, согласование национальных контрактов',
      'Национальный листинг SKU: согласование полного продуктового портфеля для размещения во всех магазинах сети',
      'Централизованные заказы: работа с центральным офисом сети, согласование объёмов, сроков поставок',
      'Национальные промо-кампании: согласование акций, механик, рекламных материалов на уровне всей сети',
      'Отчётность перед руководством сети: ежеквартальные бизнес-ревью с ключевыми показателями эффективности',
    ],
  },
  {
    num: '03',
    emoji: '\u{1F4F1}',
    title: 'Агрегаторы',
    color: '#8b3aa7',
    details: [
      'Работа с клиентами-агрегаторами: переговоры, согласование условий сотрудничества, листинг SKU',
      'Техническая интеграция: подключение к API агрегатора, настройка обмена данными по остаткам и ценам',
      'Контроль представленности: мониторинг наличия всех брендов SINTEC на платформе агрегатора',
      'Промо на платформах: согласование акций, баннеров, спецпредложений в рамках агрегаторских площадок',
      'Аналитика продаж через агрегаторов: отслеживание динамики, выявление топ-SKU, оптимизация ассортимента',
    ],
  },
  {
    num: '04',
    emoji: '\u{1F4CB}',
    title: 'Переговоры & Согласование',
    color: '#9b41b5',
    details: [
      'Ведение переговоров с ключевыми клиентами: подготовка коммерческих предложений, презентаций, бизнес-планов',
      'Согласование контрактов: цены, объёмы, условия поставок, маркетинговая поддержка, эксклюзивные условия',
      'Работа с возражениями: ценовые дискуссии, конкурентное давление, изменение условий со стороны сетей',
      'Внутренняя координация: согласование условий с логистикой, маркетингом, финансами перед подписанием контракта',
      'Юридическое сопровождение: работа с юристами по договорам, дополнительным соглашениям, претензиям',
    ],
  },
  {
    num: '05',
    emoji: '\u{1F3AF}',
    title: 'KPI отдела Сети',
    color: '#ab48c3',
    details: [
      'Доля полки: процент полочного пространства, занимаемого брендами SINTEC — целевой показатель по каждой сети',
      'Соблюдение контрактных условий: процент выполнения всех пунктов контракта — целевой показатель 95%+',
      'Уровень соблюдений: общий индекс выполнения обязательств со стороны сети и со стороны SINTEC',
      'Листинг SKU: процент согласованного ассортимента, фактически представленного на полках — целевой показатель 90%+',
      'Рост выручки: ежемесячный прирост продаж через сетевой канал не менее 10%',
    ],
  },
];

const roles = [
  {
    title: 'Директор по Сетям',
    count: '1',
    subtitle: 'Управление сетевым направлением',
    key: 'manager',
    details: [
      'Стратегия развития сетевого канала',
      'Управление командой из 9 менеджеров',
      'Ключевые переговоры с национальными сетями',
      'Контроль KPI по всем направлениям',
    ],
  },
  {
    title: 'Менеджеры по сетям',
    count: '9',
    subtitle: 'Локальные, национальные, агрегаторы — Офис, Москва',
    key: 'manager',
    details: [
      '9 менеджеров работают в офисе в Москве',
      'Локальные сети, национальные сети, агрегаторы',
      'Переговоры, согласование, листинг SKU',
      'Контроль доли полки и контрактных условий',
    ],
  },
];

export default function NetworksSection() {
  const [activeRole, setActiveRole] = useState<string | null>(null);
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section id="networks" className="py-16 px-4 bg-white">
      <div className="max-w-[900px] mx-auto">
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 border border-purple-200 bg-purple-50">
            <span className="text-xs font-medium text-purple-700 uppercase tracking-widest">&#x1F4E1; Сети</span>
          </div>
          <h2 className="font-oswald font-bold text-3xl lg:text-4xl text-black mb-2">СЕТИ</h2>
          <p className="text-sm text-gray-500 max-w-lg mx-auto mb-2">Локальные и национальные сети, агрегаторы</p>
          <p className="text-sm text-gray-400">Переговоры, согласование условий, листинг SKU</p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 mb-8 max-w-[500px] mx-auto">
          {[
            { val: '10', label: 'Сотрудников отдела', color: '#6b2c91' },
            { val: '100%', label: 'Офисная работа', color: '#7b3399' },
            { val: 'Москва', label: 'Клиентские офисы', color: '#6b2c91' },
          ].map((s, i) => (
            <div key={i} className="p-3 border border-gray-200 bg-gray-50 text-center">
              <span className="font-oswald font-bold text-2xl" style={{ color: s.color }}>{s.val}</span>
              <p className="text-[10px] text-gray-400 uppercase tracking-wider mt-1">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="h-px w-full bg-purple-200 mb-6" />

        <div className="flex items-center gap-3 mb-4 p-3 border border-gray-200 bg-gray-50 max-w-[500px] mx-auto">
          <span className="text-2xl">&#x1F3EC;</span>
          <div>
            <h3 className="font-oswald font-bold text-sm text-black uppercase">ОТДЕЛ ПО СЕТЯМ</h3>
            <p className="text-xs text-gray-400">Директор по Сетям Россия</p>
          </div>
          <div className="ml-auto text-right">
            <span className="font-oswald font-bold text-xl text-purple-700">10</span>
            <p className="text-[10px] text-gray-400 uppercase">человек</p>
          </div>
        </div>

        {/* Roles with KPI */}
        <div className="space-y-2 mb-8">
          {roles.map((r, i) => (
            <details
              key={i}
              className="group border border-gray-200 bg-gray-50/50 cursor-pointer"
              open={openIndex === i}
              onClick={(e) => { e.preventDefault(); setOpenIndex(openIndex === i ? null : i); }}
            >
              <summary className="flex items-center justify-between p-3 list-none">
                <div className="flex items-center gap-3">
                  <span className="font-oswald font-bold text-lg text-purple-700">{r.count}</span>
                  <div>
                    <h4 className="font-semibold text-sm text-black">{r.title}</h4>
                    <p className="text-xs text-gray-400">{r.subtitle}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {r.key && (
                    <button
                      onClick={(e) => { e.stopPropagation(); setActiveRole(r.key!); }}
                      className="px-2 py-1 bg-red-600 text-white text-[10px] font-bold uppercase hover:bg-red-700 transition-colors"
                    >
                      KPI
                    </button>
                  )}
                  <span className="text-gray-400 group-open:rotate-180 transition-transform text-xs">&#x25BC;</span>
                </div>
              </summary>
              <div className="px-3 pb-3 pt-0">
                <div className="h-px w-full bg-gray-200 mb-2 ml-12" />
                <ul className="space-y-1 ml-12">
                  {r.details.map((d, j) => (
                    <li key={j} className="flex items-start gap-2 text-xs text-gray-600">
                      <span className="text-purple-600">&#x2714;</span>
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </details>
          ))}
        </div>

        <div className="h-px w-full bg-purple-200 mb-6" />

        {/* Modules accordion */}
        <div className="space-y-3">
          {modules.map((m, i) => (
            <details key={i} className="group border border-gray-200 bg-gray-50 cursor-pointer">
              <summary className="flex items-center gap-3 p-4 list-none">
                <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center font-oswald font-bold text-white text-sm" style={{ backgroundColor: m.color }}>
                  {m.num}
                </div>
                <span className="text-2xl flex-shrink-0">{m.emoji}</span>
                <h3 className="font-oswald font-bold text-base text-black uppercase flex-1">{m.title}</h3>
                <span className="text-gray-400 group-open:rotate-180 transition-transform text-sm">&#x25BC;</span>
              </summary>
              <div className="px-4 pb-4">
                <div className="h-px w-full bg-gray-200 mb-3 ml-16" />
                <ul className="space-y-2 ml-16">
                  {m.details.map((d, j) => (
                    <li key={j} className="flex items-start gap-2 text-sm text-gray-600">
                      <span style={{ color: m.color }}>&#x2714;</span>
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </details>
          ))}
        </div>

        <div className="mt-8 p-4 bg-purple-50 border border-purple-200 rounded-lg text-center">
          <p className="text-sm text-gray-700">
            <span className="font-semibold text-purple-700">KPI отдела:</span> Доля полки &nbsp;|&nbsp; Соблюдение контрактных условий &nbsp;|&nbsp; Уровень соблюдений &nbsp;|&nbsp; Листинг SKU 90%+
          </p>
        </div>
      </div>

      <KPIModal dept="networks" roleKey={activeRole} onClose={() => setActiveRole(null)} />
    </section>
  );
}
