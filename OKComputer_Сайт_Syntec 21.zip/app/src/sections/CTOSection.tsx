import { useState } from 'react';
import KPIModal from '../components/KPIModal';

const roles = [
  {
    title: 'Региональные менеджеры СТО',
    count: '9',
    subtitle: 'Управление сетью СТО по 9 регионам',
    key: 'rd',
    details: [
      '9 региональных менеджеров покрывают всю сеть СТО по регионам России',
      'Каждый РМ управляет командой КАМ СТО в своём регионе',
      'Ответственность за выполнение плана продаж в сегменте СТО',
      'Контроль качества обслуживания и технической поддержки',
    ],
  },
  {
    title: 'КАМ СТО',
    count: '60',
    subtitle: 'Ключевые аккаунт-менеджеры станций техобслуживания',
    key: 'mp',
    details: [
      '60 КАМ СТО работают с закреплёнными станциями ежедневно',
      'Визиты в СТО: консультация, обучение, заключение договоров',
      'Контроль ассортимента и наличия продукции SINTEC на СТО',
      'Сбор заказов и координация поставок для качественной работы',
    ],
  },
];

export default function CTOSection() {
  const [activeRole, setActiveRole] = useState<string | null>(null);
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section id="cto" className="py-16 px-4 bg-white">
      <div className="max-w-[900px] mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 border border-blue-200 bg-blue-50">
            <span className="text-xs font-medium text-blue-700 uppercase tracking-widest">&#x1F527; СТО</span>
          </div>
          <h2 className="font-oswald font-bold text-3xl lg:text-4xl text-black mb-2">41 000+ СТО</h2>
          <p className="text-sm text-gray-500 max-w-lg mx-auto">Станции технического обслуживания по всей России</p>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 mb-8 max-w-[500px] mx-auto">
          {[
            { val: '69', label: 'Сотрудников отдела', color: '#1a2744' },
            { val: '9', label: 'Региональных менеджеров', color: '#243352' },
            { val: '60', label: 'КАМ СТО', color: '#1a2744' },
          ].map((s, i) => (
            <div key={i} className="p-3 border border-gray-200 bg-gray-50 text-center">
              <span className="font-oswald font-bold text-2xl" style={{ color: s.color }}>{s.val}</span>
              <p className="text-[10px] text-gray-400 uppercase tracking-wider mt-1">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="h-px w-full bg-blue-200 mb-6" />

        {/* Team */}
        <div className="flex items-center gap-3 mb-4 p-3 border border-gray-200 bg-gray-50 max-w-[500px] mx-auto">
          <span className="text-2xl">&#x1F527;</span>
          <div>
            <h3 className="font-oswald font-bold text-sm text-black uppercase">ОТДЕЛ СТО</h3>
            <p className="text-xs text-gray-400">Директор по СТО Россия</p>
          </div>
          <div className="ml-auto text-right">
            <span className="font-oswald font-bold text-xl text-blue-900">69</span>
            <p className="text-[10px] text-gray-400 uppercase">человек</p>
          </div>
        </div>

        {/* Roles with KPI */}
        <div className="space-y-2">
          {roles.map((r, i) => (
            <details
              key={i}
              className="group border border-gray-200 bg-gray-50/50 cursor-pointer"
              open={openIndex === i}
              onClick={(e) => { e.preventDefault(); setOpenIndex(openIndex === i ? null : i); }}
            >
              <summary className="flex items-center justify-between p-3 list-none">
                <div className="flex items-center gap-3">
                  <span className="font-oswald font-bold text-lg text-blue-700">{r.count}</span>
                  <div>
                    <h4 className="font-semibold text-sm text-black">{r.title}</h4>
                    <p className="text-xs text-gray-400">{r.subtitle}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {r.key && (
                    <button
                      onClick={(e) => { e.stopPropagation(); setActiveRole(r.key!); }}
                      className="px-2 py-1 bg-red-600 text-white text-[10px] font-bold uppercase hover:bg-red-700 transition-colors"
                    >
                      KPI
                    </button>
                  )}
                  <span className="text-gray-400 group-open:rotate-180 transition-transform text-xs">&#x25BC;</span>
                </div>
              </summary>
              <div className="px-3 pb-3 pt-0">
                <div className="h-px w-full bg-gray-200 mb-2 ml-12" />
                <ul className="space-y-1 ml-12">
                  {r.details.map((d, j) => (
                    <li key={j} className="flex items-start gap-2 text-xs text-gray-600">
                      <span className="text-blue-500">&#x2714;</span>
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </details>
          ))}
        </div>
      </div>

      <KPIModal dept="cto" roleKey={activeRole} onClose={() => setActiveRole(null)} />
    </section>
  );
}
