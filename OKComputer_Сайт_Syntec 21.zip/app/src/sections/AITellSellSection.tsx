const capabilities = [
  { icon: '\u{1F4DE}', title: 'ТЕЛЕФОННЫЕ ЗВОНКИ', desc: 'Звонит от лица компании SINTEC' },
  { icon: '\u{1F4CB}', title: 'СБОР ЗАКАЗОВ', desc: 'Принимает заказы, фиксирует объёмы' },
  { icon: '\u{1F4AC}', title: 'ОБРАТНАЯ СВЯЗЬ', desc: 'Собирает отзывы клиентов' },
  { icon: '\u{1F3A7}', title: 'ПОДДЕРЖКА КЛИЕНТОВ', desc: 'Отвечает на вопросы' },
  { icon: '\u{1F4D6}', title: 'ТЕХ. ПАРАМЕТРЫ', desc: 'Знает все характеристики' },
  { icon: '\u{1F441}', title: 'ТАЙНЫЕ ЗВОНКИ', desc: 'Проверка качества' },
  { icon: '\u{1F465}', title: 'ВНУТРЕННИЕ ЗВОНКИ', desc: 'Созванивается в компании' },
  { icon: '\u{1F3A4}', title: 'ЗАПИСЬ РАЗГОВОРОВ', desc: 'Фиксирует все диалоги' },
  { icon: '\u{1F4DD}', title: 'РАСШИФРОВКА В ТЕКСТ', desc: 'Преобразует речь в текст' },
  { icon: '\u{1F4C8}', title: 'ЕЖЕДНЕВНЫЙ ДАШБОРД', desc: 'Аналитика и отчёты' },
  { icon: '\u{1F4E1}', title: 'МОНИТОРИНГ ЦЕН', desc: 'Отслеживает цены конкурентов' },
  { icon: '\u{1F3AF}', title: 'ПЛАНИРОВАНИЕ', desc: 'Ставит цели и контролирует' },
];

export default function AITellSellSection() {
  return (
    <section className="py-16 px-4 bg-gradient-to-br from-red-600 via-red-700 to-red-900">
      <div className="max-w-[900px] mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 bg-white/10 border border-white/20">
            <span className="text-xs font-medium text-white uppercase tracking-widest">&#x1F916; AI Тренажёр</span>
          </div>
          <h2 className="font-oswald font-bold text-4xl lg:text-5xl text-white mb-3">
            AI <span className="text-yellow-300">TELL</span>SELL
          </h2>
          <p className="text-base text-white/80 max-w-lg mx-auto mb-6">
            Человекоподобный робот для увеличения продаж. Работает 24/7.
          </p>

          {/* AI badge */}
          <div className="inline-flex items-center gap-3 px-6 py-3 bg-white/10 border border-white/20 mb-8">
            <span className="text-2xl">&#x1F916;</span>
            <div className="text-left">
              <p className="text-white text-sm font-medium">AI-ассистент отдела продаж</p>
              <p className="text-white/60 text-xs">Звонки · Заказы · Аналитика · HR</p>
            </div>
          </div>
        </div>

        {/* Capabilities grid 2x2 on mobile, 3x4 on desktop */}
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 mb-8">
          {capabilities.map((c, i) => (
            <div
              key={i}
              className="group p-4 lg:p-5 bg-black/20 border border-white/10 hover:bg-black/30 transition-all"
            >
              <span className="text-2xl lg:text-3xl mb-3 block">{c.icon}</span>
              <h3 className="font-oswald font-bold text-sm lg:text-base text-white uppercase mb-1">
                {c.title}
              </h3>
              <p className="text-white/50 text-xs">{c.desc}</p>
            </div>
          ))}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { val: '12', label: 'СЦЕНАРИЕВ' },
            { val: '24/7', label: 'ДОСТУП' },
            { val: '100%', label: 'ОХВАТ' },
          ].map((s, i) => (
            <div key={i} className="p-4 bg-black/20 border border-white/10 text-center">
              <span className="font-oswald font-bold text-2xl lg:text-3xl text-white">{s.val}</span>
              <p className="text-[10px] text-white/50 uppercase tracking-wider mt-1">{s.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
