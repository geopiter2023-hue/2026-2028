import { useState } from 'react';
import KPIModal from '../components/KPIModal';

const flModules = [
  {
    num: '01',
    emoji: '\u{1F6D2}',
    title: 'Покупка для себя',
    color: '#CC0000',
    details: [
      'Личный кабинет покупателя: регистрация по телефону, история заказов, избранные товары, бонусы',
      'Широкий ассортимент: моторные масла SINTEC, TAKAYAMA, смазки MIRAX, премиум ROLF, автокосметика',
      'Подбор по автомобилю: ввод марки, модели, года — система подбирает подходящие масла и жидкости',
      'Проверка оригинальности: сканирование QR-кода на упаковке — подтверждение подлинности продукта',
      'Программа лояльности: кэшбэк баллами, скидки постоянным покупателям, ранний доступ к акциям',
    ],
  },
  {
    num: '02',
    emoji: '\u{1F4B3}',
    title: 'Кредитные продукты — Банки-партнёры',
    color: '#990000',
    details: [
      'СберБанк: рассрочка 0% на 3-6 месяцев, кредит на покупку от 3 000 ₽, оформление в 2 клика через СберID',
      'Альфа-Банк: рассрочка 0-0,5% на 3-12 месяцев, кредит до 500 000 ₽, мгновенное одобрение для клиентов банка',
      'Т-Банк (Тинькофф): рассрочка на 3-24 месяца, кредитная линия до 1 000 000 ₽, кэшбэк до 30% в рассрочку',
      'Условия для всех банков: минимальная сумма заказа от 3 000 ₽, оформление прямо на сайте/в приложении',
      'Без первоначального взноса: 100% стоимости товара в рассрочку, доставка до оплаты первого платежа',
    ],
  },
  {
    num: '03',
    emoji: '\u{1F69A}',
    title: 'Доставка и самовывоз',
    color: '#660000',
    details: [
      'Доставка курьером: по Москве и СПб — день в день, по России — 1-3 дня через партнёрские службы',
      'Пункты выдачи: более 15 000 ПВЗ по всей России — СДЭК, Boxberry, PickPoint, 5post',
      'Самовывоз со склада: бесплатно, ежедневно с 9:00 до 21:00, адрес и карта в личном кабинете',
      'Отслеживание заказа: SMS и push-уведомления на каждом этапе — от сборки до вручения',
      'Примерка и проверка: возможность осмотреть товар при получении, возврат в течение 14 дней',
    ],
  },
  {
    num: '04',
    emoji: '\u{1F4F1}',
    title: 'Мобильное приложение',
    color: '#CC0000',
    details: [
      'Приложение SINTEC Store: доступно для iOS и Android — заказ в 2 касания, сканер VIN-номера',
      'Push-уведомления: напоминание о замене масла, персональные скидки, флеш-распродажи',
      'Геолокация: автоматический поиск ближайших пунктов выдачи и офлайн-магазинов SINTEC',
      'Гараж в приложении: сохранение всех своих автомобилей — быстрый подбор масла под каждое авто',
      'Оплата: карта, Apple Pay, Google Pay, СБП, рассрочка — все способы в одном приложении',
    ],
  },
];

const ulModules = [
  {
    num: '01',
    emoji: '\u{1F3E2}',
    title: 'Подключение юридических лиц',
    color: '#1a2744',
    details: [
      'Работа с ООО и АО: полный цикл от первой встречи до подписания договора поставки',
      'Юридическое сопровождение: согласование договора, спецификаций, приложений с юристами клиента',
      'Тендерные закупки: помощь в подготовке документов для участия в тендерах крупных сетей',
      'Индивидуальные условия: разработка персональных цен, скидок и бонусов под объём заказчика',
      'Выделенный менеджер: закрепление ключевого менеджера для оперативного решения вопросов',
    ],
  },
  {
    num: '02',
    emoji: '\u{1F4B3}',
    title: 'Кредитные продукты для бизнеса',
    color: '#243352',
    details: [
      'СберБанк Бизнес: кредит на оборотные средства до 50 млн ₽, овердрафт, банковские гарантии',
      'Альфа-Банк Бизнес: кредитная линия до 100 млн ₽, лизинг оборудования, факторинг поставок',
      'Т-Банк Бизнес: кредит до 30 млн ₽ без залога, РКО с бесплатным обслуживанием, эквайринг',
      'Лизинг через банки-партнёры: приобретение оборудования для СТО и магазинов в лизинг',
      'Факторинг: финансирование дебиторской задолженности, ускорение оборота средств',
    ],
  },
  {
    num: '03',
    emoji: '\u{1F4CB}',
    title: 'Контракты и условия',
    color: '#2e3f62',
    details: [
      'Долгосрочные договоры: контракты на 12-24 месяца с фиксированными ценами и гарантированными объёмами',
      'Гибкая система скидок: прогрессивная шкала скидок в зависимости от объёма закупок за квартал',
      'Отсрочка платежа: до 60 дней для крупных контрагентов с положительной кредитной историей',
      'Эксклюзивные условия: особые условия для стратегических партнёров — крупнейших дистрибьюторов и сетей',
      'Штрафные санкции: прозрачная система штрафов за нарушение сроков и условий с обеих сторон',
    ],
  },
  {
    num: '04',
    emoji: '\u{1F69B}',
    title: 'Логистика и склад для ЮЛ',
    color: '#384d72',
    details: [
      'Прямые поставки на склад: доставка крупными партиями на склад клиента или дистрибьютора',
      'Just-in-Time поставки: точная доставка по графику под производственные потребности клиента',
      'EDI-интеграция: электронный обмен документами — заказы, накладные, счета через API',
      'Управление запасами: совместный прогноз спроса, планирование пополнения, контроль остатков',
      'Мультимодальные перевозки: автомобиль, ЖД, контейнеры — оптимальный способ доставки',
    ],
  },
  {
    num: '05',
    emoji: '\u{1F3AF}',
    title: 'Развитие партнёрства ЮЛ',
    color: '#425b82',
    details: [
      'Квартальные бизнес-ревью: совместный анализ продаж, планов на квартал, корректировка стратегии',
      'Совместный маркетинг: ко-финансирование промо-акций, размещение в каналах коммуникации',
      'Обучение персонала: проведение тренингов для сотрудников клиента по продуктам SINTEC',
      'Программа «Стратегический партнёр»: особые условия, приоритет в поставках, доступ к новинкам',
      'Аудит удовлетворённости: ежегодный опрос NPS среди юридических клиентов — минимальный показатель 80+',
    ],
  },
];

export default function BrandStoresSection() {
  const [activeRole, setActiveRole] = useState<string | null>(null);

  return (
    <section id="brand-stores" className="py-16 px-4 bg-white">
      <div className="max-w-[900px] mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 border border-red-200 bg-red-50">
            <span className="text-xs font-medium text-red-600 uppercase tracking-widest">&#x1F3EA; Развитие магазинов</span>
          </div>
          <h2 className="font-oswald font-bold text-3xl lg:text-4xl text-black mb-2">МАГАЗИНЫ БРЕНДА</h2>
          <p className="text-sm text-gray-500 max-w-lg mx-auto">Покупка продукции SINTEC — физическими и юридическими лицами</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-3 mb-8 max-w-[400px] mx-auto">
          {[
            { val: 'ФЛ', label: 'Физические лица', color: '#CC0000' },
            { val: 'ЮЛ', label: 'Юридические лица', color: '#1a2744' },
          ].map((s, i) => (
            <div key={i} className="p-3 border border-gray-200 bg-gray-50 text-center">
              <span className="font-oswald font-bold text-2xl" style={{ color: s.color }}>{s.val}</span>
              <p className="text-[10px] text-gray-400 uppercase tracking-wider mt-1">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="h-px w-full bg-red-200 mb-6" />

        {/* FL Section */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <span className="text-2xl">&#x1F464;</span>
            <div>
              <h3 className="font-oswald font-bold text-xl text-black uppercase">ФИЗИЧЕСКИЕ ЛИЦА</h3>
              <p className="text-xs text-gray-400">Конечные потребители — покупка для личного использования</p>
            </div>
          </div>

          <div className="space-y-3">
            {flModules.map((m, i) => (
              <details key={i} className="group border border-red-200 bg-red-50/30 cursor-pointer">
                <summary className="flex items-center gap-3 p-4 list-none">
                  <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center font-oswald font-bold text-white text-sm" style={{ backgroundColor: m.color }}>
                    {m.num}
                  </div>
                  <span className="text-2xl flex-shrink-0">{m.emoji}</span>
                  <h3 className="font-oswald font-bold text-base text-black uppercase flex-1">{m.title}</h3>
                  <span className="text-gray-400 group-open:rotate-180 transition-transform text-sm">&#x25BC;</span>
                </summary>
                <div className="px-4 pb-4">
                  <div className="h-px w-full bg-red-200 mb-3 ml-16" />
                  <ul className="space-y-2 ml-16">
                    {m.details.map((d, j) => (
                      <li key={j} className="flex items-start gap-2 text-sm text-gray-600">
                        <span style={{ color: m.color }}>&#x2714;</span>
                        <span>{d}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </details>
            ))}
          </div>
        </div>

        <div className="h-px w-full bg-gray-200 mb-6" />

        {/* UL Section */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <span className="text-2xl">&#x1F3E2;</span>
            <div>
              <h3 className="font-oswald font-bold text-xl text-black uppercase">ЮРИДИЧЕСКИЕ ЛИЦА</h3>
              <p className="text-xs text-gray-400">ООО, АО, корпоративные клиенты, дистрибьюторы, сети</p>
            </div>
          </div>

          <div className="space-y-3">
            {ulModules.map((m, i) => (
              <details key={i} className="group border border-blue-200 bg-blue-50/30 cursor-pointer">
                <summary className="flex items-center gap-3 p-4 list-none">
                  <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center font-oswald font-bold text-white text-sm" style={{ backgroundColor: m.color }}>
                    {m.num}
                  </div>
                  <span className="text-2xl flex-shrink-0">{m.emoji}</span>
                  <h3 className="font-oswald font-bold text-base text-black uppercase flex-1">{m.title}</h3>
                  <span className="text-gray-400 group-open:rotate-180 transition-transform text-sm">&#x25BC;</span>
                </summary>
                <div className="px-4 pb-4">
                  <div className="h-px w-full bg-blue-200 mb-3 ml-16" />
                  <ul className="space-y-2 ml-16">
                    {m.details.map((d, j) => (
                      <li key={j} className="flex items-start gap-2 text-sm text-gray-600">
                        <span style={{ color: m.color }}>&#x2714;</span>
                        <span>{d}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </details>
            ))}
          </div>
        </div>

        {/* Bottom principle */}
        <div className="mt-4 p-4 bg-gray-50 border border-gray-200 rounded-lg text-center">
          <p className="text-sm text-gray-700">
            <span className="font-semibold text-red-600">ФЛ:</span> Покупка, рассрочка, доставка, приложение &nbsp;|&nbsp; <span className="font-semibold text-blue-900">ЮЛ:</span> Подключение, кредит для бизнеса, контракты, логистика, партнёрство
          </p>
        </div>

        {/* Growth targets */}
        <div className="mt-4 grid grid-cols-1 lg:grid-cols-2 gap-3">
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg text-center">
            <p className="text-sm text-gray-700">
              <span className="font-semibold text-green-700">&#x1F4C8; ФЛ:</span> Потенциал роста <strong>+250-400 млн ₽</strong> за счёт развития магазина бренда для физических лиц
            </p>
          </div>
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg text-center">
            <p className="text-sm text-gray-700">
              <span className="font-semibold text-blue-700">&#x1F4C8; ЮЛ:</span> Потенциал роста <strong>+100 млн ₽</strong> за счёт подключения юридических лиц и корпоративных клиентов
            </p>
          </div>
        </div>
      </div>

      <KPIModal dept="directors" roleKey={activeRole} onClose={() => setActiveRole(null)} />
    </section>
  );
}
