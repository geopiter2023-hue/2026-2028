import { useState } from 'react';
import KPIModal from '../components/KPIModal';

const roles = [
  {
    title: 'Региональные директора',
    count: 9,
    subtitle: 'Управление регионами',
    key: 'regional',
    details: [
      '9 региональных директоров покрывают всю территорию России',
      'Каждый директор управляет командой из территориальных менеджеров и торговых представителей',
      'Ответственность за выполнение плана продаж в своём регионе',
      'Контроль качества мерчендайзинга и выкладки продукции',
    ],
  },
  {
    title: 'Территориальные менеджеры',
    count: 30,
    subtitle: 'Координация территорий',
    key: 'manager',
    details: [
      '30 территориальных менеджеров координируют работу торговых представителей',
      'Каждый ТМ закреплён за своей территорией с чёткими границами',
      'Обучение и развитие подчинённых торговых представителей',
      'Совместные аудиты и обратная связь через EasyMerch после каждого выезда',
    ],
  },
  {
    title: 'Торговые представители',
    count: 120,
    subtitle: 'С функцией мерчендайзинга',
    key: 'representative',
    details: [
      '120 торговых представителей работают в поле ежедневно',
      'Каждый ТП закреплён за своим районом и списком торговых точек',
      'Сбор заказов, мерчендайзинг, обучение персонала ТТ',
      'Ежедневная отчётность через CRM: визиты, заказы, фото выкладки',
    ],
  },
];

export default function B2CSection() {
  const [activeRole, setActiveRole] = useState<string | null>(null);
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section id="b2c" className="py-12 px-4 bg-white">
      <div className="max-w-[900px] mx-auto">
        {/* Compact header */}
        <div className="flex items-center gap-4 mb-6">
          <div className="w-12 h-12 flex items-center justify-center border border-red-300 bg-red-50">
            <span className="text-2xl">&#x1F465;</span>
          </div>
          <div className="flex-1">
            <div className="flex items-baseline gap-3">
              <h2 className="font-oswald font-bold text-3xl lg:text-4xl text-black">B2C</h2>
              <span className="font-oswald font-bold text-3xl lg:text-4xl text-red-600">159</span>
              <span className="text-xs text-gray-400 uppercase">человек</span>
            </div>
            <p className="text-sm text-gray-500">Директор B2C Россия</p>
          </div>
        </div>

        <div className="h-px w-full bg-red-200 mb-4" />

        {/* Accordion roles */}
        <div className="space-y-2">
          {roles.map((r, i) => (
            <details
              key={i}
              className="group border border-gray-200 bg-gray-50/50 cursor-pointer"
              open={openIndex === i}
              onClick={(e) => {
                e.preventDefault();
                setOpenIndex(openIndex === i ? null : i);
              }}
            >
              <summary className="flex items-center justify-between p-3 list-none">
                <div className="flex items-center gap-3">
                  <span className="font-oswald font-bold text-lg text-red-600">{r.count}</span>
                  <div>
                    <h4 className="font-semibold text-sm text-black">{r.title}</h4>
                    <p className="text-xs text-gray-400">{r.subtitle}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveRole(r.key);
                    }}
                    className="px-2 py-1 bg-red-600 text-white text-[10px] font-bold uppercase hover:bg-red-700 transition-colors"
                  >
                    KPI
                  </button>
                  <span className="text-gray-400 group-open:rotate-180 transition-transform text-xs">&#x25BC;</span>
                </div>
              </summary>
              <div className="px-3 pb-3 pt-0">
                <div className="h-px w-full bg-gray-200 mb-2 ml-12" />
                <ul className="space-y-1 ml-12">
                  {r.details.map((d, j) => (
                    <li key={j} className="flex items-start gap-2 text-xs text-gray-600">
                      <span className="text-red-500">&#x2714;</span>
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </details>
          ))}
        </div>
      </div>

      <KPIModal dept="b2c" roleKey={activeRole} onClose={() => setActiveRole(null)} />
    </section>
  );
}
