const stats = [
  { emoji: '\u{1F465}', value: '320+', label: 'Специалистов по продажам', color: '#CC0000' },
  { emoji: '\u{1F4CD}', value: '30', label: 'Регионов присутствия', color: '#5c6b00' },
  { emoji: '\u{1F3E2}', value: '7', label: 'Направлений продаж', color: '#8B3A00' },
  { emoji: '\u{1F310}', value: '15+', label: 'Стран экспорта', color: '#005f7f' },
  { emoji: '\u{2B50}', value: '5', label: 'Брендов в портфеле', color: '#6b238f' },
  { emoji: '\u{1F6D2}', value: '+350млн', label: 'Потенциал ФЛ магазина', color: '#CC0000' },
  { emoji: '\u{1F3E2}', value: '+100млн', label: 'Потенциал ЮЛ магазина', color: '#1a2744' },
  { emoji: '\u{1F4C8}', value: '+10-15%', label: 'Рост доли B2C за 2 года', color: '#006b4f' },
];

export default function StatsSection() {
  return (
    <section className="py-16 px-4 bg-white">
      <div className="max-w-[900px] mx-auto">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 border border-red-200 bg-red-50">
            <span className="text-xs font-medium text-red-600 uppercase tracking-widest">&#x1F4C8; Масштаб</span>
          </div>
          <h2 className="font-oswald font-bold text-4xl lg:text-5xl text-black mb-2">В ЦИФРАХ</h2>
          <p className="text-sm text-gray-500">Общая структура отдела продаж СИНТЕК</p>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
          {stats.map((s, i) => (
            <div key={i} className="p-5 lg:p-6 border border-gray-200 bg-gray-50/50 hover:border-gray-300 transition-all">
              <span className="text-xl mb-2 block">{s.emoji}</span>
              <span className="font-oswald font-bold text-3xl lg:text-4xl block mb-1" style={{ color: s.color }}>{s.value}</span>
              <p className="text-[10px] text-gray-400 uppercase tracking-wider">{s.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
