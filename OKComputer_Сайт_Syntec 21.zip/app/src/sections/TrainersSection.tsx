import { useState } from 'react';
import KPIModal from '../components/KPIModal';

const roles = [
  {
    title: 'Тренер по управлению и продажам',
    count: '3',
    subtitle: '3 человека в поле — лидерство, переговоры, влияние',
    key: 'management',
    details: [
      '3 тренера работают в поле — по всей России, ездят с торговыми представителями',
      'Тренинги лидерства для ТМ и РД: управление командой, постановка целей, делегирование, мотивация',
      'Переговоры и влияние: техники убеждения, работа с возражениями, закрытие сделок, построение доверия',
      'Развитие эмоционального интеллекта: понимание эмоций клиента и партнёра, адаптация стиля общения',
      'Практические сессии: разбор реальных кейсов торговых команд, ролевые игры, симуляция сложных переговоров',
      'Совместные выезды: тренер едет с ТП в поле, наблюдает, дает обратную связь, корректирует техники',
      'Индивидуальные планы развития: для каждого менеджера составляется персональный план прокачки навыков',
    ],
  },
  {
    title: 'Тренер по продуктам',
    count: '1',
    subtitle: '1 человек в офисе — глубокое знание портфеля SINTEC',
    key: 'product',
    details: [
      '1 тренер в офисе — отвечает за глубокое знание всего продуктового портфеля SINTEC',
      'Продуктовые тренинги: моторные масла SINTEC и TAKAYAMA, смазки MIRAX, премиум ROLF, автокосметика',
      'Технические характеристики: вязкость, допуски ACEA/API, применимость к двигателям, климатические условия',
      'Конкурентный анализ: сравнение продуктов SINTEC с конкурентами, аргументация преимуществ',
      'Обучение новых сотрудников: интенсивный курс продуктовой подготовки для всех новичков отдела продаж',
      'Обновления и новинки: регулярные брифинги при запуске новых SKU, изменениях в линейке',
      'Сертификация: система аттестации знаний продукта — обязательный экзамен для всех ТП и ТМ',
    ],
  },
  {
    title: 'AI Тренажёр TellSell',
    count: '24/7',
    subtitle: 'Постоянное развитие через AI-симуляции',
    key: 'ai',
    details: [
      'AI-симулятор переговоров — доступен 24 часа в сутки, 7 дней в неделю',
      '12 сценариев: от первого контакта с клиентом до закрытия сложной сделки с возражениями',
      'AI-оценка навыков: система анализирует речь, тон, скорость, аргументацию — рейтинг от 1 до 100',
      'Персональный план развития: AI выявляет слабые зоны каждого сотрудника и формирует индивидуальную программу',
      'Симуляция возражений: работа с типичными отказами клиентов — дорого, не знаю бренд, работаю с другим',
      'Тренировка между визитами: сотрудник тренируется в дороге, вечером, в любое удобное время',
      'Рейтинг и соревнования: лидерборд по навыкам переговоров — лучшие получают премии и признание',
      'Синхронизация с CRM: AI тренажёр получает данные о реальных сделках и подстраивает сценарии',
    ],
  },
];

const modules = [
  {
    num: '01',
    emoji: '\u{1F3CB}',
    title: 'Программа тренингов',
    color: '#005f7f',
    details: [
      'Недельный интенсив для новичков: продуктовая база, техники продаж, работа с CRM, маршрутизация',
      'Ежемесячные тренинги для ТП: разбор кейсов, новые техники, обновления ассортимента, конкурентная разведка',
      'Квартальные сессии для ТМ: стратегическое планирование, управление командой, анализ KPI',
      'Годовой саммит: все торговые представители собираются для обмена опытом, награждения лучших',
    ],
  },
  {
    num: '02',
    emoji: '\u{1F4CA}',
    title: 'Оценка эффективности обучения',
    color: '#007a8a',
    details: [
      'Тестирование до и после: измерение знаний сотрудника до тренинга и через 30 дней после',
      'Применение на практике: тренер проверяет, использует ли сотрудник новые техники в реальных визитах',
      'KPI роста: сравнение показателей сотрудника до и после прохождения обучения — рост продаж, конверсии',
      'Обратная связь: анкетирование сотрудников о качестве тренингов — оценка полезности и применимости',
    ],
  },
  {
    num: '03',
    emoji: '\u{1F3C6}',
    title: 'Клуб Легенд',
    color: '#008f9f',
    details: [
      'Золотой бейдж: трейдер, выполнивший план 12 месяцев подряд, получает статус «Легенда»',
      'Право обучать: легенды становятся наставниками для новичков — передача лучших практик',
      'Привилегии: приоритет на корпоративных мероприятиях, доступ к закрытым тренингам, повышенный кэшбэк',
      'Снижение нагрузки: 3 легенды заменяют 1 тренера — peer-to-peer обучение внутри команды',
    ],
  },
  {
    num: '04',
    emoji: '\u{1F916}',
    title: 'AI Тренажёр — возможности',
    color: '#006b8f',
    details: [
      'Голосовые симуляции: сотрудник разговаривает с AI-клиентом — отработка живой речи, интонаций, пауз',
      'Чат-бот тренировки: текстовые переговоры для отработки письменной коммуникации с клиентами',
      'Видео-разбор: запись реальных визитов с последующим AI-анализом и рекомендациями',
      'Адаптивная сложность: чем выше навык сотрудника — тем сложнее сценарии AI-тренажёра',
      'Геймификация: баллы, уровни, достижения — обучение превращается в увлекательный процесс',
      'Мобильное приложение: тренировки в дороге, офлайн-режим, синхронизация прогресса',
    ],
  },
];

export default function TrainersSection() {
  const [activeRole, setActiveRole] = useState<string | null>(null);
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section className="py-16 px-4 bg-gray-50">
      <div className="max-w-[900px] mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 border border-blue-200 bg-blue-50">
            <span className="text-xs font-medium text-blue-700 uppercase tracking-widest">&#x1F393; Обучение</span>
          </div>
          <h2 className="font-oswald font-bold text-3xl lg:text-4xl text-black mb-2">ОТДЕЛ ОБУЧЕНИЯ</h2>
          <p className="text-sm text-gray-500 max-w-lg mx-auto">3 типа тренеров + AI — полный цикл развития сотрудников</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-8 max-w-[400px] mx-auto">
          {[
            { val: '4', label: 'Тренера', color: '#005f7f' },
            { val: '3', label: 'В поле', color: '#007a8a' },
            { val: '1', label: 'В офисе', color: '#005f7f' },
          ].map((s, i) => (
            <div key={i} className="p-3 border border-gray-200 bg-white text-center">
              <span className="font-oswald font-bold text-2xl" style={{ color: s.color }}>{s.val}</span>
              <p className="text-[10px] text-gray-400 uppercase tracking-wider mt-1">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="h-px w-full bg-blue-200 mb-6" />

        {/* Team block */}
        <div className="flex items-center gap-3 mb-6 p-3 border border-gray-200 bg-white max-w-[500px] mx-auto">
          <span className="text-2xl">&#x1F393;</span>
          <div>
            <h3 className="font-oswald font-bold text-sm text-black uppercase">ОТДЕЛ ОБУЧЕНИЯ</h3>
            <p className="text-xs text-gray-400">Руководитель отдела обучения</p>
          </div>
          <div className="ml-auto text-right">
            <span className="font-oswald font-bold text-xl text-blue-800">4</span>
            <p className="text-[10px] text-gray-400 uppercase">тренера</p>
          </div>
        </div>

        {/* Roles with KPI buttons */}
        <div className="space-y-2 mb-8">
          {roles.map((r, i) => (
            <details
              key={i}
              className="group border border-gray-200 bg-white cursor-pointer"
              open={openIndex === i}
              onClick={(e) => { e.preventDefault(); setOpenIndex(openIndex === i ? null : i); }}
            >
              <summary className="flex items-center justify-between p-3 list-none">
                <div className="flex items-center gap-3">
                  <span className="font-oswald font-bold text-lg text-blue-800">{r.count}</span>
                  <div>
                    <h4 className="font-semibold text-sm text-black">{r.title}</h4>
                    <p className="text-xs text-gray-400">{r.subtitle}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {r.key && (
                    <button
                      onClick={(e) => { e.stopPropagation(); setActiveRole(r.key!); }}
                      className="px-2 py-1 bg-red-600 text-white text-[10px] font-bold uppercase hover:bg-red-700 transition-colors"
                    >
                      KPI
                    </button>
                  )}
                  <span className="text-gray-400 group-open:rotate-180 transition-transform text-xs">&#x25BC;</span>
                </div>
              </summary>
              <div className="px-3 pb-3 pt-0">
                <div className="h-px w-full bg-gray-200 mb-2 ml-12" />
                <ul className="space-y-1 ml-12">
                  {r.details.map((d, j) => (
                    <li key={j} className="flex items-start gap-2 text-xs text-gray-600">
                      <span className="text-blue-600">&#x2714;</span>
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </details>
          ))}
        </div>

        <div className="h-px w-full bg-blue-200 mb-6" />

        {/* Modules accordion */}
        <div className="space-y-3">
          {modules.map((m, i) => (
            <details key={i} className="group border border-gray-200 bg-white cursor-pointer">
              <summary className="flex items-center gap-3 p-4 list-none">
                <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center font-oswald font-bold text-white text-sm" style={{ backgroundColor: m.color }}>
                  {m.num}
                </div>
                <span className="text-2xl flex-shrink-0">{m.emoji}</span>
                <h3 className="font-oswald font-bold text-base text-black uppercase flex-1">{m.title}</h3>
                <span className="text-gray-400 group-open:rotate-180 transition-transform text-sm">&#x25BC;</span>
              </summary>
              <div className="px-4 pb-4">
                <div className="h-px w-full bg-gray-200 mb-3 ml-16" />
                <ul className="space-y-2 ml-16">
                  {m.details.map((d, j) => (
                    <li key={j} className="flex items-start gap-2 text-sm text-gray-600">
                      <span style={{ color: m.color }}>&#x2714;</span>
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </details>
          ))}
        </div>
      </div>

      <KPIModal dept="trainers" roleKey={activeRole} onClose={() => setActiveRole(null)} />
    </section>
  );
}
