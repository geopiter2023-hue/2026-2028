import { useState } from 'react';
import KPIModal from '../components/KPIModal';

const modules = [
  {
    num: '01',
    emoji: '\u{1F4E6}',
    title: 'Поддержка ассортимента',
    color: '#1a2744',
    details: [
      'Контроль наличия всех брендов SINTEC на складе дистрибьютора: SINTEC, TAKAYAMA, MIRAX, ROLF, Автокосметика SINTEC',
      'Анализ оборачиваемости SKU: выявление «залежавшихся» позиций и формирование рекомендаций по ассортименту',
      'Планограмма размещения: рекомендации по оптимальному размещению товаров на складе дистрибьютора',
      'Прогноз пополнения: система автоматически рассчитывает потребность в пополнении на основе продаж',
      'Синхронизация через API: остатки на складе дистрибьютора обновляются в реальном времени',
    ],
  },
  {
    num: '02',
    emoji: '\u{1F465}',
    title: 'Развитие команды дистрибьютора',
    color: '#243352',
    details: [
      'Совместные выезды на торговые точки: BDM SINTEC едет в поле с торговыми представителями дистрибьютора',
      'Обучающие собрания для сотрудников дистрибьютора: продуктовые презентации, техники продаж, работа с возражениями',
      'Аудит качества работы: проверка визитов, отчётности, мерчендайзинга — обратная связь через EasyMerch',
      'Менторство BDM: каждый BDM закреплён за своими ТП дистрибьютора — регулярные созвоны и разбор кейсов',
      'Мотивационные программы: совместные акции, конкурсы, бонусные схемы для команды дистрибьютора',
    ],
  },
  {
    num: '03',
    emoji: '\u{1F3AF}',
    title: 'Аудиты рынка & Новые точки',
    color: '#2e3f62',
    details: [
      'Аудит рынка в зоне ответственности дистрибьютора: обход точек, сбор данных, фотоотчёты, анализ конкурентов',
      'Поиск новых торговых точек: BDM идентифицирует потенциальных клиентов и передаёт дистрибьютору для подключения',
      'Развитие существующих точек: план расширения ассортимента, увеличение доли полки, запуск акций',
      'Поиск новых возможностей: мониторинг тендеров, крупных сетей, строительных проектов в регионе дистрибьютора',
      'Отчёт по результатам аудита: автоматическая генерация отчёта с рекомендациями для дистрибьютора',
    ],
  },
  {
    num: '04',
    emoji: '\u{1F504}',
    title: 'Взаимодействие клиент–дистрибьютор',
    color: '#384d72',
    details: [
      'Решение вопросов «клиент–дистрибьютор»: BDM SINTEC выступает связующим звеном между торговой точкой и дистрибьютором',
      'Передача данных по клиентам: BDM передаёт дистрибьютору информацию о новых точках, заказах и потребностях рынка',
      'Определение зон продаж дистрибьютора: чёткие границы территории с картой и списком закреплённых точек',
      'Контроль обслуживания: мониторинг сроков доставки, качества сервиса, реакции на заказы дистрибьютора',
      'Разрешение конфликтов: BDM помогает решать спорные ситуации между клиентом и дистрибьютором',
    ],
  },
  {
    num: '05',
    emoji: '\u{2B50}',
    title: 'Сегментация точек',
    color: '#425b82',
    details: [
      'Платинум: крупнейшие точки с максимальным потенциалом — на прямом обслуживании ТП SINTEC с полным пакетом услуг',
      'Голд: перспективные точки с высоким объёмом — на прямом обслуживании ТП SINTEC с регулярным развитием',
      'Сильвер: стабильные точки среднего потенциала — обслуживаются ТП дистрибьютора с контролем со стороны BDM',
      'Бронза: базовые точки с минимальным потенциалом — обслуживаются ТП дистрибьютора, поддержка через BDM при необходимости',
      'Пересегментация ежеквартально: точки могут переходить между категориями на основе динамики продаж',
    ],
  },
  {
    num: '06',
    emoji: '\u{1F4CB}',
    title: 'Маркетинговые материалы',
    color: '#4c6992',
    details: [
      'Контроль заказов маркетинговых материалов: BDM помогает дистрибьютору правильно сформировать заявку на POS-материалы',
      'Эффективное использование: анализ какие материалы работают лучше в конкретном регионе — фокус на результат',
      'Библиотека материалов: каталоги, стенды, ценники, дисплеи, пробники — доступ к актуальным промо-материалам',
      'Маркетинговый календарь: план промо-активностей на квартал — BDM доводит до дистрибьютора и контролирует выполнение',
      'Отчёт по использованию: процент магазинов с актуальными POS-материалами — KPI BDM',
    ],
  },
  {
    num: '07',
    emoji: '\u{1F3C6}',
    title: 'KPI BDM',
    color: '#5678a2',
    details: [
      'Подключение клиентов к Бонус Клубу: основной KPI — каждый BDM имеет план по подключению новых точек к программе лояльности',
      'Формирование заказа и отправка дистрибьютору: BDM мотивирует точку сформировать заказ и передать его дистрибьютору',
      'Рост выручки по ведомым магазинам: ежемесячный прирост продаж через дистрибьютора не менее 10%',
      'Количество новых подключённых точек в месяц: план по привлечению новых торговых точек через дистрибьютора',
      'Активность Бонус Клуба: процент точек, регулярно использующих программу лояльности — целевой показатель 80%+',
    ],
  },
  {
    num: '08',
    emoji: '\u{1F4CA}',
    title: 'Автоматическая аналитика по дистрибьютору',
    color: '#6082b2',
    details: [
      'Результат работы BDM и региональных менеджеров: система собирает данные по всем визитам, заказам и активностям каждого дистрибьютора',
      'Автоматическая генерация презентаций для собраний: на основе собранных данных система формирует готовую презентацию для встречи с торговыми представителями дистрибьютора',
      'Анализ динамики продаж: сравнение текущего периода с предыдущим — рост, падение, тренды по каждому SKU',
      'Оценка эффективности Бонус Клуба: сколько точек подключено, какая активность, какие начисления — всё в одном отчёте',
      'Топ-точки и проблемные зоны: автоматическое выявление лучших торговых точек и тех, кто отстаёт по продажам',
      'Прогноз и рекомендации: система рассчитывает прогноз продаж на следующий месяц и даёт рекомендации по развитию дистрибьютора',
    ],
  },
  {
    num: '09',
    emoji: '\u{1F3CB}',
    title: 'Тренеры BDM — Влияние и вовлечение',
    color: '#6b8fa8',
    details: [
      '2 тренера специализируются на развитии навыков влияния и вовлечения для BDM',
      'Тренинг «Убеждение и влияние»: техники переговоров, построение доверия, управление возражениями дистрибьюторов',
      'Тренинг «Вовлечение команды дистрибьютора»: как мотивировать ТП дистрибьютора работать с продуктами SINTEC',
      'Практические сессии: разбор реальных кейсов BDM, ролевые игры, симуляция сложных переговоров',
      'Совместные выезды: тренеры едут с BDM в поле, наблюдают, дают обратную связь, корректируют техники',
      'Оценка прогресса: ежемесячный аудит навыков каждого BDM — план развития на квартал',
    ],
  },
  {
    num: '10',
    emoji: '\u{1F916}',
    title: 'AI Тренажёр для BDM',
    color: '#7a9ab0',
    details: [
      'AI-симулятор переговоров с дистрибьютором: BDM практикует сложные сценарии — возражения, конфликты, закрытие сделок',
      '12 сценариев: от первого знакомства с дистрибьютором до разрешения конфликта по ценам и условиям',
      'AI-оценка: система анализирует речь, тон, аргументацию — рейтинг от 1 до 100 с рекомендациями',
      'Персональный план развития: AI выявляет слабые зоны каждого BDM и формирует индивидуальную программу тренировок',
      'Доступ 24/7: BDM тренируется в любое время — между визитами, в дороге, вечером',
      'Соревнования: рейтинг BDM по навыкам переговоров — лучшие получают премии и признание',
    ],
  },
];

const roles = [
  {
    title: 'Директор по дистрибьюторам',
    count: '1',
    subtitle: 'Управление дистрибьюторской сетью',
    key: 'dd',
    details: [
      'Стратегия развития дистрибьюторской сети',
      'Управление командой из 57 сотрудников',
      'Контроль KPI по всем направлениям',
      'Ключевые переговоры с дистрибьюторами',
    ],
  },
  {
    title: 'Региональные менеджеры',
    count: '5',
    subtitle: 'Координация BDM по регионам',
    key: 'rm',
    details: [
      '5 РМ управляют командами BDM в своих регионах',
      'Аудиты рынка, развитие новых дистрибьюторов',
      'Контроль качества работы BDM через EasyMerch',
      'Формирование региональных планов продаж',
    ],
  },
  {
    title: 'BDM',
    count: '50',
    subtitle: 'Бизнес-девелопмент менеджеры на поле',
    key: 'bdm',
    details: [
      '50 BDM работают в поле ежедневно',
      'Поддержка ассортимента, развитие точек',
      'Бонус Клуб — основной KPI',
      'Совместные выезды с ТП дистрибьютора',
    ],
  },
  {
    title: 'Тренеры BDM',
    count: '2',
    subtitle: 'Влияние, вовлечение, переговоры',
    details: [
      '2 тренера специализируются на влиянии и вовлечении',
      'Тренинги убеждения, работа с возражениями',
      'Совместные выезды, разбор кейсов',
      'AI тренажёр — постоянное развитие',
    ],
  },
];

export default function DistributorSection() {
  const [activeRole, setActiveRole] = useState<string | null>(null);
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section id="distributors" className="py-16 px-4 bg-gray-50">
      <div className="max-w-[900px] mx-auto">
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 border border-blue-200 bg-blue-50">
            <span className="text-xs font-medium text-blue-800 uppercase tracking-widest">&#x1F69B; Дистрибьюторы</span>
          </div>
          <h2 className="font-oswald font-bold text-3xl lg:text-4xl text-black mb-2">ДИСТРИБЬЮТОРЫ</h2>
          <p className="text-sm text-gray-500 max-w-lg mx-auto mb-2">Развитие дистрибьюторской сети через BDM</p>
          <p className="text-sm text-gray-400">Поддержка ассортимента, обучение команд, аудиты рынка, открытие новых точек</p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 mb-8 max-w-[600px] mx-auto">
          {[
            { val: '58', label: 'Сотрудников отдела', color: '#1a2744' },
            { val: '5', label: 'Региональных менеджеров', color: '#243352' },
            { val: '50', label: 'BDM на поле', color: '#1a2744' },
            { val: '2', label: 'Тренера BDM', color: '#243352' },
            { val: '1', label: 'Директор', color: '#1a2744' },
            { val: 'AI', label: 'Тренажёр 24/7', color: '#243352' },
          ].map((s, i) => (
            <div key={i} className="p-3 border border-gray-200 bg-white text-center">
              <span className="font-oswald font-bold text-2xl" style={{ color: s.color }}>{s.val}</span>
              <p className="text-[10px] text-gray-400 uppercase tracking-wider mt-1">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="h-px w-full bg-blue-200 mb-6" />

        <div className="flex items-center gap-3 mb-4 p-3 border border-gray-200 bg-white max-w-[500px] mx-auto">
          <span className="text-2xl">&#x1F69B;</span>
          <div>
            <h3 className="font-oswald font-bold text-sm text-black uppercase">ОТДЕЛ ПО ДИСТРИБЬЮТОРАМ</h3>
            <p className="text-xs text-gray-400">Директор по дистрибьюторам</p>
          </div>
          <div className="ml-auto text-right">
            <span className="font-oswald font-bold text-xl text-blue-900">58</span>
            <p className="text-[10px] text-gray-400 uppercase">человек</p>
          </div>
        </div>

        {/* Roles with KPI */}
        <div className="space-y-2 mb-8">
          {roles.map((r, i) => (
            <details
              key={i}
              className="group border border-gray-200 bg-white cursor-pointer"
              open={openIndex === i}
              onClick={(e) => { e.preventDefault(); setOpenIndex(openIndex === i ? null : i); }}
            >
              <summary className="flex items-center justify-between p-3 list-none">
                <div className="flex items-center gap-3">
                  <span className="font-oswald font-bold text-lg text-blue-900">{r.count}</span>
                  <div>
                    <h4 className="font-semibold text-sm text-black">{r.title}</h4>
                    <p className="text-xs text-gray-400">{r.subtitle}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {r.key && (
                    <button
                      onClick={(e) => { e.stopPropagation(); setActiveRole(r.key!); }}
                      className="px-2 py-1 bg-red-600 text-white text-[10px] font-bold uppercase hover:bg-red-700 transition-colors"
                    >
                      KPI
                    </button>
                  )}
                  <span className="text-gray-400 group-open:rotate-180 transition-transform text-xs">&#x25BC;</span>
                </div>
              </summary>
              <div className="px-3 pb-3 pt-0">
                <div className="h-px w-full bg-gray-200 mb-2 ml-12" />
                <ul className="space-y-1 ml-12">
                  {r.details.map((d, j) => (
                    <li key={j} className="flex items-start gap-2 text-xs text-gray-600">
                      <span className="text-blue-800">&#x2714;</span>
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </details>
          ))}
        </div>

        <div className="h-px w-full bg-blue-200 mb-6" />

        {/* Modules accordion */}
        <div className="space-y-3">
          {modules.map((m, i) => (
            <details key={i} className="group border border-gray-200 bg-white cursor-pointer">
              <summary className="flex items-center gap-3 p-4 list-none">
                <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center font-oswald font-bold text-white text-sm" style={{ backgroundColor: m.color }}>
                  {m.num}
                </div>
                <span className="text-2xl flex-shrink-0">{m.emoji}</span>
                <h3 className="font-oswald font-bold text-base text-black uppercase flex-1">{m.title}</h3>
                <span className="text-gray-400 group-open:rotate-180 transition-transform text-sm">&#x25BC;</span>
              </summary>
              <div className="px-4 pb-4">
                <div className="h-px w-full bg-gray-200 mb-3 ml-16" />
                <ul className="space-y-2 ml-16">
                  {m.details.map((d, j) => (
                    <li key={j} className="flex items-start gap-2 text-sm text-gray-600">
                      <span style={{ color: m.color }}>&#x2714;</span>
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </details>
          ))}
        </div>

        <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg text-center">
          <p className="text-sm text-gray-700">
            <span className="font-semibold text-blue-900">Принцип:</span> Платинум &amp; Голд → ТП SINTEC &nbsp;|&nbsp; Сильвер &amp; Бронза → ТП дистрибьютора &nbsp;|&nbsp; Основной KPI BDM — Бонус Клуб + заказ дистрибьютору
          </p>
        </div>

        {/* Growth target */}
        <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg text-center">
          <p className="text-sm text-gray-700">
            <span className="font-semibold text-green-700">&#x1F4C8; Потенциал роста:</span> Рост объёма продаж через дистрибьюторскую сеть за счёт вовлечения и развития партнёров
          </p>
        </div>
      </div>

      <KPIModal dept="distributors" roleKey={activeRole} onClose={() => setActiveRole(null)} />
    </section>
  );
}
