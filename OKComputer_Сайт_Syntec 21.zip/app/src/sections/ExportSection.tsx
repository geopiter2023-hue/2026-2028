import { useState } from 'react';
import KPIModal from '../components/KPIModal';

const roles = [
  {
    title: 'Региональные директора по странам',
    count: '4',
    subtitle: 'Управление экспортом по направлениям',
    key: 'rd',
    details: [
      '4 региональных директора: Беларусь, Казахстан, Армения, Узбекистан',
      'Поиск и развитие дистрибьюторов в стране',
      'Переговоры с крупными сетями и дистрибьюторами',
      'Входящие запросы: конверсия в активных клиентов',
    ],
  },
  {
    title: 'Менеджеры по экспорту',
    count: '4',
    subtitle: 'Ведение клиентов, логистика, документы',
    key: 'manager',
    details: [
      '4 менеджера обслуживают закреплённые страны',
      'Ведение клиентской базы, сбор заказов, отгрузки',
      'Таможенное сопровождение и документооборот',
      'Контроль дебиторской задолженности',
    ],
  },
];

export default function ExportSection() {
  const [activeRole, setActiveRole] = useState<string | null>(null);
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section id="export" className="py-12 px-4 bg-gray-50">
      <div className="max-w-[900px] mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-12 h-12 flex items-center justify-center border border-orange-200 bg-orange-50">
            <span className="text-2xl">&#x1F6E4;</span>
          </div>
          <div className="flex-1">
            <div className="flex items-baseline gap-3">
              <h2 className="font-oswald font-bold text-3xl lg:text-4xl text-black">ЭКСПОРТ</h2>
              <span className="font-oswald font-bold text-3xl lg:text-4xl text-orange-700">8</span>
              <span className="text-xs text-gray-400 uppercase">человек в отделе</span>
            </div>
            <p className="text-sm text-gray-500">Директор по экспорту — РС, Беларусь, Казахстан, Армения, Узбекистан</p>
          </div>
        </div>

        <div className="h-px w-full bg-orange-200 mb-4" />

        <div className="space-y-2">
          {roles.map((r, i) => (
            <details
              key={i}
              className="group border border-gray-200 bg-white cursor-pointer"
              open={openIndex === i}
              onClick={(e) => { e.preventDefault(); setOpenIndex(openIndex === i ? null : i); }}
            >
              <summary className="flex items-center justify-between p-3 list-none">
                <div className="flex items-center gap-3">
                  <span className="font-oswald font-bold text-lg text-orange-700">{r.count}</span>
                  <div>
                    <h4 className="font-semibold text-sm text-black">{r.title}</h4>
                    <p className="text-xs text-gray-400">{r.subtitle}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {r.key && (
                    <button
                      onClick={(e) => { e.stopPropagation(); setActiveRole(r.key!); }}
                      className="px-2 py-1 bg-red-600 text-white text-[10px] font-bold uppercase hover:bg-red-700 transition-colors"
                    >
                      KPI
                    </button>
                  )}
                  <span className="text-gray-400 group-open:rotate-180 transition-transform text-xs">&#x25BC;</span>
                </div>
              </summary>
              <div className="px-3 pb-3 pt-0">
                <div className="h-px w-full bg-gray-200 mb-2 ml-12" />
                <ul className="space-y-1 ml-12">
                  {r.details.map((d, j) => (
                    <li key={j} className="flex items-start gap-2 text-xs text-gray-600">
                      <span className="text-orange-500">&#x2714;</span>
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </details>
          ))}
        </div>
      </div>

      <KPIModal dept="export" roleKey={activeRole} onClose={() => setActiveRole(null)} />
    </section>
  );
}
