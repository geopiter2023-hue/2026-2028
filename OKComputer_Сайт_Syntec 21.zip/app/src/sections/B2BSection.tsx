import { useState } from 'react';
import KPIModal from '../components/KPIModal';

const roles = [
  {
    title: 'Директор B2B',
    count: '1',
    subtitle: 'Управление корпоративными продажами',
    key: 'director',
    details: [
      'Ответственность за выполнение плана B2B-продаж',
      'Управление командой клиентских менеджеров и ключевых переговорщиков',
      'Развитие стратегических отношений с ключевыми клиентами',
      'Контроль воронки продаж и конверсии',
    ],
  },
  {
    title: 'Клиентские менеджеры',
    count: '3',
    subtitle: 'Ведение клиентской базы',
    key: 'km',
    details: [
      'Ведение портфеля ключевых клиентов: от первого контакта до повторных продаж',
      'Регулярные встречи, презентации, согласование условий',
      'Формирование индивидуальных коммерческих предложений',
      'Контроль дебиторской задолженности и сроков оплаты',
    ],
  },
  {
    title: 'Ключевые переговорщики',
    count: '1',
    subtitle: 'Закрытие крупных сделок',
    key: 'kp',
    details: [
      'Проведение переговоров с крупными корпоративными клиентами',
      'Работа с возражениями, согласование условий контрактов',
      'Закрытие сделок высокой сложности и объёма',
      'Партнёрство с клиентами на уровне C-level',
    ],
  },
];

export default function B2BSection() {
  const [activeRole, setActiveRole] = useState<string | null>(null);
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section id="b2b" className="py-12 px-4 bg-gray-50">
      <div className="max-w-[900px] mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-12 h-12 flex items-center justify-center border border-gray-300 bg-white">
            <span className="text-2xl">&#x1F3E2;</span>
          </div>
          <div className="flex-1">
            <div className="flex items-baseline gap-3">
              <h2 className="font-oswald font-bold text-3xl lg:text-4xl text-black">B2B</h2>
              <span className="font-oswald font-bold text-3xl lg:text-4xl text-gray-700">5</span>
              <span className="text-xs text-gray-400 uppercase">человек в отделе</span>
            </div>
            <p className="text-sm text-gray-500">Директор B2B Россия</p>
          </div>
        </div>

        <div className="h-px w-full bg-gray-300 mb-4" />

        <div className="space-y-2">
          {roles.map((r, i) => (
            <details
              key={i}
              className="group border border-gray-200 bg-white cursor-pointer"
              open={openIndex === i}
              onClick={(e) => { e.preventDefault(); setOpenIndex(openIndex === i ? null : i); }}
            >
              <summary className="flex items-center justify-between p-3 list-none">
                <div className="flex items-center gap-3">
                  <span className="font-oswald font-bold text-lg text-gray-700">{r.count}</span>
                  <div>
                    <h4 className="font-semibold text-sm text-black">{r.title}</h4>
                    <p className="text-xs text-gray-400">{r.subtitle}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {r.key && (
                    <button
                      onClick={(e) => { e.stopPropagation(); setActiveRole(r.key!); }}
                      className="px-2 py-1 bg-red-600 text-white text-[10px] font-bold uppercase hover:bg-red-700 transition-colors"
                    >
                      KPI
                    </button>
                  )}
                  <span className="text-gray-400 group-open:rotate-180 transition-transform text-xs">&#x25BC;</span>
                </div>
              </summary>
              <div className="px-3 pb-3 pt-0">
                <div className="h-px w-full bg-gray-200 mb-2 ml-12" />
                <ul className="space-y-1 ml-12">
                  {r.details.map((d, j) => (
                    <li key={j} className="flex items-start gap-2 text-xs text-gray-600">
                      <span className="text-gray-500">&#x2714;</span>
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </details>
          ))}
        </div>
      </div>

      <KPIModal dept="b2b" roleKey={activeRole} onClose={() => setActiveRole(null)} />
    </section>
  );
}
