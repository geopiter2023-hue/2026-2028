import { useEffect } from 'react';
import Home from './pages/Home';
import HiddenAdmin, { trackSession } from './components/HiddenAdmin';

export default function App() {
  useEffect(() => {
    trackSession().catch(() => {});
  }, []);

  return (
    <>
      <Home />
      <HiddenAdmin />
    </>
  );
}
