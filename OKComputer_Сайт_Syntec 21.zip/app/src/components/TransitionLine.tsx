export default function TransitionLine({ color = '#FF0000' }: { color?: string }) {
  return <div className="h-px w-full max-w-[600px] mx-auto" style={{ backgroundColor: color + '30' }} />;
}
