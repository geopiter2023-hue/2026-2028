import type { ReactNode } from 'react';

export interface Role {
  title: string;
  count?: number;
  subtitle?: string;
  onClick?: () => void;
}

interface Props {
  id: string;
  title: string;
  director: string;
  roles: Role[];
  accentColor?: string;
  icon: ReactNode;
  index: number;
}

export default function DepartmentCard({ id, title, director, roles, accentColor = '#CC0000', icon, index }: Props) {
  const total = roles.reduce((s, r) => s + (r.count || 0), 0);
  return (
    <section id={id} className="relative min-h-screen flex items-center justify-center py-16 px-4 bg-white">
      <div className="relative w-full max-w-[1100px] border border-gray-200 bg-white p-6 lg:p-12 shadow-sm">
        <div className="absolute -top-3 -left-3 lg:-top-4 lg:-left-4 w-10 h-10 lg:w-14 lg:h-14 flex items-center justify-center font-oswald font-bold text-white text-base lg:text-lg" style={{ backgroundColor: accentColor }}>
          {String(index + 1).padStart(2, '0')}
        </div>
        <div className="flex flex-col lg:flex-row lg:justify-between gap-4 mb-8 mt-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 flex items-center justify-center border" style={{ borderColor: accentColor + '40', backgroundColor: accentColor + '10' }}>{icon}</div>
              <h2 className="font-oswald font-bold text-4xl lg:text-6xl text-black tracking-tight">{title}</h2>
            </div>
            <p className="text-sm text-gray-500 pl-[52px]">{director}</p>
          </div>
          {total > 0 && (
            <div className="text-center lg:text-right">
              <span className="font-oswald font-bold text-6xl lg:text-8xl" style={{ color: accentColor }}>{total}</span>
              <p className="text-xs text-gray-400 uppercase">человек в отделе</p>
            </div>
          )}
        </div>
        <div className="h-px w-full mb-8" style={{ backgroundColor: accentColor + '30' }} />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {roles.map((r, i) => (
            <div key={i} onClick={r.onClick} className={`group relative p-4 border border-gray-100 bg-gray-50/50 ${r.onClick ? 'cursor-pointer hover:border-red-300' : ''}`}>
              <div className="flex justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className={`font-semibold text-sm ${r.onClick ? 'hover:text-red-600' : ''}`}>{r.title}</h4>
                    {r.onClick && <span className="opacity-0 group-hover:opacity-100 text-red-500 text-xs">&#x2192;</span>}
                  </div>
                  {r.subtitle && <p className="text-xs text-gray-400 mt-0.5">{r.subtitle}</p>}
                </div>
                {r.count && <span className="font-oswald font-bold text-xl flex-shrink-0" style={{ color: accentColor }}>{r.count}</span>}
              </div>
              <div className="absolute bottom-0 left-0 h-0.5 w-0 group-hover:w-full transition-all duration-500" style={{ backgroundColor: r.onClick ? '#CC0000' : accentColor }} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
