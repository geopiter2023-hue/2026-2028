interface Props { roleKey: string | null; onClose: () => void; }

const data: Record<string, { title: string; kpis: string[]; extra?: string[]; focus: string; why: string; dashboard: string; motivation: { type: string; period: string; desc: string } }> = {
  regional: { title: 'Региональный директор', kpis: ['Объём продаж по региону', 'Картина успеха', 'Шахматка по продуктам'], focus: 'Бонус клуб — подключение клиентов ежемесячно', why: 'Клиент мотивирован, заказы идут дистрибутору', dashboard: 'Продажи, Бонус Клуб, мерчендайзинг', motivation: { type: 'Годовая премия', period: '1 раз в год', desc: 'Выплата годовой премии по результатам выполнения годового плана продаж и развития региона.' } },
  manager: { title: 'Территориальный менеджер', kpis: ['Объём продаж по территории', 'Картина успеха', 'Шахматка по продуктам'], extra: ['Обучение ТП и совместные аудиты', 'План развития подчинённых', 'EasyMerch — обратная связь'], focus: 'Бонус клуб — подключение клиентов ежемесячно', why: 'Точка заинтересована, заказы через дистрибьютора', dashboard: 'Продажи, визиты ТП, EasyMerch, обучение', motivation: { type: 'Квартальная премия', period: '4 раза в год', desc: 'Выплата квартальной премии по результатам выполнения плана продаж и развития команды.' } },
  representative: { title: 'Торговый представитель', kpis: ['Объём заказов с ТТ', 'Картина успеха', 'Шахматка по продуктам'], extra: ['План развития территории', 'Рейтинг эффективности'], focus: 'Бонус клуб — подключение клиентов ежемесячно', why: 'Покупатель мотивирован, точка делает больший заказ', dashboard: 'Продажи, визиты, шахматка, рейтинг', motivation: { type: 'Ежемесячная премия', period: '12 раз в год', desc: 'Выплата ежемесячной премии по результатам выполнения плана продаж и показателей эффективности.' } },
};

export default function B2CKPIModal({ roleKey, onClose }: Props) {
  const role = roleKey ? data[roleKey] : null;
  if (!role) return null;
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4" style={{ backgroundColor: 'rgba(0,0,0,0.6)' }} onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="w-full max-w-[600px] max-h-[85vh] overflow-y-auto bg-white shadow-2xl p-6">
        <div className="flex items-center justify-between mb-4 pb-4 border-b border-gray-200">
          <h3 className="font-oswald font-bold text-xl text-black">{role.title}</h3>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-black hover:bg-gray-100 rounded-full transition-all">&#x2715;</button>
        </div>

        <div className="mb-4">
          <h4 className="font-oswald font-bold text-sm text-red-600 uppercase mb-2">&#x1F3AF; Главные показатели</h4>
          {role.kpis.map((k, i) => <div key={i} className="flex items-center gap-3 p-3 mb-2 bg-gray-50 border-l-4 border-red-500"><span className="text-red-500 font-bold">{String(i+1).padStart(2,'0')}</span><span className="text-sm text-black">{k}</span></div>)}
        </div>

        {role.extra && <div className="mb-4">
          <h4 className="font-oswald font-bold text-sm text-gray-500 uppercase mb-2">&#x2795; Доп. KPI</h4>
          {role.extra.map((k, i) => <div key={i} className="p-3 mb-2 bg-gray-50 text-sm">{k}</div>)}
        </div>}

        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
          <h4 className="font-oswald font-bold text-sm text-red-600 uppercase mb-1">&#x1F381; Фокусный показатель</h4>
          <p className="text-sm text-black font-medium">{role.focus}</p>
        </div>

        <div className="mb-4 p-4 border-l-4 border-red-600 bg-gray-50 rounded-r-lg">
          <h4 className="font-oswald font-bold text-sm text-red-600 uppercase mb-1">&#x27A1; Почему это важно</h4>
          <p className="text-sm text-gray-600">{role.why}</p>
        </div>

        <div className="mb-6 p-4 bg-gray-50 rounded-lg">
          <h4 className="font-oswald font-bold text-sm text-black uppercase mb-1">&#x1F4CA; Ежедневный дашборд</h4>
          <p className="text-sm text-gray-600">{role.dashboard}</p>
        </div>

        {/* ОПЛАТА РЕЗУЛЬТАТА — в самом низу, перед кнопкой */}
        <div className="mb-6 p-5 bg-green-50 border border-green-300 rounded-lg">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xl">&#x1F4B0;</span>
            <h4 className="font-oswald font-bold text-base text-green-800 uppercase tracking-wider">ОПЛАТА РЕЗУЛЬТАТА</h4>
          </div>
          <div className="flex items-center gap-2 mb-2">
            <span className="px-3 py-1 bg-green-600 text-white text-xs font-bold uppercase rounded">{role.motivation.type}</span>
            <span className="px-2 py-1 bg-green-200 text-green-800 text-[10px] font-bold uppercase rounded">{role.motivation.period}</span>
          </div>
          <p className="text-sm text-gray-700 leading-relaxed">{role.motivation.desc}</p>
          <p className="text-xs text-green-600 mt-2 font-medium">Выплата напрямую зависит от достижения KPI</p>
        </div>

        <button onClick={onClose} className="w-full py-3 bg-red-600 hover:bg-red-700 text-white font-medium text-sm rounded-lg transition-colors">Закрыть</button>
      </div>
    </div>
  );
}
