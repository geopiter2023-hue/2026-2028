import DepartmentCard from '../components/DepartmentCard';
export default function CTOSection() { return <DepartmentCard id="sto" title="СТО" director="Директор СТО Россия" accentColor="#005f7f" icon={<span className="text-xl">&#x1F527;</span>} index={2} roles={[{ title: 'Региональные директора', count: 4, subtitle: 'Станции технического обслуживания' }]} />; }
