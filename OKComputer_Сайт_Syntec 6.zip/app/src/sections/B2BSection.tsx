import DepartmentCard from '../components/DepartmentCard';
export default function B2BSection() { return <DepartmentCard id="b2b" title="B2B" director="Директор B2B Россия" accentColor="#8B3A00" icon={<span className="text-xl">&#x1F3E2;</span>} index={1} roles={[{ title: 'Региональные директора', count: 5, subtitle: 'Корпоративные продажи' }]} />; }
