import Navigation from '../components/Navigation';
import HeroSection from '../sections/HeroSection';
import B2CSection from '../sections/B2CSection';
import B2CToolsSection from '../sections/B2CToolsSection';
import B2CAnalyticsSection from '../sections/B2CAnalyticsSection';
import B2CControlSection from '../sections/B2CControlSection';
import B2CMarketSection from '../sections/B2CMarketSection';
import TrainersSection from '../sections/TrainersSection';
import B2BSection from '../sections/B2BSection';
import CTOSection from '../sections/CTOSection';
import OnlineSection from '../sections/OnlineSection';
import NetworksSection from '../sections/NetworksSection';
import ExportSection from '../sections/ExportSection';
import DistributorSection from '../sections/DistributorSection';
import BrandsSection from '../sections/BrandsSection';
import StatsSection from '../sections/StatsSection';
import AITellSellSection from '../sections/AITellSellSection';
import FooterSection from '../sections/FooterSection';
import TransitionLine from '../components/TransitionLine';

export default function Home() {
  return (
    <div className="relative bg-white min-h-screen">
      <Navigation />
      <HeroSection />
      <B2CSection />
      <B2CToolsSection />
      <B2CAnalyticsSection />
      <B2CControlSection />
      <B2CMarketSection />
      <TrainersSection />
      <TransitionLine color="#b3cc00" />
      <B2BSection />
      <TransitionLine color="#b3cc00" />
      <CTOSection />
      <TransitionLine color="#cc5200" />
      <OnlineSection />
      <TransitionLine color="#0099cc" />
      <NetworksSection />
      <TransitionLine color="#cc3377" />
      <ExportSection />
      <TransitionLine color="#00b377" />
      <DistributorSection />
      <TransitionLine color="#9933cc" />
      <BrandsSection />
      <TransitionLine color="#FF0000" />
      <StatsSection />
      <AITellSellSection />
      <FooterSection />
    </div>
  );
}
