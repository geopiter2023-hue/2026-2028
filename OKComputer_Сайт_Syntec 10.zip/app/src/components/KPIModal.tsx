interface Props { dept: string; roleKey: string | null; onClose: () => void; }

const db: Record<string, Record<string, { title: string; kpis: string[]; extra?: string[]; focus: string; why: string; dashboard: string; motivation: { type: string; period: string; desc: string } }>> = {
  b2c: {
    regional: { title: 'РЕГИОНАЛЬНЫЙ ДИРЕКТОР', kpis: ['Объём продаж по региону', 'Картина успеха', 'Шахматка по продуктам'], focus: 'Бонус клуб — подключение клиентов ежемесячно', why: 'Клиент мотивирован, заказы идут дистрибутору', dashboard: 'Продажи, Бонус Клуб, мерчендайзинг', motivation: { type: 'Годовая премия', period: '1 раз в год', desc: 'Выплата годовой премии по результатам выполнения годового плана продаж и развития региона.' } },
    manager: { title: 'ТЕРРИТОРИАЛЬНЫЙ МЕНЕДЖЕР', kpis: ['Объём продаж по территории', 'Картина успеха', 'Шахматка по продуктам'], extra: ['Обучение ТП и совместные аудиты', 'План развития подчинённых', 'EasyMerch — обратная связь'], focus: 'Бонус клуб — подключение клиентов ежемесячно', why: 'Точка заинтересована, заказы через дистрибьютора', dashboard: 'Продажи, визиты ТП, EasyMerch, обучение', motivation: { type: 'Квартальная премия', period: '4 раза в год', desc: 'Выплата квартальной премии по результатам выполнения плана продаж и развития команды.' } },
    representative: { title: 'ТОРГОВЫЙ ПРЕДСТАВИТЕЛЬ', kpis: ['Объём заказов с ТТ', 'Картина успеха', 'Шахматка по продуктам'], extra: ['План развития территории', 'Рейтинг эффективности'], focus: 'Бонус клуб — подключение клиентов ежемесячно', why: 'Покупатель мотивирован, точка делает больший заказ', dashboard: 'Продажи, визиты, шахматка, рейтинг', motivation: { type: 'Ежемесячная премия', period: '12 раз в год', desc: 'Выплата ежемесячной премии по результатам выполнения плана продаж и показателей эффективности.' } },
  },
  b2b: {
    director: { title: 'ДИРЕКТОР B2B', kpis: ['Объём B2B-продаж', 'Развитие ключевых клиентов', 'Конверсия в сделку'], focus: 'Увеличение среднего чека с клиента', why: 'B2B клиент даёт стабильный объём с минимальными затратами', dashboard: 'Продажи, воронка сделок, активность КП', motivation: { type: 'Годовая премия', period: '1 раз в год', desc: 'Выплата годовой премии по результатам выполнения плана B2B-продаж и развития клиентской базы.' } },
    km: { title: 'КЛИЕНТСКИЙ МЕНЕДЖЕР', kpis: ['Объём продаж по клиентам', 'Удержание клиентов', 'Кросс-продажи'], extra: ['Визиты и встречи с клиентами', 'Отчётность по взаимодействию'], focus: 'Рост среднего чека на 15% с каждого клиента', why: 'Удержание существующего клиента дешевле привлечения нового', dashboard: 'Продажи по клиентам, визиты, план встреч', motivation: { type: 'Квартальная премия', period: '4 раза в год', desc: 'Выплата квартальной премии по результатам выполнения плана продаж и удержания клиентов.' } },
    kp: { title: 'КЛЮЧЕВОЙ ПЕРЕГОВОРЩИК', kpis: ['Количество закрытых сделок', 'Сумма сделок', 'Конверсия первичных контактов'], extra: ['Срок закрытия сделки', 'Успешность переговоров'], focus: 'Закрытие крупных сделок с оборотом от 10 млн ₽', why: 'Каждая крупная сделка формирует базу на год вперёд', dashboard: 'Воронка продаж, сделки, переговоры', motivation: { type: 'Ежемесячная премия', period: '12 раз в год', desc: 'Выплата ежемесячной премии по результатам закрытия сделок и выполнения плана.' } },
  },
  cto: {
    rd: { title: 'РЕГИОНАЛЬНЫЙ ДИРЕКТОР СТО', kpis: ['Объём продаж по региону СТО', 'Количество активных СТО', 'Конверсия визитов в заказы'], focus: 'Рост среднего чека на СТО на 20%', why: 'СТО — лояльный канал с регулярным спросом', dashboard: 'Продажи, активные СТО, визиты, заказы', motivation: { type: 'Годовая премия', period: '1 раз в год', desc: 'Выплата годовой премии по результатам выполнения плана продаж и развития сети СТО.' } },
    mp: { title: 'МЕНЕДЖЕР ПО СТО', kpis: ['Объём продаж по закреплённым СТО', 'Количество визитов', 'Конверсия визитов в заказы'], extra: ['Удержание СТО в активе', 'Обучение персонала СТО'], focus: 'Подключение новых СТО к программе лояльности', why: 'Новое СТО даёт стабильный ежемесячный объём', dashboard: 'Продажи, визиты, конверсия, новые СТО', motivation: { type: 'Ежемесячная премия', period: '12 раз в год', desc: 'Выплата ежемесячной премии по результатам выполнения плана продаж и развития СТО.' } },
  },
  online: {
    director: { title: 'ДИРЕКТОР ОНЛАЙН-ПРОДАЖ', kpis: ['Объём онлайн-продаж', 'Количество подключённых магазинов', 'Рост выручки по магазинам'], focus: 'Запуск подборщика на 50+ магазинах', why: 'Подборщик повышает конверсию на 30%', dashboard: 'Онлайн-продажи, магазины, маркетплейсы', motivation: { type: 'Годовая премия', period: '1 раз в год', desc: 'Выплата годовой премии по результатам развития онлайн-канала и роста продаж.' } },
    websites: { title: 'МАНАГЕР ИНТЕРНЕТ-МАГАЗИНОВ', kpis: ['Количество подключённых магазинов', 'Наполнение ассортимента 95%+', 'Контроль цен 90%+'], extra: ['Запуск подборщика на сайтах', 'API-интеграция'], focus: 'Ежемесячный прирост новых магазинов 10%+', why: 'Каждый новый магазин — новый канал продаж', dashboard: 'Магазины, ассортимент, цены, API', motivation: { type: 'Квартальная премия', period: '4 раза в год', desc: 'Выплата квартальной премии по результатам подключения магазинов и роста онлайн-продаж.' } },
    marketplaces: { title: 'МАНАГЕР МАРКЕТПЛЕЙСОВ', kpis: ['Выручка с OZON, WB, Яндекс', 'Контроль цен на площадках', 'Рейтинг и отзывы товаров'], extra: ['Продвижение на площадках', 'Актуальность карточек товаров'], focus: 'Рост выручки с маркетплейсов на 20% в квартал', why: 'Маркетплейсы — быстрорастущий канал с миллионами покупателей', dashboard: 'Выручка, цены, рейтинг, акции', motivation: { type: 'Квартальная премия', period: '4 раза в год', desc: 'Выплата квартальной премии по результатам продаж через маркетплейсы.' } },
  },
  networks: {
    manager: { title: 'МЕНЕДЖЕР ПО СЕТЯМ', kpis: ['Доля полки в сети', 'Соблюдение контрактных условий', 'Уровень соблюдений'], extra: ['Листинг SKU 90%+', 'Рост выручки по сети 10%+'], focus: 'Согласование листинга SKU в новых сетях', why: 'Попадание в листинг = гарантированные продажи', dashboard: 'Доля полки, контракты, листинг, продажи', motivation: { type: 'Квартальная премия', period: '4 раза в год', desc: 'Выплата квартальной премии по результатам соблюдения контрактов и роста доли полки.' } },
  },
  export: {
    rd: { title: 'РЕГИОНАЛЬНЫЙ ДИРЕКТОР ЭКСПОРТ', kpis: ['Объём экспортных продаж', 'Развитие дистрибьюторов в стране', 'Конверсия входящих запросов'], focus: 'Открытие новых рынков сбыта', why: 'Каждый новый рынок диверсифицирует риски', dashboard: 'Продажи, дистрибьюторы, запросы, логистика', motivation: { type: 'Годовая премия', period: '1 раз в год', desc: 'Выплата годовой премии по результатам развития экспортных продаж.' } },
    manager: { title: 'МЕНЕДЖЕР ПО ЭКСПОРТУ', kpis: ['Объём продаж по стране', 'Количество активных клиентов', 'Выполнение плана отгрузок'], extra: ['Таможенное сопровождение', 'Документооборот'], focus: 'Увеличение частоты заказов с существующих рынков', why: 'Повторные заказы дешевле новых', dashboard: 'Продажи, клиенты, отгрузки, документы', motivation: { type: 'Квартальная премия', period: '4 раза в год', desc: 'Выплата квартальной премии по результатам выполнения плана продаж в стране.' } },
  },
  distributors: {
    dd: { title: 'ДИРЕКТОР ПО ДИСТРИБЬЮТОРАМ', kpis: ['Объём продаж через дистрибьюторов', 'Развитие дистрибьюторской сети', 'Качество ассортимента на складах'], focus: 'Рост продаж через дистрибьюторов на 15%', why: 'Дистрибьюторы расширяют охват без увеличения штата', dashboard: 'Продажи, дистрибьюторы, ассортимент, BDM', motivation: { type: 'Годовая премия', period: '1 раз в год', desc: 'Выплата годовой премии по результатам развития дистрибьюторской сети.' } },
    rm: { title: 'РЕГИОНАЛЬНЫЙ МЕНЕДЖЕР ДИСТРИБЬЮТОРОВ', kpis: ['Объём продаж по региону', 'Количество активных BDM', 'Качество работы BDM'], extra: ['Развитие новых дистрибьюторов', 'Аудиты рынка'], focus: 'Подключение новых дистрибьюторов в регионе', why: 'Каждый новый дистрибьютор = +30 точек охвата', dashboard: 'Продажи, BDM, аудиты, новые дистрибьюторы', motivation: { type: 'Квартальная премия', period: '4 раза в год', desc: 'Выплата квартальной премии по результатам развития дистрибьюторов в регионе.' } },
    bdm: { title: 'BDM (БИЗНЕС-ДЕВЕЛОПМЕНТ МЕНЕДЖЕР)', kpis: ['Объём заказов с точек', 'Подключение к Бонус Клубу', 'Количество новых точек'], extra: ['Аудиты качества', 'Обучение ТП дистрибьютора'], focus: 'Формирование заказа и отправка дистрибьютору', why: 'Заказ через дистрибьютора = рост для всех', dashboard: 'Заказы, Бонус Клуб, новые точки, аудиты', motivation: { type: 'Ежемесячная премия', period: '12 раз в год', desc: 'Выплата ежемесячной премии по результатам выполнения плана заказов и подключения точек.' } },
  },
};

export default function KPIModal({ dept, roleKey, onClose }: Props) {
  const role = roleKey && db[dept]?.[roleKey] ? db[dept][roleKey] : null;
  if (!role) return null;
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4" style={{ backgroundColor: 'rgba(0,0,0,0.6)' }} onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="w-full max-w-[600px] max-h-[85vh] overflow-y-auto bg-white shadow-2xl p-6">
        <div className="flex items-center justify-between mb-4 pb-4 border-b border-gray-200">
          <h3 className="font-oswald font-bold text-xl text-black">{role.title}</h3>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-black hover:bg-gray-100 rounded-full transition-all">&#x2715;</button>
        </div>
        <div className="mb-4">
          <h4 className="font-oswald font-bold text-sm text-red-600 uppercase mb-2">&#x1F3AF; Главные показатели</h4>
          {role.kpis.map((k, i) => <div key={i} className="flex items-center gap-3 p-3 mb-2 bg-gray-50 border-l-4 border-red-500"><span className="text-red-500 font-bold">{String(i+1).padStart(2,'0')}</span><span className="text-sm text-black">{k}</span></div>)}
        </div>
        {role.extra && <div className="mb-4">
          <h4 className="font-oswald font-bold text-sm text-gray-500 uppercase mb-2">&#x2795; Доп. KPI</h4>
          {role.extra.map((k, i) => <div key={i} className="p-3 mb-2 bg-gray-50 text-sm">{k}</div>)}
        </div>}
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
          <h4 className="font-oswald font-bold text-sm text-red-600 uppercase mb-1">&#x1F381; Фокусный показатель</h4>
          <p className="text-sm text-black font-medium">{role.focus}</p>
        </div>
        <div className="mb-4 p-4 border-l-4 border-red-600 bg-gray-50 rounded-r-lg">
          <h4 className="font-oswald font-bold text-sm text-red-600 uppercase mb-1">&#x27A1; Почему это важно</h4>
          <p className="text-sm text-gray-600">{role.why}</p>
        </div>
        <div className="mb-6 p-4 bg-gray-50 rounded-lg">
          <h4 className="font-oswald font-bold text-sm text-black uppercase mb-1">&#x1F4CA; Ежедневный дашборд</h4>
          <p className="text-sm text-gray-600">{role.dashboard}</p>
        </div>
        <div className="mb-6 p-5 bg-green-50 border border-green-300 rounded-lg">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xl">&#x1F4B0;</span>
            <h4 className="font-oswald font-bold text-base text-green-800 uppercase tracking-wider">ОПЛАТА РЕЗУЛЬТАТА</h4>
          </div>
          <div className="flex items-center gap-2 mb-2">
            <span className="px-3 py-1 bg-green-600 text-white text-xs font-bold uppercase rounded">{role.motivation.type}</span>
            <span className="px-2 py-1 bg-green-200 text-green-800 text-[10px] font-bold uppercase rounded">{role.motivation.period}</span>
          </div>
          <p className="text-sm text-gray-700 leading-relaxed">{role.motivation.desc}</p>
          <p className="text-xs text-green-600 mt-2 font-medium">Выплата напрямую зависит от достижения KPI</p>
        </div>
        <button onClick={onClose} className="w-full py-3 bg-red-600 hover:bg-red-700 text-white font-medium text-sm rounded-lg transition-colors">Закрыть</button>
      </div>
    </div>
  );
}
