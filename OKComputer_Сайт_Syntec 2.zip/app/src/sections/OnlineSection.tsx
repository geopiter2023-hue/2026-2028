const directions = [
  {
    num: '01',
    emoji: '\u{1F6E0}',
    title: 'Наполнение магазинов',
    color: '#006b4f',
    details: [
      'Полное наполнение интернет-магазинов товарами брендов SINTEC, TAKAYAMA, MIRAX, ROLF, Автокосметика SINTEC',
      'Формирование актуального ассортимента: подбор SKU под формат и аудиторию каждого конкретного магазина',
      'Профессиональные описания товаров: технические характеристики, применимость, преимущества, фото и видео-контент',
      'Контроль цен в реальном времени: система мониторит цены конкурентов и корректирует рекомендованные розничные цены',
      'Автоматическое обновление остатков: складские запасы синхронизируются через API — нет ситуаций «товар закончился»',
    ],
  },
  {
    num: '02',
    emoji: '\u{1F50D}',
    title: 'Подборщик на сайтах',
    color: '#007a5e',
    details: [
      'Запуск умного подборщика масел и автотоваров на сайтах интернет-магазинов по марке, модели и году автомобиля',
      'Интеграция подборщика через API: клиент вводит параметры авто — система предлагает подходящие продукты SINTEC',
      'Повышение конверсии: подборщик помогает клиенту быстро найти нужный товар без изучения всего каталога',
      'Кросс-продажи: система рекомендует сопутствующие товары — антифриз, тормозная жидкость, автокосметика',
      'Аналитика использования: отслеживается частота использования подборщика и конверсия в заказ',
    ],
  },
  {
    num: '03',
    emoji: '\u{1F4E1}',
    title: 'Парсинг рынка & API-интеграция',
    color: '#008970',
    details: [
      'Отдельная система парсинга рынка интернет-магазинов: мониторинг 60 000+ магазинов по данным Автостат',
      'Контроль в реальном времени: система отслеживает наличие брендов SINTEC, цены, описания, позиции в поиске',
      'Автоматическое формирование предложений для клиентов: если магазин не работает с SINTEC — система генерирует персональное коммерческое предложение',
      'API-интеграция с площадками: прямая связь с каталогами магазинов — обновление ассортимента, цен и остатков без ручной работы',
      'Клиент не испытывает дискомфорта: бренды SINTEC всегда в наличии с актуальными ценами и правильным описанием',
    ],
  },
  {
    num: '04',
    emoji: '\u{1F3AF}',
    title: 'KPI сотрудников онлайн',
    color: '#009982',
    details: [
      'Количество подключённых интернет-магазинов в месяц: каждый менеджер имеет план по привлечению новых магазинов',
      'Рост выручки по ведомым магазинам: ежемесячный прирост оборота не менее 10% на каждый магазин',
      'Наполнение ассортимента: процент заполненности каталога магазина товарами SINTEC — целевой показатель 95%+',
      'Контроль цен: процент магазинов с рекомендованными ценами — целевой показатель 90%+',
      'Запуск подборщика: количество магазинов с активным подборщиком — KPI на квартал',
    ],
  },
  {
    num: '05',
    emoji: '\u{1F5FA}',
    title: 'Яндекс.Карты & Выкладка',
    color: '#00a894',
    details: [
      'Настройка выкладки продукта SINTEC на карточках торговых точек в Яндекс.Картах',
      'Покупатель видит: ассортимент SINTEC в конкретном магазине, цены, наличие, фото выкладки',
      'Помогает найти товар: клиент ищет «масло SINTEC рядом» — видит точки с продуктом на карте',
      'Увеличение трафика в офлайн-магазины: онлайн-видимость конвертируется в посещения торговых точек',
      'Контроль данных: менеджер онлайн обновляет информацию о точках — актуальные часы, адрес, телефон, фото',
    ],
  },
];

export default function OnlineSection() {
  return (
    <section id="online" className="py-16 px-4 bg-white">
      <div className="max-w-[900px] mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 border border-green-200 bg-green-50">
            <span className="text-xs font-medium text-green-700 uppercase tracking-widest">&#x1F310; Онлайн-направление</span>
          </div>
          <h2 className="font-oswald font-bold text-3xl lg:text-4xl text-black mb-2">60 000+ ИНТЕРНЕТ-МАГАЗИНОВ</h2>
          <p className="text-sm text-gray-500 max-w-lg mx-auto mb-2">Российский рынок по данным Автостат</p>
          <p className="text-sm text-gray-400">Основное направление — развитие интернет-магазинов с полной автоматизацией</p>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-8 max-w-[600px] mx-auto">
          {[
            { val: '7', label: 'Сотрудников отдела', color: '#006b4f' },
            { val: '60K+', label: 'Интернет-магазинов', color: '#008970' },
            { val: '100%', label: 'Автоматизация', color: '#006b4f' },
            { val: 'API', label: 'Интеграция', color: '#008970' },
          ].map((s, i) => (
            <div key={i} className="p-3 border border-gray-200 bg-gray-50 text-center">
              <span className="font-oswald font-bold text-2xl" style={{ color: s.color }}>{s.val}</span>
              <p className="text-[10px] text-gray-400 uppercase tracking-wider mt-1">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="h-px w-full bg-green-200 mb-6" />

        {/* Team */}
        <div className="flex items-center gap-3 mb-6 p-3 border border-gray-200 bg-gray-50 max-w-[500px] mx-auto">
          <span className="text-2xl">&#x1F310;</span>
          <div>
            <h3 className="font-oswald font-bold text-sm text-black uppercase">ОТДЕЛ ОНЛАЙН-ПРОДАЖ</h3>
            <p className="text-xs text-gray-400">Директор онлайн-продаж Россия</p>
          </div>
          <div className="ml-auto text-right">
            <span className="font-oswald font-bold text-xl text-green-700">7</span>
            <p className="text-[10px] text-gray-400 uppercase">человек</p>
          </div>
        </div>

        {/* Directions accordion */}
        <div className="space-y-3">
          {directions.map((d, i) => (
            <details key={i} className="group border border-gray-200 bg-gray-50 cursor-pointer">
              <summary className="flex items-center gap-3 p-4 list-none">
                <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center font-oswald font-bold text-white text-sm" style={{ backgroundColor: d.color }}>
                  {d.num}
                </div>
                <span className="text-2xl flex-shrink-0">{d.emoji}</span>
                <h3 className="font-oswald font-bold text-base text-black uppercase flex-1">{d.title}</h3>
                <span className="text-gray-400 group-open:rotate-180 transition-transform text-sm">&#x25BC;</span>
              </summary>
              <div className="px-4 pb-4">
                <div className="h-px w-full bg-gray-200 mb-3 ml-16" />
                <ul className="space-y-2 ml-16">
                  {d.details.map((item, j) => (
                    <li key={j} className="flex items-start gap-2 text-sm text-gray-600">
                      <span style={{ color: d.color }}>&#x2714;</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </details>
          ))}
        </div>

        {/* Bottom principle */}
        <div className="mt-8 p-4 bg-green-50 border border-green-200 rounded-lg text-center">
          <p className="text-sm text-gray-700">
            <span className="font-semibold" style={{ color: '#006b4f' }}>Принцип:</span> Парсинг рынка → Автоматическое предложение → API-интеграция → Наполнение → Подборщик → Рост продаж. Ручная работа сведена к нулю.
          </p>
        </div>
      </div>
    </section>
  );
}
