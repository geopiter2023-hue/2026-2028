import path from "path"
import react from "@vitejs/plugin-react"
import { defineConfig } from "vite"
import { inspectAttr } from 'kimi-plugin-inspect-react'
import devServer from "@hono/vite-dev-server"

// https://vite.dev/config/
export default defineConfig({
  base: '/',
  plugins: [
    inspectAttr(),
    react(),
    devServer({
      entry: "./api/boot.ts",
      exclude: [
        /.*\.tsx?$/,
        /.*\.jsx?$/,
        /.*\.css$/,
        /.*\.svg$/,
        /.*\.png$/,
        /.*\.json$/,
        /^\/@fs/,
        /^\/@vite/,
        /^\/@react-refresh/,
        /^\/favicon\.ico$/,
        /^\/robots\.txt$/,
        /^\/sitemap\.xml$/,
      ],
    }),
  ],
  server: {
    port: 3000,
  },
  build: {
    outDir: "dist/client",
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
      "@db": path.resolve(__dirname, "./db"),
      "@contracts": path.resolve(__dirname, "./contracts"),
    },
  },
  envDir: ".",
});
