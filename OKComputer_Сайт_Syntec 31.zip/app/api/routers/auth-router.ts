import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { deviceBindings } from "../../db/schema";
import { eq } from "drizzle-orm";

const VALID_PASSWORDS = ["7771", "7773", "0334"];

export const authRouter = createRouter({
  checkPassword: publicQuery
    .input(z.object({
      password: z.string(),
      deviceFingerprint: z.string(),
    }))
    .mutation(async ({ input }) => {
      const { password, deviceFingerprint } = input;

      if (!VALID_PASSWORDS.includes(password)) {
        return { valid: false as const, bound: false as const, message: "Неверный пароль" };
      }

      const db = getDb();
      const existing = await db
        .select()
        .from(deviceBindings)
        .where(eq(deviceBindings.password, password))
        .limit(1);

      if (existing.length === 0) {
        return { valid: true as const, bound: false as const, message: "OK" };
      }

      const binding = existing[0];
      if (binding.deviceFingerprint === deviceFingerprint) {
        return { valid: true as const, bound: true as const, ownDevice: true as const, message: "OK" };
      }

      return {
        valid: false as const,
        bound: true as const,
        ownDevice: false as const,
        message: "Информация конфиденциальна и не подлежит передаче другим лицам без подтверждения администратора",
      };
    }),

  bindPassword: publicQuery
    .input(z.object({
      password: z.string(),
      deviceFingerprint: z.string(),
    }))
    .mutation(async ({ input }) => {
      const { password, deviceFingerprint } = input;

      if (!VALID_PASSWORDS.includes(password)) {
        return { success: false, message: "Неверный пароль" };
      }

      const db = getDb();
      await db.delete(deviceBindings).where(eq(deviceBindings.password, password));
      await db.insert(deviceBindings).values({ password, deviceFingerprint });

      return { success: true, message: "Привязка создана" };
    }),

  unbindPassword: publicQuery
    .input(z.object({ password: z.string() }))
    .mutation(async ({ input }) => {
      const { password } = input;

      if (!VALID_PASSWORDS.includes(password)) {
        return { success: false, message: "Неверный пароль" };
      }

      const db = getDb();
      await db.delete(deviceBindings).where(eq(deviceBindings.password, password));

      return { success: true, message: "Пароль разблокирован" };
    }),

  listBindings: publicQuery.query(async () => {
    const db = getDb();
    const all = await db.select().from(deviceBindings);
    return all.map((b) => ({
      password: b.password,
      deviceFingerprint: b.deviceFingerprint,
      createdAt: b.createdAt,
    }));
  }),
});
