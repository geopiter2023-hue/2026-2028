import {
  mysqlTable,
  serial,
  varchar,
  timestamp,
} from "drizzle-orm/mysql-core";

export const deviceBindings = mysqlTable("device_bindings", {
  id: serial("id").primaryKey(),
  password: varchar("password", { length: 10 }).notNull(),
  deviceFingerprint: varchar("device_fingerprint", { length: 255 }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
