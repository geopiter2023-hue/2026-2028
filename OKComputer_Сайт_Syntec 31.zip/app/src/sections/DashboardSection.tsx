import { useState, useRef } from 'react';

interface Dept {
  name: string;
  color: string;
  headcount: number;
  kpi: { label: string; value: string; target: string; progress: number; details: string[] }[];
}

interface Task {
  id: string;
  dept: string;
  description: string;
  deadline: string;
  status: 'done' | 'progress' | 'risk';
  owner: string;
}

const departments: Dept[] = [
  {
    name: 'B2C', color: '#CC0000', headcount: 159,
    kpi: [
      { label: 'Объём продаж', value: '1.2 млрд ₽', target: '1.5 млрд ₽', progress: 80, details: ['Ежемесячный прирост не менее 10%', 'Контроль через CRM ежедневно', 'Разбивка по регионам и ТМ'] },
      { label: 'Доля рынка', value: '8.5%', target: '10-15%', progress: 57, details: ['Анализ Автостат ежеквартально', 'Сравнение с топ-5 конкурентами', 'Фокус на регионах с потенциалом'] },
      { label: 'Торговые точки в базе', value: '45 000', target: '60 000', progress: 75, details: ['Сегментация по потенциалу', 'Обновление данных ежемесячно', 'Приоритет: крупные города'] },
      { label: 'Бонус Клуб подключено', value: '12 000', target: '20 000', progress: 60, details: ['Каждый ТП имеет план подключения', 'Мотивация через скидки и бонусы', 'Отслеживание активности'] },
      { label: 'Визитов в день', value: '850', target: '1 000', progress: 85, details: ['GPS-контроль маршрутов', 'Минимум 5 визитов на ТП', 'Отчётность через CRM'] },
      { label: 'Аудиты через EasyMerch', value: '92%', target: '95%', progress: 97, details: ['Фотоотчёты с каждой точки', 'Сверка с эталонной выкладкой', 'Исправление в течение 48 часов'] },
    ],
  },
  {
    name: 'Онлайн', color: '#006b4f', headcount: 12,
    kpi: [
      { label: 'Выручка онлайн', value: '180 млн ₽', target: '250 млн ₽', progress: 72, details: ['4 менеджера интернет-магазинов', '3 менеджера маркетплейсов', 'API-интеграция с 60 000+ магазинов'] },
      { label: 'Подключено магазинов', value: '2 400', target: '5 000', progress: 48, details: ['Парсинг рынка Автостат', 'Автоматические предложения', 'Контроль через API'] },
      { label: 'Запуск подборщика', value: '28', target: '50', progress: 56, details: ['Подбор по марке/модели авто', 'Интеграция через API', 'Аналитика конверсии'] },
      { label: 'Маркетплейсы выручка', value: '45 млн ₽', target: '80 млн ₽', progress: 56, details: ['OZON, Wildberries, Яндекс Маркет', 'Контроль цен и остатков', 'Продвижение на площадках'] },
      { label: 'Интеграции через API', value: '85%', target: '95%', progress: 89, details: ['Прямая связь с каталогами', 'Автообновление цен и остатков', 'Нет ручной работы'] },
      { label: 'Наполнение ассортимента', value: '91%', target: '95%', progress: 96, details: ['Описания, фото, видео', 'Технические характеристики', 'Актуальные остатки'] },
    ],
  },
  {
    name: 'Дистрибьюторы', color: '#1a2744', headcount: 58,
    kpi: [
      { label: 'Объём через дистр.', value: '420 млн ₽', target: '500 млн ₽', progress: 84, details: ['50 BDM на поле', 'Сегментация Platinum/Gold/Silver/Bronze', 'Совместные выезды с ТП дистрибьютора'] },
      { label: 'BDM активность', value: '85%', target: '90%', progress: 94, details: ['Ежедневные визиты', 'Аудиты качества', 'Обучение через AI тренажёр'] },
      { label: 'Бонус Клуб БДМ', value: '3 200', target: '5 000', progress: 64, details: ['Основной KPI каждого BDM', 'Мотивация точек через бонусы', 'Контроль подключений'] },
      { label: 'Аудиты качества', value: '78%', target: '85%', progress: 92, details: ['EasyMerch проверки', 'Фото выкладки', 'Обратная связь'] },
      { label: 'Новые точки', value: '450', target: '600', progress: 75, details: ['Поиск через аудиты рынка', 'Передача дистрибьютору', 'Контроль первого заказа'] },
      { label: 'Сегментация Platinum', value: '120', target: '200', progress: 60, details: ['Прямое обслуживание ТП SINTEC', 'Полный пакет услуг', 'Приоритет в поставках'] },
    ],
  },
  {
    name: 'Бренды', color: '#6b2c91', headcount: 5,
    kpi: [
      { label: 'Доля рынка SINTEC', value: '12%', target: '15%', progress: 80, details: ['Анализ Nielsen/Автостат', 'Сравнение с конкурентами', 'Фокус на ключевых регионах'] },
      { label: 'Лояльность клиентов (NPS)', value: '72', target: '80+', progress: 90, details: ['Ежеквартальный опрос', 'Обратная связь от клиентов', 'Корректирующие действия'] },
      { label: 'Окупаемость маркетинга (ROMI)', value: '280%', target: '300%', progress: 93, details: ['Отслеживание каждой кампании', 'Сравнение затрат и выручки', 'Оптимизация каналов'] },
      { label: 'Запуск новинок', value: '3', target: '5', progress: 60, details: ['ROLF Black Edition', 'Новые вязкости SINTEC', 'Автокосметика премиум'] },
      { label: 'Снижение контрафакта', value: '15%', target: '5%', progress: 33, details: ['Мониторинг рынка', 'Работа с юристами', 'Проверка поставщиков'] },
      { label: 'Узнаваемость бренда', value: '65%', target: '75%', progress: 87, details: ['Опросы узнаваемости', 'Цифровые метрики', 'PR-упоминания'] },
    ],
  },
  {
    name: 'Магазины ФЛ', color: '#CC0000', headcount: 8,
    kpi: [
      { label: 'Выручка ФЛ', value: '85 млн ₽', target: '+250-400 млн ₽', progress: 34, details: ['Личный кабинет покупателя', 'Подбор по автомобилю', 'Рассрочка от банков-партнёров'] },
      { label: 'Заказов в день', value: '120', target: '300', progress: 40, details: ['Приложение iOS/Android', '15 000+ ПВЗ', 'Доставка день в день'] },
      { label: 'Рассрочка оформлено', value: '450', target: '1 000', progress: 45, details: ['СберБанк, Альфа-Банк, Т-Банк', 'Оформление на сайте', 'Без первоначального взноса'] },
      { label: 'Приложение установок', value: '8 500', target: '20 000', progress: 43, details: ['Сканер VIN-номера', 'Гараж в приложении', 'Push-уведомления'] },
      { label: 'Повторные покупки', value: '35%', target: '50%', progress: 70, details: ['Программа лояльности', 'Кэшбэк баллами', 'Персональные скидки'] },
      { label: 'Средний чек', value: '3 200 ₽', target: '4 500 ₽', progress: 71, details: ['Кросс-продажи', 'Рекомендации по авто', 'Наборы и комплекты'] },
    ],
  },
  {
    name: 'Магазины ЮЛ', color: '#1a2744', headcount: 6,
    kpi: [
      { label: 'Выручка ЮЛ', value: '28 млн ₽', target: '+100 млн ₽', progress: 28, details: ['Долгосрочные контракты 12-24 мес', 'EDI-интеграция', 'Отсрочка до 60 дней'] },
      { label: 'ЮЛ подключено', value: '45', target: '120', progress: 38, details: ['ООО и АО', 'Тендерные закупки', 'Выделенный менеджер'] },
      { label: 'EDI-интеграции', value: '12', target: '30', progress: 40, details: ['Электронный обмен документами', 'Заказы и накладные через API', 'Just-in-Time поставки'] },
      { label: 'Контракты подписано', value: '18', target: '40', progress: 45, details: ['Индивидуальные условия', 'Прогрессивная шкала скидок', 'Эксклюзив для стратегических'] },
      { label: 'NPS ЮЛ', value: '75', target: '80+', progress: 94, details: ['Ежегодный опрос', 'Бизнес-ревью каждый квартал', 'Программа «Стратегический партнёр»'] },
      { label: 'Отсрочка 60 дней', value: '8 клиентов', target: '20', progress: 40, details: ['Положительная кредитная история', 'Гибкая система', 'Факторинг'] },
    ],
  },
];

const tasks: Task[] = [
  { id: 'T001', dept: 'B2C', description: 'Запуск новой сегментации 60 000+ торговых точек', deadline: '2025-12-31', status: 'progress', owner: 'РД B2C' },
  { id: 'T002', dept: 'B2C', description: 'Внедрение автоматического контроля качества визитов', deadline: '2025-11-30', status: 'progress', owner: 'ТМ Полина' },
  { id: 'T003', dept: 'B2C', description: 'Запуск Клуба Легенд для топ-ТП', deadline: '2025-10-15', status: 'done', owner: 'Отдел обучения' },
  { id: 'T004', dept: 'Онлайн', description: 'Интеграция подборщика на 50+ магазинов', deadline: '2025-12-15', status: 'progress', owner: 'Директор онлайн' },
  { id: 'T005', dept: 'Онлайн', description: 'Запуск на Wildberries Premium', deadline: '2025-11-15', status: 'risk', owner: 'Менеджер WB' },
  { id: 'T006', dept: 'Дистрибьюторы', description: 'Автоматическая генерация презентаций для BDM', deadline: '2025-12-01', status: 'progress', owner: 'РМ Север' },
  { id: 'T007', dept: 'Дистрибьюторы', description: 'Обучение 50 BDM через AI тренажёр', deadline: '2025-11-30', status: 'progress', owner: 'Тренеры BDM' },
  { id: 'T008', dept: 'Бренды', description: 'Запуск ROLF Black Edition', deadline: '2026-01-15', status: 'progress', owner: 'Бренд-директор' },
  { id: 'T009', dept: 'Бренды', description: 'Программа борьбы с контрафактом', deadline: '2025-12-31', status: 'risk', owner: 'Юрист' },
  { id: 'T010', dept: 'Магазины ФЛ', description: 'Запуск рассрочки через Т-Банк', deadline: '2025-11-01', status: 'done', owner: 'Менеджер ФЛ' },
  { id: 'T011', dept: 'Магазины ЮЛ', description: 'EDI-интеграция с 10 крупными ЮЛ', deadline: '2025-12-31', status: 'progress', owner: 'Менеджер ЮЛ' },
  { id: 'T012', dept: 'Обучение', description: 'Сертификация 100% ТП по продуктам', deadline: '2025-11-30', status: 'progress', owner: 'Тренер продуктов' },
];

const statusLabels: Record<string, { label: string; color: string }> = {
  done: { label: '✅ Выполнено', color: 'bg-green-100 text-green-700' },
  progress: { label: '🔄 В работе', color: 'bg-blue-100 text-blue-700' },
  risk: { label: '⚠️ Риск', color: 'bg-red-100 text-red-700' },
};

/* ═══════════════════════════════════════════
   ДИНАМИКА ОПЛАЧИВАЕМЫХ ПОКАЗАТЕЛЕЙ
   За эти показатели сотрудники получают премии
   ═══════════════════════════════════════════ */
interface PeriodDynamics {
  dept: string;
  color: string;
  metric: string;
  currency: string;
  monthly: { month: string; plan: number; fact: number }[];
  quarterly: { quarter: string; plan: number; fact: number }[];
  yearly: { year: string; plan: number; fact: number }[];
}

const paidMetricsDynamics: PeriodDynamics[] = [
  {
    dept: 'B2C', color: '#CC0000', metric: 'Объём продаж', currency: 'млн ₽',
    monthly: [
      { month: 'Янв', plan: 95, fact: 88 }, { month: 'Фев', plan: 100, fact: 97 }, { month: 'Мар', plan: 110, fact: 105 },
      { month: 'Апр', plan: 105, fact: 102 }, { month: 'Май', plan: 115, fact: 118 }, { month: 'Июн', plan: 120, fact: 125 },
      { month: 'Июл', plan: 125, fact: 0 }, { month: 'Авг', plan: 130, fact: 0 }, { month: 'Сен', plan: 135, fact: 0 },
      { month: 'Окт', plan: 140, fact: 0 }, { month: 'Ноя', plan: 145, fact: 0 }, { month: 'Дек', plan: 150, fact: 0 },
    ],
    quarterly: [
      { quarter: '1Q 2025', plan: 305, fact: 290 }, { quarter: '2Q 2025', plan: 340, fact: 345 },
      { quarter: '3Q 2025', plan: 390, fact: 0 }, { quarter: '4Q 2025', plan: 435, fact: 0 },
    ],
    yearly: [
      { year: '2023', plan: 1000, fact: 980 }, { year: '2024', plan: 1200, fact: 1150 }, { year: '2025', plan: 1470, fact: 635 },
    ],
  },
  {
    dept: 'Онлайн', color: '#006b4f', metric: 'Выручка онлайн', currency: 'млн ₽',
    monthly: [
      { month: 'Янв', plan: 15, fact: 14 }, { month: 'Фев', plan: 16, fact: 15 }, { month: 'Мар', plan: 18, fact: 17 },
      { month: 'Апр', plan: 17, fact: 16 }, { month: 'Май', plan: 19, fact: 20 }, { month: 'Июн', plan: 20, fact: 22 },
      { month: 'Июл', plan: 21, fact: 0 }, { month: 'Авг', plan: 22, fact: 0 }, { month: 'Сен', plan: 23, fact: 0 },
      { month: 'Окт', plan: 24, fact: 0 }, { month: 'Ноя', plan: 25, fact: 0 }, { month: 'Дек', plan: 28, fact: 0 },
    ],
    quarterly: [
      { quarter: '1Q 2025', plan: 49, fact: 46 }, { quarter: '2Q 2025', plan: 56, fact: 58 },
      { quarter: '3Q 2025', plan: 66, fact: 0 }, { quarter: '4Q 2025', plan: 77, fact: 0 },
    ],
    yearly: [
      { year: '2023', plan: 120, fact: 110 }, { year: '2024', plan: 160, fact: 155 }, { year: '2025', plan: 248, fact: 104 },
    ],
  },
  {
    dept: 'Дистрибьюторы', color: '#1a2744', metric: 'Объём через дистрибьюторов', currency: 'млн ₽',
    monthly: [
      { month: 'Янв', plan: 35, fact: 33 }, { month: 'Фев', plan: 37, fact: 36 }, { month: 'Мар', plan: 40, fact: 38 },
      { month: 'Апр', plan: 38, fact: 37 }, { month: 'Май', plan: 42, fact: 43 }, { month: 'Июн', plan: 45, fact: 47 },
      { month: 'Июл', plan: 47, fact: 0 }, { month: 'Авг', plan: 50, fact: 0 }, { month: 'Сен', plan: 52, fact: 0 },
      { month: 'Окт', plan: 55, fact: 0 }, { month: 'Ноя', plan: 57, fact: 0 }, { month: 'Дек', plan: 60, fact: 0 },
    ],
    quarterly: [
      { quarter: '1Q 2025', plan: 112, fact: 107 }, { quarter: '2Q 2025', plan: 125, fact: 127 },
      { quarter: '3Q 2025', plan: 149, fact: 0 }, { quarter: '4Q 2025', plan: 172, fact: 0 },
    ],
    yearly: [
      { year: '2023', plan: 380, fact: 365 }, { year: '2024', plan: 450, fact: 420 }, { year: '2025', plan: 558, fact: 234 },
    ],
  },
  {
    dept: 'Магазины ФЛ', color: '#CC0000', metric: 'Выручка физлиц', currency: 'млн ₽',
    monthly: [
      { month: 'Янв', plan: 7, fact: 6 }, { month: 'Фев', plan: 7, fact: 6.5 }, { month: 'Мар', plan: 8, fact: 7 },
      { month: 'Апр', plan: 8, fact: 7.5 }, { month: 'Май', plan: 9, fact: 8 }, { month: 'Июн', plan: 9, fact: 8.5 },
      { month: 'Июл', plan: 10, fact: 0 }, { month: 'Авг', plan: 10, fact: 0 }, { month: 'Сен', plan: 11, fact: 0 },
      { month: 'Окт', plan: 11, fact: 0 }, { month: 'Ноя', plan: 12, fact: 0 }, { month: 'Дек', plan: 13, fact: 0 },
    ],
    quarterly: [
      { quarter: '1Q 2025', plan: 22, fact: 19.5 }, { quarter: '2Q 2025', plan: 26, fact: 24 },
      { quarter: '3Q 2025', plan: 31, fact: 0 }, { quarter: '4Q 2025', plan: 36, fact: 0 },
    ],
    yearly: [
      { year: '2023', plan: 50, fact: 45 }, { year: '2024', plan: 70, fact: 65 }, { year: '2025', plan: 115, fact: 43.5 },
    ],
  },
  {
    dept: 'Магазины ЮЛ', color: '#1a2744', metric: 'Выручка юрлиц', currency: 'млн ₽',
    monthly: [
      { month: 'Янв', plan: 2.5, fact: 2 }, { month: 'Фев', plan: 2.5, fact: 2.2 }, { month: 'Мар', plan: 3, fact: 2.5 },
      { month: 'Апр', plan: 3, fact: 2.8 }, { month: 'Май', plan: 3.5, fact: 3 }, { month: 'Июн', plan: 3.5, fact: 3.2 },
      { month: 'Июл', plan: 4, fact: 0 }, { month: 'Авг', plan: 4, fact: 0 }, { month: 'Сен', plan: 4.5, fact: 0 },
      { month: 'Окт', plan: 4.5, fact: 0 }, { month: 'Ноя', plan: 5, fact: 0 }, { month: 'Дек', plan: 5.5, fact: 0 },
    ],
    quarterly: [
      { quarter: '1Q 2025', plan: 8, fact: 6.7 }, { quarter: '2Q 2025', plan: 10, fact: 9 },
      { quarter: '3Q 2025', plan: 12.5, fact: 0 }, { quarter: '4Q 2025', plan: 15, fact: 0 },
    ],
    yearly: [
      { year: '2023', plan: 20, fact: 18 }, { year: '2024', plan: 35, fact: 32 }, { year: '2025', plan: 45.5, fact: 15.7 },
    ],
  },
  {
    dept: 'Бренды', color: '#6b2c91', metric: 'Выручка бренда', currency: 'млн ₽',
    monthly: [
      { month: 'Янв', plan: 80, fact: 78 }, { month: 'Фев', plan: 85, fact: 82 }, { month: 'Мар', plan: 90, fact: 88 },
      { month: 'Апр', plan: 88, fact: 86 }, { month: 'Май', plan: 95, fact: 96 }, { month: 'Июн', plan: 100, fact: 102 },
      { month: 'Июл', plan: 105, fact: 0 }, { month: 'Авг', plan: 110, fact: 0 }, { month: 'Сен', plan: 115, fact: 0 },
      { month: 'Окт', plan: 120, fact: 0 }, { month: 'Ноя', plan: 125, fact: 0 }, { month: 'Дек', plan: 130, fact: 0 },
    ],
    quarterly: [
      { quarter: '1Q 2025', plan: 255, fact: 248 }, { quarter: '2Q 2025', plan: 283, fact: 284 },
      { quarter: '3Q 2025', plan: 330, fact: 0 }, { quarter: '4Q 2025', plan: 375, fact: 0 },
    ],
    yearly: [
      { year: '2023', plan: 900, fact: 880 }, { year: '2024', plan: 1050, fact: 1020 }, { year: '2025', plan: 1243, fact: 532 },
    ],
  },
];

type PeriodTab = 'monthly' | 'quarterly' | 'yearly';

const periodLabels: Record<PeriodTab, string> = {
  monthly: 'МЕСЯЦ',
  quarterly: 'КВАРТАЛ',
  yearly: 'ГОД',
};

const periodHeaders: Record<PeriodTab, string[]> = {
  monthly: ['Месяц', 'План', 'Факт', 'Выполнение', 'Премия'],
  quarterly: ['Квартал', 'План', 'Факт', 'Выполнение', 'Премия'],
  yearly: ['Год', 'План', 'Факт', 'Выполнение', 'Премия'],
};

export default function DashboardSection() {
  const [openDept, setOpenDept] = useState<number | null>(null);
  const [filterDept, setFilterDept] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [periodTab, setPeriodTab] = useState<PeriodTab>('monthly');
  const [dynamicsDept, setDynamicsDept] = useState<string>('all');
  const sectionRef = useRef<HTMLElement>(null);

  const filteredTasks = tasks.filter((t) => {
    const deptMatch = filterDept === 'all' || t.dept === filterDept;
    const statusMatch = filterStatus === 'all' || t.status === filterStatus;
    return deptMatch && statusMatch;
  });

  const totalHeadcount = departments.reduce((s, d) => s + d.headcount, 0);
  const totalKPIs = departments.reduce((s, d) => s + d.kpi.length, 0);
  const doneTasks = tasks.filter((t) => t.status === 'done').length;
  const riskTasks = tasks.filter((t) => t.status === 'risk').length;

  const exportPDF = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    const html = `
      <html><head><meta charset="utf-8"><title>SINTEC Dashboard</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 20px; color: #333; }
        h1 { font-size: 24px; border-bottom: 3px solid #CC0000; padding-bottom: 10px; }
        h2 { font-size: 18px; margin-top: 20px; color: #CC0000; }
        .stat { display: inline-block; padding: 10px 20px; background: #f5f5f5; margin: 5px; }
        .stat-val { font-size: 20px; font-weight: bold; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 12px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background: #CC0000; color: white; }
        .done { background: #e8f5e9; }
        .progress { background: #e3f2fd; }
        .risk { background: #ffebee; }
        .progress-bar { height: 10px; background: #eee; }
        .progress-fill { height: 100%; background: #CC0000; }
      </style></head><body>
      <h1>📊 ОБЩИЙ ДАШБОРД SINTEC</h1>
      <p>Сводка по всем направлениям | ${new Date().toLocaleDateString('ru-RU')}</p>
      <div>
        <div class="stat"><div class="stat-val">${totalHeadcount}</div>СОТРУДНИКОВ</div>
        <div class="stat"><div class="stat-val">${departments.length}</div>ОТДЕЛОВ</div>
        <div class="stat"><div class="stat-val">${totalKPIs}</div>KPI</div>
        <div class="stat"><div class="stat-val">${tasks.length}</div>ЗАДАЧ</div>
        <div class="stat"><div class="stat-val">${doneTasks}/${tasks.length}</div>ВЫПОЛНЕНО</div>
      </div>
      ${departments.map(d => `
        <h2>${d.name} (${d.headcount} чел.)</h2>
        <table>
          <tr><th>KPI</th><th>Текущее</th><th>Цель</th><th>%</th></tr>
          ${d.kpi.map(k => `<tr><td>${k.label}</td><td>${k.value}</td><td>${k.target}</td><td>${k.progress}%</td></tr>`).join('')}
        </table>
      `).join('')}
      <h2>Задачи</h2>
      <table>
        <tr><th>ID</th><th>Отдел</th><th>Задача</th><th>Дедлайн</th><th>Статус</th><th>Ответственный</th></tr>
        ${tasks.map(t => `<tr class="${t.status}"><td>${t.id}</td><td>${t.dept}</td><td>${t.description}</td><td>${t.deadline}</td><td>${statusLabels[t.status].label}</td><td>${t.owner}</td></tr>`).join('')}
      </table>
      </body></html>`;
    printWindow.document.write(html);
    printWindow.document.close();
    setTimeout(() => printWindow.print(), 500);
  };

  const exportCSV = () => {
    const rows = [
      ['Отдел', 'KPI', 'Текущее', 'Цель', 'Прогресс %'],
      ...departments.flatMap(d => d.kpi.map(k => [d.name, k.label, k.value, k.target, k.progress.toString()])),
      [],
      ['ID', 'Отдел', 'Задача', 'Дедлайн', 'Статус', 'Ответственный'],
      ...tasks.map(t => [t.id, t.dept, t.description, t.deadline, statusLabels[t.status].label, t.owner]),
    ];
    const csv = rows.map(r => r.map(c => `"${c}"`).join(',')).join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sintec-dashboard-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <section ref={sectionRef} id="dashboard" className="py-16 px-4 bg-white">
      <div className="max-w-[900px] mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 border border-red-200 bg-red-50">
            <span className="text-xs font-medium text-red-600 uppercase tracking-widest">📊 Дашборд</span>
          </div>
          <h2 className="font-oswald font-bold text-3xl lg:text-4xl text-black mb-2">ОБЩИЙ ДАШБОРД SINTEC</h2>
          <p className="text-sm text-gray-500">Сводка по всем направлениям | {new Date().toLocaleDateString('ru-RU')}</p>
        </div>

        {/* Export buttons */}
        <div className="flex justify-center gap-2 mb-6">
          <button onClick={exportPDF} className="px-4 py-2 bg-red-600 text-white text-xs font-bold uppercase hover:bg-red-700">⬇️ Экспорт PDF</button>
          <button onClick={exportCSV} className="px-4 py-2 bg-green-600 text-white text-xs font-bold uppercase hover:bg-green-700">⬇️ Экспорт CSV</button>
        </div>

        {/* Summary cards */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-2 mb-6">
          {[
            { val: totalHeadcount.toString(), label: 'СОТРУДНИКОВ', color: 'bg-red-600 text-white' },
            { val: departments.length.toString(), label: 'ОТДЕЛОВ', color: 'bg-blue-900 text-white' },
            { val: totalKPIs.toString(), label: 'K ПОКАЗАТЕЛЕЙ', color: 'bg-green-600 text-white' },
            { val: tasks.length.toString(), label: 'ЗАДАЧ', color: 'bg-purple-600 text-white' },
            { val: `${doneTasks}/${tasks.length}`, label: 'ВЫПОЛНЕНО', color: 'bg-gray-800 text-white' },
          ].map((s, i) => (
            <div key={i} className={`p-3 ${s.color} text-center`}>
              <span className="font-oswald font-bold text-xl">{s.val}</span>
              <p className="text-[10px] uppercase tracking-wider mt-1 opacity-80">{s.label}</p>
            </div>
          ))}
        </div>

        {riskTasks > 0 && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 text-sm text-red-700 text-center">
            ⚠️ {riskTasks} задач в статусе "Риск" — требуют внимания
          </div>
        )}

        {/* KPI by department — accordion */}
        <div className="mb-8">
          <h3 className="font-oswald font-bold text-lg text-black uppercase mb-3">📈 KPI ПО ОТДЕЛАМ</h3>
          <div className="space-y-2">
            {departments.map((dept, di) => (
              <details
                key={di}
                className="group border border-gray-200 cursor-pointer"
                open={openDept === di}
                onClick={(e) => { e.preventDefault(); setOpenDept(openDept === di ? null : di); }}
              >
                <summary className="flex items-center justify-between p-3 bg-gray-50 list-none">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3" style={{ backgroundColor: dept.color }} />
                    <span className="font-oswald font-bold text-sm uppercase">{dept.name}</span>
                    <span className="text-xs text-gray-400">({dept.headcount} чел.)</span>
                  </div>
                  <span className="text-gray-400 group-open:rotate-180 transition-transform text-xs">▼</span>
                </summary>
                <div className="p-3">
                  {dept.kpi.map((k, ki) => (
                    <div key={ki} className="mb-3 last:mb-0 p-3 bg-gray-50/50">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium text-black">{k.label}</span>
                        <span className="text-sm font-bold" style={{ color: dept.color }}>{k.value}</span>
                      </div>
                      <div className="w-full h-2 bg-gray-200 mb-1">
                        <div className="h-full transition-all" style={{ width: `${k.progress}%`, backgroundColor: dept.color }} />
                      </div>
                      <div className="flex justify-between mb-2">
                        <span className="text-[10px] text-gray-400">Цель: {k.target}</span>
                        <span className="text-[10px] font-bold" style={{ color: dept.color }}>{k.progress}%</span>
                      </div>
                      {/* Detailed actions */}
                      <ul className="space-y-1 ml-4">
                        {k.details.map((d, i) => (
                          <li key={i} className="flex items-start gap-2 text-xs text-gray-500">
                            <span style={{ color: dept.color }}>▸</span>
                            <span>{d}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </details>
            ))}
          </div>
        </div>

        {/* ═══════════════════════════════════════════
            ДИНАМИКА ОПЛАЧИВАЕМЫХ ПОКАЗАТЕЛЕЙ
            За эти показатели сотрудники получают деньги
            ═══════════════════════════════════════════ */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-3">
            <h3 className="font-oswald font-bold text-lg text-black uppercase">💰 ДИНАМИКА ОПЛАЧИВАЕМЫХ ПОКАЗАТЕЛЕЙ</h3>
            <span className="text-[10px] bg-red-600 text-white px-2 py-0.5 uppercase">Премии</span>
          </div>
          <p className="text-xs text-gray-500 mb-3">Динамика основных показателей, за которые начисляются премии сотрудников</p>

          {/* Period tabs */}
          <div className="flex gap-1 mb-4">
            {(Object.keys(periodLabels) as PeriodTab[]).map((tab) => (
              <button
                key={tab}
                onClick={() => setPeriodTab(tab)}
                className={`px-4 py-2 text-xs font-bold uppercase transition-colors ${
                  periodTab === tab ? 'bg-red-600 text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                }`}
              >
                {periodLabels[tab]}
              </button>
            ))}
          </div>

          {/* Dept filter */}
          <div className="flex gap-1 mb-3">
            <button
              onClick={() => setDynamicsDept('all')}
              className={`px-3 py-1 text-[10px] font-bold uppercase transition-colors ${
                dynamicsDept === 'all' ? 'bg-gray-800 text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
              }`}
            >
              ВСЕ ОТДЕЛЫ
            </button>
            {paidMetricsDynamics.map((d) => (
              <button
                key={d.dept}
                onClick={() => setDynamicsDept(d.dept)}
                className={`px-3 py-1 text-[10px] font-bold uppercase transition-colors ${
                  dynamicsDept === d.dept ? 'text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                }`}
                style={dynamicsDept === d.dept ? { backgroundColor: d.color } : undefined}
              >
                {d.dept}
              </button>
            ))}
          </div>

          {/* Data table */}
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-2 text-left font-medium text-gray-500">Отдел / Показатель</th>
                  {periodHeaders[periodTab].map((h) => (
                    <th key={h} className="p-2 text-right font-medium text-gray-500">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {paidMetricsDynamics
                  .filter((d) => dynamicsDept === 'all' || d.dept === dynamicsDept)
                  .map((d) => {
                    const data = d[periodTab];
                    return (
                      <tr key={d.dept} className="border-t-2 border-gray-200">
                        <td colSpan={6} className="p-0">
                          <table className="w-full">
                            <tbody>
                              {data.map((row: any, i: number) => {
                                const label = periodTab === 'monthly' ? row.month : periodTab === 'quarterly' ? row.quarter : row.year;
                                const pct = row.plan > 0 ? Math.round((row.fact / row.plan) * 100) : 0;
                                const isFuture = row.fact === 0;
                                const bonus = pct >= 100 ? '100%' : pct >= 90 ? '75%' : pct >= 75 ? '50%' : '0%';
                                return (
                                  <tr key={i} className={`border-t border-gray-100 ${i === 0 ? 'bg-gray-50/50' : ''}`}>
                                    {i === 0 && (
                                      <td rowSpan={data.length} className="p-2 align-top" style={{ width: '160px' }}>
                                        <div className="flex items-center gap-2">
                                          <div className="w-2 h-2" style={{ backgroundColor: d.color }} />
                                          <div>
                                            <div className="font-bold text-black text-[10px] uppercase">{d.dept}</div>
                                            <div className="text-gray-400 text-[9px]">{d.metric}, {d.currency}</div>
                                          </div>
                                        </div>
                                      </td>
                                    )}
                                    <td className="p-2 text-right font-mono text-gray-600">{label}</td>
                                    <td className="p-2 text-right font-mono text-gray-600">{row.plan.toLocaleString('ru-RU')}</td>
                                    <td className={`p-2 text-right font-mono font-bold ${isFuture ? 'text-gray-300' : pct >= 100 ? 'text-green-600' : pct >= 90 ? 'text-blue-600' : 'text-orange-500'}`}>
                                      {isFuture ? '—' : row.fact.toLocaleString('ru-RU')}
                                    </td>
                                    <td className="p-2 text-right">
                                      {isFuture ? (
                                        <span className="text-gray-300">—</span>
                                      ) : (
                                        <div className="flex items-center justify-end gap-1">
                                          <div className="w-12 h-1.5 bg-gray-200">
                                            <div className="h-full" style={{ width: `${Math.min(pct, 100)}%`, backgroundColor: pct >= 100 ? '#16a34a' : pct >= 90 ? '#2563eb' : '#f97316' }} />
                                          </div>
                                          <span className={`font-mono font-bold text-[10px] ${pct >= 100 ? 'text-green-600' : pct >= 90 ? 'text-blue-600' : 'text-orange-500'}`}>{pct}%</span>
                                        </div>
                                      )}
                                    </td>
                                    <td className="p-2 text-right">
                                      <span className={`px-2 py-0.5 text-[10px] font-bold uppercase ${
                                        isFuture ? 'bg-gray-100 text-gray-300' :
                                        pct >= 100 ? 'bg-green-100 text-green-700' :
                                        pct >= 90 ? 'bg-blue-100 text-blue-700' :
                                        pct >= 75 ? 'bg-orange-100 text-orange-700' :
                                        'bg-red-100 text-red-700'
                                      }`}>{isFuture ? '—' : bonus}</span>
                                    </td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>

          {/* Legend */}
          <div className="flex flex-wrap gap-3 mt-3 text-[10px] text-gray-500">
            <span className="flex items-center gap-1"><span className="w-2 h-2 bg-green-500" />100%+ = премия 100%</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 bg-blue-500"/>90-99% = премия 75%</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 bg-orange-500"/>75-89% = премия 50%</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 bg-red-500"/> &lt;75% = премия 0%</span>
          </div>
        </div>

        {/* Tasks */}
        <div>
          <h3 className="font-oswald font-bold text-lg text-black uppercase mb-3">📋 ЗАДАЧИ</h3>
          <div className="flex flex-wrap gap-2 mb-3">
            <select value={filterDept} onChange={(e) => setFilterDept(e.target.value)} className="px-2 py-1 border border-gray-300 text-xs">
              <option value="all">Все отделы</option>
              {departments.map((d) => <option key={d.name} value={d.name}>{d.name}</option>)}
              <option value="Обучение">Обучение</option>
            </select>
            <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="px-2 py-1 border border-gray-300 text-xs">
              <option value="all">Все статусы</option>
              <option value="done">✅ Выполнено</option>
              <option value="progress">🔄 В работе</option>
              <option value="risk">⚠️ Риск</option>
            </select>
            <span className="text-xs text-gray-400 ml-auto self-center">{filteredTasks.length} задач</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-2 text-left font-medium text-gray-500">ID</th>
                  <th className="p-2 text-left font-medium text-gray-500">Отдел</th>
                  <th className="p-2 text-left font-medium text-gray-500">Задача</th>
                  <th className="p-2 text-left font-medium text-gray-500">Дедлайн</th>
                  <th className="p-2 text-left font-medium text-gray-500">Статус</th>
                  <th className="p-2 text-left font-medium text-gray-500">Ответственный</th>
                </tr>
              </thead>
              <tbody>
                {filteredTasks.map((t) => (
                  <tr key={t.id} className="border-t border-gray-100">
                    <td className="p-2 text-gray-400 font-mono">{t.id}</td>
                    <td className="p-2"><span className="px-2 py-0.5 bg-gray-100 text-gray-700">{t.dept}</span></td>
                    <td className="p-2 text-gray-700">{t.description}</td>
                    <td className="p-2 text-gray-500">{t.deadline}</td>
                    <td className="p-2"><span className={`px-2 py-0.5 ${statusLabels[t.status].color}`}>{statusLabels[t.status].label}</span></td>
                    <td className="p-2 text-gray-500">{t.owner}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}
