import { useState, useEffect } from 'react';
import { trpc } from '@/providers/trpc';

const VALID_PASSWORDS = ['7771', '7773', '0334'];
const ADMIN_ACCESS_KEY = 'sintec_admin_access';

interface Binding {
  password: string;
  deviceFingerprint: string;
  createdAt: Date | null;
}

export default function AdminPanel() {
  const [visible, setVisible] = useState(false);
  const [accessCode, setAccessCode] = useState('');
  const [accessGranted, setAccessGranted] = useState(false);
  const [unlockInput, setUnlockInput] = useState('');
  const [message, setMessage] = useState('');
  const [shake, setShake] = useState(false);
  const [activeTab, setActiveTab] = useState<'status' | 'unlock'>('status');

  const bindingsQuery = trpc.auth.listBindings.useQuery(undefined, {
    enabled: accessGranted,
  });

  const unbindMutation = trpc.auth.unbindPassword.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        setMessage(`Пароль разблокирован. Теперь его можно использовать на другом устройстве.`);
        bindingsQuery.refetch();
      } else {
        setMessage(data.message);
      }
    },
  });

  useEffect(() => {
    const hasAccess = sessionStorage.getItem(ADMIN_ACCESS_KEY);
    if (hasAccess === '1') setAccessGranted(true);
  }, []);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'A') {
        e.preventDefault();
        setVisible(true);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const checkAccess = (e: React.FormEvent) => {
    e.preventDefault();
    if (accessCode.toUpperCase() === 'SINTEC') {
      sessionStorage.setItem(ADMIN_ACCESS_KEY, '1');
      setAccessGranted(true);
      setAccessCode('');
    } else {
      setShake(true);
      setTimeout(() => setShake(false), 400);
      setAccessCode('');
    }
  };

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    setMessage('');

    if (!unlockInput) {
      setMessage('Введите пароль для разблокировки.');
      return;
    }

    if (!VALID_PASSWORDS.includes(unlockInput)) {
      setShake(true);
      setTimeout(() => setShake(false), 400);
      setMessage('Неверный код. Введите один из привязанных паролей.');
      setUnlockInput('');
      return;
    }

    unbindMutation.mutate({ password: unlockInput });
    setUnlockInput('');
  };

  const resetAll = async () => {
    for (const pwd of VALID_PASSWORDS) {
      await unbindMutation.mutateAsync({ password: pwd });
    }
    setMessage('Все привязки сброшены. Все 3 пароля свободны.');
  };

  if (!visible) return null;

  if (!accessGranted) {
    return (
      <div className="fixed inset-0 z-[20000] bg-black/90 flex items-center justify-center" onClick={(e) => { if (e.target === e.currentTarget) setVisible(false); }}>
        <div className={`w-full max-w-xs mx-4 bg-white p-6 shadow-2xl ${shake ? 'animate-shake' : ''}`}>
          <div className="text-center mb-4">
            <span className="text-xs font-medium text-red-600 uppercase tracking-widest">&#x1F510; Кабинет администратора</span>
            <h2 className="font-oswald font-bold text-xl text-black uppercase mt-2">ДОСТУП ОГРАНИЧЕН</h2>
          </div>
          <form onSubmit={checkAccess} className="space-y-3">
            <input type="password" value={accessCode} onChange={(e) => setAccessCode(e.target.value)} placeholder="Код доступа" className="w-full px-3 py-2 border border-gray-300 text-center text-sm uppercase tracking-wider focus:outline-none focus:border-red-600" autoFocus />
            <button type="submit" className="w-full py-2 bg-red-600 text-white font-oswald font-bold text-xs uppercase hover:bg-red-700">Войти в кабинет</button>
          </form>
          <p className="text-[10px] text-gray-400 text-center mt-3">Нажмите Ctrl+Shift+A для открытия этой панели</p>
          <button onClick={() => setVisible(false)} className="w-full mt-2 py-1.5 bg-gray-200 text-gray-600 text-[10px] font-bold uppercase hover:bg-gray-300">Закрыть</button>
          <style>{`@keyframes shake {0%,100%{transform:translateX(0)}25%{transform:translateX(-8px)}50%{transform:translateX(8px)}75%{transform:translateX(-4px)}}.animate-shake{animation:shake 0.35s ease-in-out}`}</style>
        </div>
      </div>
    );
  }

  const bindings: Binding[] = (bindingsQuery.data || []) as Binding[];
  const boundPasswords = bindings.map((b: Binding) => b.password);

  return (
    <div className="fixed inset-0 z-[20000] bg-black/90 flex items-center justify-center overflow-y-auto py-8" onClick={(e) => { if (e.target === e.currentTarget) setVisible(false); }}>
      <div className={`w-full max-w-lg mx-4 bg-white shadow-2xl ${shake ? 'animate-shake' : ''}`}>
        <div className="p-4 bg-gray-900 text-white flex items-center justify-between">
          <div>
            <span className="text-[10px] text-red-400 uppercase tracking-widest">&#x1F510; Кабинет администратора</span>
            <h2 className="font-oswald font-bold text-lg uppercase">Управление доступом</h2>
          </div>
          <button onClick={() => setVisible(false)} className="text-gray-400 hover:text-white text-lg">&#x2715;</button>
        </div>

        <div className="flex border-b border-gray-200">
          <button onClick={() => { setActiveTab('status'); setMessage(''); }} className={`flex-1 py-2 text-[10px] font-bold uppercase ${activeTab === 'status' ? 'bg-red-600 text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}>Статус системы</button>
          <button onClick={() => { setActiveTab('unlock'); setMessage(''); }} className={`flex-1 py-2 text-[10px] font-bold uppercase ${activeTab === 'unlock' ? 'bg-red-600 text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}>Разблокировка пароля</button>
        </div>

        <div className="p-6">
          {activeTab === 'status' && (
            <div className="space-y-4">
              <h3 className="font-oswald font-bold text-sm text-black uppercase">Текущие привязки</h3>

              {bindings.length > 0 ? (
                bindings.map((b: Binding) => (
                  <div key={b.password} className="p-4 bg-green-50 border border-green-200">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="w-2 h-2 bg-green-500 rounded-full" />
                      <span className="text-xs font-bold text-green-800 uppercase">Пароль привязан к устройству</span>
                    </div>
                    <div className="space-y-1 text-xs text-green-700">
                      <p><strong>Пароль:</strong> {b.password}</p>
                      <p><strong>Отпечаток устройства:</strong> <span className="font-mono text-[10px]">{b.deviceFingerprint}</span></p>
                      <p><strong>Привязан:</strong> {b.createdAt ? new Date(b.createdAt).toLocaleString('ru-RU') : '—'}</p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-4 bg-gray-50 border border-gray-200 text-center">
                  <p className="text-xs text-gray-500">Нет активных привязок. Все пароли свободны.</p>
                </div>
              )}

              <div className="p-4 bg-gray-50 border border-gray-200">
                <h4 className="font-oswald font-bold text-[10px] text-black uppercase mb-2">Доступные пароли</h4>
                <div className="flex gap-2">
                  {VALID_PASSWORDS.map((p) => (
                    <span key={p} className={`px-3 py-1 text-xs font-mono font-bold ${boundPasswords.includes(p) ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-600'}`}>{p}</span>
                  ))}
                </div>
                <p className="text-[10px] text-gray-400 mt-2">&#x2705; Зелёный = используется | &#x25EF; Серый = свободен</p>
              </div>

              <button onClick={resetAll} className="w-full py-3 bg-red-600 text-white font-oswald font-bold text-xs uppercase hover:bg-red-700">&#x26A0; Сбросить все привязки</button>
            </div>
          )}

          {activeTab === 'unlock' && (
            <div className="space-y-4">
              <h3 className="font-oswald font-bold text-sm text-black uppercase">Разблокировка пароля</h3>
              <p className="text-xs text-gray-500">Введите <strong>привязанный пароль</strong>, чтобы разблокировать его для использования на другом устройстве.</p>

              <form onSubmit={handleUnlock} className="space-y-3">
                <input type="password" value={unlockInput} onChange={(e) => { setUnlockInput(e.target.value); setMessage(''); }} placeholder="XXXX" maxLength={4} className="w-full px-4 py-3 border border-gray-300 text-center text-lg font-mono tracking-[0.5em] text-black placeholder:text-gray-300 focus:outline-none focus:border-red-600" autoFocus />
                <button type="submit" disabled={unbindMutation.isPending} className="w-full py-3 bg-red-600 text-white font-oswald font-bold text-sm uppercase hover:bg-red-700 disabled:opacity-50">{unbindMutation.isPending ? 'Разблокировка...' : 'Разблокировать'}</button>
              </form>

              {message && (
                <div className={`p-3 text-xs text-center ${message.includes('разблокирован') || message.includes('сброшены') ? 'bg-green-50 border border-green-200 text-green-700' : 'bg-yellow-50 border border-yellow-200 text-yellow-700'}`}>{message}</div>
              )}
            </div>
          )}
        </div>

        <style>{`@keyframes shake {0%,100%{transform:translateX(0)}25%{transform:translateX(-8px)}50%{transform:translateX(8px)}75%{transform:translateX(-4px)}}.animate-shake{animation:shake 0.35s ease-in-out}`}</style>
      </div>
    </div>
  );
}
