import { useState, useCallback } from 'react';

interface DashboardData {
  departments: Dept[];
  tasks: Task[];
}

interface Dept {
  name: string;
  color: string;
  headcount: number;
  kpi: { label: string; value: string; target: string; progress: number }[];
}

interface Task {
  id: string;
  dept: string;
  description: string;
  deadline: string;
  status: 'done' | 'progress' | 'risk';
  owner: string;
}

const data: DashboardData = {
  departments: [
    {
      name: 'B2C',
      color: '#CC0000',
      headcount: 159,
      kpi: [
        { label: 'Объём продаж', value: '1.2 млрд ₽', target: '1.5 млрд ₽', progress: 80 },
        { label: 'Доля рынка', value: '8.5%', target: '10-15%', progress: 57 },
        { label: 'Торговые точки в базе', value: '45 000', target: '60 000', progress: 75 },
        { label: 'Бонус Клуб подключено', value: '12 000', target: '20 000', progress: 60 },
        { label: 'Визитов в день', value: '850', target: '1 000', progress: 85 },
        { label: 'EasyMerch аудиты', value: '92%', target: '95%', progress: 97 },
      ],
    },
    {
      name: 'Онлайн',
      color: '#006b4f',
      headcount: 12,
      kpi: [
        { label: 'Выручка онлайн', value: '180 млн ₽', target: '250 млн ₽', progress: 72 },
        { label: 'Подключено магазинов', value: '2 400', target: '5 000', progress: 48 },
        { label: 'Запуск подборщика', value: '28', target: '50', progress: 56 },
        { label: 'Маркетплейсы выручка', value: '45 млн ₽', target: '80 млн ₽', progress: 56 },
        { label: 'API-интеграции', value: '85%', target: '95%', progress: 89 },
        { label: 'Наполнение ассортимента', value: '91%', target: '95%', progress: 96 },
      ],
    },
    {
      name: 'Дистрибьюторы',
      color: '#1a2744',
      headcount: 58,
      kpi: [
        { label: 'Объём через дистр.', value: '420 млн ₽', target: '500 млн ₽', progress: 84 },
        { label: 'BDM активность', value: '85%', target: '90%', progress: 94 },
        { label: 'Бонус Клуб БДМ', value: '3 200', target: '5 000', progress: 64 },
        { label: 'Аудиты качества', value: '78%', target: '85%', progress: 92 },
        { label: 'Новые точки', value: '450', target: '600', progress: 75 },
        { label: 'Сегментация Platinum', value: '120', target: '200', progress: 60 },
      ],
    },
    {
      name: 'Бренды',
      color: '#6b2c91',
      headcount: 5,
      kpi: [
        { label: 'Доля рынка SINTEC', value: '12%', target: '15%', progress: 80 },
        { label: 'Лояльность клиентов (NPS)', value: '72', target: '80+', progress: 90 },
        { label: 'Окупаемость маркетинга (ROMI)', value: '280%', target: '300%', progress: 93 },
        { label: 'Запуск новинок', value: '3', target: '5', progress: 60 },
        { label: 'Снижение контрафакта', value: '15%', target: '5%', progress: 33 },
        { label: 'Узнаваемость бренда', value: '65%', target: '75%', progress: 87 },
      ],
    },
    {
      name: 'Магазины ФЛ',
      color: '#CC0000',
      headcount: 8,
      kpi: [
        { label: 'Выручка ФЛ', value: '85 млн ₽', target: '+250-400 млн ₽', progress: 34 },
        { label: 'Заказов в день', value: '120', target: '300', progress: 40 },
        { label: 'Рассрочка оформлено', value: '450', target: '1 000', progress: 45 },
        { label: 'Приложение установок', value: '8 500', target: '20 000', progress: 43 },
        { label: 'Повторные покупки', value: '35%', target: '50%', progress: 70 },
        { label: 'Средний чек', value: '3 200 ₽', target: '4 500 ₽', progress: 71 },
      ],
    },
    {
      name: 'Магазины ЮЛ',
      color: '#1a2744',
      headcount: 6,
      kpi: [
        { label: 'Выручка ЮЛ', value: '28 млн ₽', target: '+100 млн ₽', progress: 28 },
        { label: 'ЮЛ подключено', value: '45', target: '120', progress: 38 },
        { label: 'EDI-интеграции', value: '12', target: '30', progress: 40 },
        { label: 'Контракты подписано', value: '18', target: '40', progress: 45 },
        { label: 'NPS ЮЛ', value: '75', target: '80+', progress: 94 },
        { label: 'Отсрочка 60 дней', value: '8 клиентов', target: '20', progress: 40 },
      ],
    },
  ],
  tasks: [
    { id: 'T001', dept: 'B2C', description: 'Запуск новой сегментации 60 000+ торговых точек', deadline: '2025-12-31', status: 'progress', owner: 'РД B2C' },
    { id: 'T002', dept: 'B2C', description: 'Внедрение автоматического контроля качества визитов', deadline: '2025-11-30', status: 'progress', owner: 'ТМ Полина' },
    { id: 'T003', dept: 'B2C', description: 'Запуск Клуба Легенд для топ-ТП', deadline: '2025-10-15', status: 'done', owner: 'Отдел обучения' },
    { id: 'T004', dept: 'Онлайн', description: 'Интеграция подборщика на 50+ магазинов', deadline: '2025-12-15', status: 'progress', owner: 'Директор онлайн' },
    { id: 'T005', dept: 'Онлайн', description: 'Запуск на Wildberries Premium', deadline: '2025-11-15', status: 'risk', owner: 'Менеджер WB' },
    { id: 'T006', dept: 'Дистрибьюторы', description: 'Автоматическая генерация презентаций для BDM', deadline: '2025-12-01', status: 'progress', owner: 'РМ Север' },
    { id: 'T007', dept: 'Дистрибьюторы', description: 'Обучение 50 BDM через AI тренажёр', deadline: '2025-11-30', status: 'progress', owner: 'Тренеры BDM' },
    { id: 'T008', dept: 'Бренды', description: 'Запуск ROLF Black Edition', deadline: '2026-01-15', status: 'progress', owner: 'Бренд-директор' },
    { id: 'T009', dept: 'Бренды', description: 'Программа борьбы с контрафактом', deadline: '2025-12-31', status: 'risk', owner: 'Юрист' },
    { id: 'T010', dept: 'Магазины ФЛ', description: 'Запуск рассрочки через Т-Банк', deadline: '2025-11-01', status: 'done', owner: 'Менеджер ФЛ' },
    { id: 'T011', dept: 'Магазины ЮЛ', description: 'EDI-интеграция с 10 крупными ЮЛ', deadline: '2025-12-31', status: 'progress', owner: 'Менеджер ЮЛ' },
    { id: 'T012', dept: 'Обучение', description: 'Сертификация 100% ТП по продуктам', deadline: '2025-11-30', status: 'progress', owner: 'Тренер продуктов' },
  ],
};

const statusLabels: Record<string, { label: string; color: string }> = {
  done: { label: '✅ Выполнено', color: 'bg-green-100 text-green-700' },
  progress: { label: '🔄 В работе', color: 'bg-blue-100 text-blue-700' },
  risk: { label: '⚠️ Риск', color: 'bg-red-100 text-red-700' },
};

export default function Dashboard({ onClose }: { onClose: () => void }) {
  const [filterDept, setFilterDept] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const exportCSV = useCallback(() => {
    const rows = [
      ['Отдел', 'Задача', 'Дедлайн', 'Статус', 'Ответственный'],
      ...filteredTasks.map((t) => [t.dept, t.description, t.deadline, statusLabels[t.status].label, t.owner]),
    ];
    const csv = rows.map((r) => r.map((c) => `"${c}"`).join(',')).join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sintec-dashboard-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }, []);

  const filteredTasks = data.tasks.filter((t) => {
    const deptMatch = filterDept === 'all' || t.dept === filterDept;
    const statusMatch = filterStatus === 'all' || t.status === filterStatus;
    return deptMatch && statusMatch;
  });

  const totalHeadcount = data.departments.reduce((s, d) => s + d.headcount, 0);
  const totalKPIs = data.departments.reduce((s, d) => s + d.kpi.length, 0);
  const doneTasks = data.tasks.filter((t) => t.status === 'done').length;
  const riskTasks = data.tasks.filter((t) => t.status === 'risk').length;

  return (
    <div className="fixed inset-0 z-[9999] bg-black/80 flex items-start justify-center overflow-y-auto py-8">
      <div className="bg-white w-full max-w-[1100px] mx-4 p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="font-oswald font-bold text-2xl text-black uppercase">📊 Общий дашборд SINTEC</h2>
            <p className="text-xs text-gray-400">Сводка по всем направлениям</p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={exportCSV} className="px-3 py-1.5 bg-green-600 text-white text-xs font-medium">⬇️ Экспорт CSV</button>
            <button onClick={onClose} className="px-3 py-1.5 bg-gray-200 text-black text-xs font-medium">✕ Закрыть</button>
          </div>
        </div>

        {/* Summary cards */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-2 mb-6">
          {[
            { val: totalHeadcount.toString(), label: 'Сотрудников', color: 'bg-red-600 text-white' },
            { val: data.departments.length.toString(), label: 'Отделов', color: 'bg-blue-900 text-white' },
            { val: totalKPIs.toString(), label: 'KPI показателей', color: 'bg-green-600 text-white' },
            { val: data.tasks.length.toString(), label: 'Задач', color: 'bg-purple-600 text-white' },
            { val: `${doneTasks}/${data.tasks.length}`, label: 'Выполнено', color: 'bg-gray-800 text-white' },
          ].map((s, i) => (
            <div key={i} className={`p-3 ${s.color} text-center`}>
              <span className="font-oswald font-bold text-xl">{s.val}</span>
              <p className="text-[10px] uppercase tracking-wider mt-1 opacity-80">{s.label}</p>
            </div>
          ))}
        </div>

        {riskTasks > 0 && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 text-sm text-red-700">
            ⚠️ {riskTasks} задач в статусе "Риск" — требуют внимания
          </div>
        )}

        {/* KPI by department */}
        <div className="mb-6">
          <h3 className="font-oswald font-bold text-lg text-black uppercase mb-3">📈 KPI по отделам</h3>
          <div className="space-y-4">
            {data.departments.map((dept) => (
              <div key={dept.name} className="border border-gray-200">
                <div className="p-3 bg-gray-50 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3" style={{ backgroundColor: dept.color }} />
                    <span className="font-oswald font-bold text-sm uppercase">{dept.name}</span>
                    <span className="text-xs text-gray-400">({dept.headcount} чел.)</span>
                  </div>
                </div>
                <div className="p-3 grid grid-cols-1 lg:grid-cols-3 gap-2">
                  {dept.kpi.map((k, j) => (
                    <div key={j} className="p-2 bg-gray-50/50">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs text-gray-500">{k.label}</span>
                        <span className="text-xs font-medium">{k.value}</span>
                      </div>
                      <div className="w-full h-2 bg-gray-200">
                        <div className="h-full transition-all" style={{ width: `${k.progress}%`, backgroundColor: dept.color }} />
                      </div>
                      <div className="flex justify-between mt-1">
                        <span className="text-[10px] text-gray-400">Цель: {k.target}</span>
                        <span className="text-[10px] font-medium" style={{ color: dept.color }}>{k.progress}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Tasks table */}
        <div>
          <h3 className="font-oswald font-bold text-lg text-black uppercase mb-3">📋 Задачи</h3>

          {/* Filters */}
          <div className="flex flex-wrap gap-2 mb-3">
            <select value={filterDept} onChange={(e) => setFilterDept(e.target.value)} className="px-2 py-1 border border-gray-300 text-xs">
              <option value="all">Все отделы</option>
              {data.departments.map((d) => <option key={d.name} value={d.name}>{d.name}</option>)}
              <option value="Обучение">Обучение</option>
            </select>
            <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="px-2 py-1 border border-gray-300 text-xs">
              <option value="all">Все статусы</option>
              <option value="done">✅ Выполнено</option>
              <option value="progress">🔄 В работе</option>
              <option value="risk">⚠️ Риск</option>
            </select>
            <span className="text-xs text-gray-400 ml-auto self-center">{filteredTasks.length} задач</span>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-2 text-left font-medium text-gray-500">ID</th>
                  <th className="p-2 text-left font-medium text-gray-500">Отдел</th>
                  <th className="p-2 text-left font-medium text-gray-500">Задача</th>
                  <th className="p-2 text-left font-medium text-gray-500">Дедлайн</th>
                  <th className="p-2 text-left font-medium text-gray-500">Статус</th>
                  <th className="p-2 text-left font-medium text-gray-500">Ответственный</th>
                </tr>
              </thead>
              <tbody>
                {filteredTasks.map((t) => (
                  <tr key={t.id} className="border-t border-gray-100">
                    <td className="p-2 text-gray-400 font-mono">{t.id}</td>
                    <td className="p-2">
                      <span className="px-2 py-0.5 bg-gray-100 text-gray-700">{t.dept}</span>
                    </td>
                    <td className="p-2 text-gray-700">{t.description}</td>
                    <td className="p-2 text-gray-500">{t.deadline}</td>
                    <td className="p-2">
                      <span className={`px-2 py-0.5 ${statusLabels[t.status].color}`}>{statusLabels[t.status].label}</span>
                    </td>
                    <td className="p-2 text-gray-500">{t.owner}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
