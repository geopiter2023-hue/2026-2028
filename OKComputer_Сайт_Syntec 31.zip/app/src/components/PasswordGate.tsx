import { useState } from 'react';
import { trpc } from '@/providers/trpc';

const STORAGE_KEY_DEVICE = 'sintec_device_fp';

function getDeviceFingerprint(): string {
  const parts = [
    navigator.userAgent,
    screen.width + 'x' + screen.height,
    screen.colorDepth.toString(),
    navigator.language,
    Intl.DateTimeFormat().resolvedOptions().timeZone,
    navigator.hardwareConcurrency?.toString() || '',
    navigator.platform,
  ];
  let hash = 0;
  const str = parts.join('|');
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0;
  }
  return 'fp_' + Math.abs(hash).toString(16);
}

function getStoredFingerprint(): string {
  let fp = localStorage.getItem(STORAGE_KEY_DEVICE);
  if (!fp) {
    fp = getDeviceFingerprint();
    localStorage.setItem(STORAGE_KEY_DEVICE, fp);
  }
  return fp;
}

export default function PasswordGate({ children }: { children: React.ReactNode }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [shake, setShake] = useState(false);
  const [warningMessage, setWarningMessage] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const checkMut = trpc.auth.checkPassword.useMutation();
  const bindMut = trpc.auth.bindPassword.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setWarningMessage('');

    const deviceFingerprint = getStoredFingerprint();

    try {
      const result = await checkMut.mutateAsync({ password, deviceFingerprint });

      if (!result.valid) {
        if (result.bound && !result.ownDevice) {
          setWarningMessage(result.message);
          setShake(true);
          setTimeout(() => setShake(false), 400);
          setPassword('');
        } else {
          setError(result.message);
          setShake(true);
          setTimeout(() => setShake(false), 400);
          setPassword('');
        }
        return;
      }

      if (!result.bound) {
        await bindMut.mutateAsync({ password, deviceFingerprint });
        setIsAuthenticated(true);
      } else {
        setIsAuthenticated(true);
      }
    } catch {
      setError('Ошибка соединения. Проверьте интернет.');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setPassword('');
    setError('');
    setWarningMessage('');
  };

  if (isAuthenticated) {
    return (
      <>
        {children}
        <button
          onClick={handleLogout}
          className="fixed bottom-4 right-4 z-[9999] px-3 py-1.5 bg-gray-800/80 text-white text-[10px] font-bold uppercase tracking-wider hover:bg-red-600 transition-colors"
        >
          &#x2715; ВЫХОД
        </button>
      </>
    );
  }

  return (
    <div className="fixed inset-0 z-[10000] bg-black flex items-center justify-center">
      <div className="absolute inset-0 opacity-5" style={{
        backgroundImage: `repeating-linear-gradient(45deg, #CC0000 0, #CC0000 1px, transparent 0, transparent 50%)`,
        backgroundSize: '20px 20px'
      }} />

      <div className={`relative w-full max-w-sm mx-4 ${shake ? 'animate-shake' : ''}`}>
        <div className="bg-white p-8 shadow-2xl">
          <div className="text-center mb-6">
            <div className="inline-block px-4 py-1.5 border border-red-200 bg-red-50 mb-4">
              <span className="text-xs font-medium text-red-600 uppercase tracking-widest">SINTEC 2027</span>
            </div>
            <h1 className="font-oswald font-bold text-2xl text-black uppercase tracking-wide">
              СТРАТЕГИЧЕСКИЙ ПОРТАЛ
            </h1>
            <p className="text-xs text-gray-400 mt-2">Доступ ограничен. Введите пароль.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <input
                type="password"
                value={password}
                onChange={(e) => { setPassword(e.target.value); setError(''); setWarningMessage(''); }}
                placeholder="Введите пароль"
                maxLength={10}
                className="w-full px-4 py-3 border border-gray-300 text-center text-lg font-mono tracking-[0.3em] text-black placeholder:text-gray-300 placeholder:tracking-normal placeholder:text-sm focus:outline-none focus:border-red-600 transition-colors"
                autoFocus
              />
            </div>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 text-xs text-red-600 text-center">{error}</div>
            )}

            {warningMessage && (
              <div className="p-4 bg-yellow-50 border-2 border-yellow-400 text-center">
                <div className="text-lg mb-1">&#x26A0;&#xFE0F;</div>
                <p className="text-xs text-yellow-800 font-medium leading-relaxed">{warningMessage}</p>
                <p className="text-[10px] text-yellow-600 mt-2">Этот пароль уже используется на другом устройстве</p>
              </div>
            )}

            <button
              type="submit"
              disabled={bindMut.isPending || checkMut.isPending}
              className="w-full py-3 bg-red-600 text-white font-oswald font-bold text-sm uppercase tracking-wider hover:bg-red-700 transition-colors disabled:opacity-50"
            >
              {checkMut.isPending ? 'ПРОВЕРКА...' : bindMut.isPending ? 'ВХОД...' : 'ВОЙТИ'}
            </button>
          </form>

          <div className="mt-6 pt-4 border-t border-gray-100 text-center">
            <p className="text-[10px] text-gray-400">Если у вас нет пароля — обратитесь к администратору</p>
          </div>
        </div>
        <div className="h-1 bg-red-600" />
      </div>

      <style>{`
        @keyframes shake { 0%,100%{transform:translateX(0)} 25%{transform:translateX(-8px)} 50%{transform:translateX(8px)} 75%{transform:translateX(-4px)} }
        .animate-shake { animation: shake 0.35s ease-in-out; }
      `}</style>
    </div>
  );
}
