import { useState } from 'react';

interface ReportEntry {
  time: string;
  task: string;
  client: string;
  type: 'visit' | 'call' | 'order' | 'training' | 'admin' | 'meeting';
  result: string;
  robotComment: string;
  status: 'done' | 'pending' | 'issue';
}

const reports: Record<string, ReportEntry[]> = {
  'b2c_regional': [
    { time: '08:00', task: 'Анализ дашборда региона', client: 'Регион Север', type: 'admin', result: 'Продажи +12% к плану', robotComment: 'Отличная динамика! 2 ТМ могут получить премию', status: 'done' },
    { time: '09:00', task: 'Проверка KPI ТМ — Соколова', client: 'ТМ Соколова', type: 'meeting', result: 'План выполнен на 95%', robotComment: 'Platinum точки растут — закрепите тренд', status: 'done' },
    { time: '10:00', task: 'Аудит нового дистрибьютора', client: 'ООО СибТорг', type: 'visit', result: 'Ассортимент 78%', robotComment: 'Недостаёт 5 SKU — отправьте заявку', status: 'done' },
    { time: '11:00', task: 'Созвон с РД по Югу', client: 'РД Петров', type: 'call', result: 'Проблемные точки переданы', robotComment: 'Контроль исполнения в пятницу', status: 'done' },
    { time: '12:00', task: 'Обед', client: '—', type: 'admin', result: '—', robotComment: '—', status: 'done' },
    { time: '13:00', task: 'Анализ конкурентов', client: '—', type: 'admin', result: 'Shell активен', robotComment: '⚠️ Shell снизил цены на 8% — контрмеры к пятнице', status: 'issue' },
    { time: '14:00', task: 'Стратегическая встреча с ТМ', client: 'ТМ Иванова', type: 'meeting', result: 'План развития Новосибирска', robotComment: 'Потенциал +30% — фокус на этом городе', status: 'done' },
    { time: '15:00', task: 'Проверка Бонус Клуб', client: '—', type: 'admin', result: '12 000 подключено', robotComment: 'Цель 20 000 — ускорьте темп', status: 'pending' },
    { time: '16:00', task: 'Подготовка квартального отчёта', client: '—', type: 'admin', result: 'Черновик готов', robotComment: 'Добавьте детализацию по каждому ТМ', status: 'pending' },
  ],
  'b2c_manager': [
    { time: '08:00', task: 'Утренний брифинг с ТП', client: 'Команда 5 ТП', type: 'meeting', result: 'Планы на день согласованы', robotComment: 'ТП Васильев рискует не выполнить план — созвон в 16:00', status: 'done' },
    { time: '09:00', task: 'Совместный выезд с ТП', client: 'ИП Кузнецов', type: 'visit', result: 'Обучение техникам продаж', robotComment: 'ТП усвоил 3 новые техники — проверьте через неделю', status: 'done' },
    { time: '10:00', task: 'EasyMerch аудит 5 точек', client: '—', type: 'admin', result: '82% качество', robotComment: 'Целевой показатель 95% — 3 точки нуждаются в доработке', status: 'done' },
    { time: '11:00', task: 'Анализ KPI команды', client: '—', type: 'admin', result: '4 из 5 ТП в плане', robotComment: 'ТП Новиков отстаёт на 15% — назначьте созвон', status: 'done' },
    { time: '12:00', task: 'Обед', client: '—', type: 'admin', result: '—', robotComment: '—', status: 'done' },
    { time: '13:00', task: 'Встреча с РД', client: 'РД Иванов', type: 'meeting', result: 'Стратегия квартала', robotComment: 'Фокус на Platinum точках — рост 20%', status: 'done' },
    { time: '14:00', task: 'Проверка шахматки ТП', client: 'ТП Смирнов', type: 'admin', result: '3 SKU отсутствуют', robotComment: 'Срочно пополните ассортимент', status: 'issue' },
    { time: '15:00', task: 'Совместный визит с ТП', client: 'СТО Мотор', type: 'visit', result: 'Заказ 85 000 ₽', robotComment: 'Отличный результат! Предложите Бонус Клуб', status: 'done' },
    { time: '16:00', task: 'Индивидуальный созвон', client: 'ТП Васильев', type: 'call', result: 'План действий на неделю', robotComment: 'Поставьте контроль на пятницу', status: 'done' },
    { time: '17:00', task: 'Обучение нового ТП', client: 'ТП Смирнов', type: 'training', result: 'Продуктовый тренинг', robotComment: 'Назначьте экзамен через 3 дня', status: 'done' },
  ],
  'b2c_representative': [
    { time: '08:00', task: 'Планирование маршрута', client: '—', type: 'admin', result: 'Маршрут на 8 точек', robotComment: 'Оптимизируйте — 2 точки дальше 15 км', status: 'done' },
    { time: '08:30', task: 'CRM: проверка задач', client: '—', type: 'admin', result: '7 задач на сегодня', robotComment: 'Приоритет: Platinum и Gold', status: 'done' },
    { time: '09:00', task: 'Визит в автомагазин «Автомир»', client: 'ООО Автомир', type: 'visit', result: 'Заказ 45 000 ₽', robotComment: 'Отлично! Platinum — предложите расширение SKU', status: 'done' },
    { time: '10:00', task: 'Визит на рынок «Южный»', client: 'ИП Петров', type: 'visit', result: 'Бонус Клуб подключён', robotComment: 'Gold статус — планируйте визит раз в 2 недели', status: 'done' },
    { time: '10:30', task: 'Проверка шахматки', client: 'ИП Петров', type: 'admin', result: 'Выкладка 90%', robotComment: 'Отправьте фото в EasyMerch', status: 'done' },
    { time: '11:00', task: 'Визит в супермаркет «Перекрёсток»', client: 'ООО Перекрёсток', type: 'visit', result: 'Аудит выкладки', robotComment: 'Выкладка 85% — отправьте фото в EasyMerch', status: 'done' },
    { time: '12:00', task: 'Обед', client: '—', type: 'admin', result: '—', robotComment: '—', status: 'done' },
    { time: '13:00', task: 'Телефонный звонок дистрибьютору', client: 'ООО Логистика-Юг', type: 'call', result: 'Согласована поставка', robotComment: 'BDM одобрил — контролируйте срок', status: 'done' },
    { time: '13:30', task: 'Визит в строймагазин «СтройДом»', client: 'ИП Сидоров', type: 'visit', result: 'Проблема с ценами', robotComment: '⚠️ Конкурент снизил цены на 10% — сообщите ТМ', status: 'issue' },
    { time: '14:00', task: 'Визит в шиномонтаж «Колесо»', client: 'ИП Колесов', type: 'visit', result: 'Заказ 12 000 ₽', robotComment: 'Silver — предложите перейти на Gold', status: 'done' },
    { time: '15:00', task: 'CRM: заполнение отчёта', client: '—', type: 'admin', result: '7 визитов внесены', robotComment: 'Заполните фотоотчёты по 2 точкам', status: 'pending' },
    { time: '15:30', task: 'AI Тренажёр: переговоры', client: '—', type: 'training', result: 'Рейтинг 78/100', robotComment: 'Практикуйте работу с возражениями', status: 'done' },
    { time: '16:00', task: 'Маршрут домой', client: '—', type: 'admin', result: '—', robotComment: 'Завтра приоритет: Platinum точки', status: 'done' },
  ],
  'online_director': [
    { time: '08:00', task: 'Анализ онлайн-дашборда', client: 'Все каналы', type: 'admin', result: 'Конверсия +5%', robotComment: 'Маркетплейсы растут — удвойте бюджет WB', status: 'done' },
    { time: '09:00', task: 'Встреча с командой', client: '11 менеджеров', type: 'meeting', result: 'Планы на неделю', robotComment: '3 магазина готовы к подключению', status: 'done' },
    { time: '10:00', task: 'Согласование с IT', client: 'Команда разработки', type: 'meeting', result: 'API интеграция на 15 сайтов', robotComment: 'Срок: 2 недели — контроль по понедельникам', status: 'done' },
    { time: '11:00', task: 'Анализ маркетплейсов', client: 'OZON, WB, Яндекс', type: 'admin', result: 'Рейтинги стабильны', robotComment: 'OZON — цены ниже на 8%, скорректируйте', status: 'done' },
    { time: '12:00', task: 'Обед', client: '—', type: 'admin', result: '—', robotComment: '—', status: 'done' },
    { time: '13:00', task: 'Стратегия подборщика', client: 'Партнёры', type: 'meeting', result: 'ТЗ на доработку', robotComment: 'Добавьте фильтр по году авто — конверсия +15%', status: 'pending' },
    { time: '14:00', task: 'Контроль API парсинга', client: '—', type: 'admin', result: '60 000+ магазинов в базе', robotComment: '100% автоматизация — ручная работа сведена к нулю', status: 'done' },
    { time: '15:00', task: 'Встреча с Яндекс Маркет', client: 'Яндекс', type: 'meeting', result: 'Условия обновлены', robotComment: 'Запуск промо в понедельник', status: 'done' },
    { time: '16:00', task: 'Анализ WB выручки', client: 'Wildberries', type: 'admin', result: 'Рост 12%', robotComment: 'Продолжайте в том же духе', status: 'done' },
  ],
  'online_marketplaces': [
    { time: '08:00', task: 'Проверка цен на OZON', client: 'OZON', type: 'admin', result: 'Цены актуальны', robotComment: '2 SKU ниже рекомендованных — скорректируйте', status: 'done' },
    { time: '09:00', task: 'Обновление карточек WB', client: 'Wildberries', type: 'admin', result: '15 карточек обновлены', robotComment: 'Добавьте видео на топ-5 SKU', status: 'done' },
    { time: '10:00', task: 'Анализ рейтингов', client: 'Все площадки', type: 'admin', result: 'Средний 4.6/5', robotComment: 'Цель 4.8 — работайте с отзывами', status: 'done' },
    { time: '11:00', task: 'Согласование акции с OZON', client: 'OZON', type: 'call', result: 'Акция с 15% скидкой', robotComment: 'Прогноз роста продаж на 25%', status: 'done' },
    { time: '12:00', task: 'Обед', client: '—', type: 'admin', result: '—', robotComment: '—', status: 'done' },
    { time: '13:00', task: 'Проверка остатков на WB', client: 'Wildberries', type: 'admin', result: 'Остатки синхронизированы', robotComment: '3 SKU на грани — пополните склад', status: 'issue' },
    { time: '14:00', task: 'Запуск рекламы на Яндекс', client: 'Яндекс Маркет', type: 'admin', result: 'Кампания активна', robotComment: 'CPC 12 ₽ — оптимально', status: 'done' },
    { time: '15:00', task: 'Отчёт по выручке', client: '—', type: 'admin', result: '45 млн ₽', robotComment: 'Цель 80 млн — ускорьте темп', status: 'pending' },
    { time: '16:00', task: 'Встреча с категорийным менеджером', client: 'OZON', type: 'meeting', result: 'Условия улучшены', robotComment: 'Эксклюзив на квартал — отлично!', status: 'done' },
  ],
  'distributors_dd': [
    { time: '08:00', task: 'Анализ дашборда дистрибьюторов', client: 'Все дистрибьюторы', type: 'admin', result: 'Объём +8% к плану', robotComment: '3 дистрибьютора отстают — созвоните РМ', status: 'done' },
    { time: '09:00', task: 'Встреча с РМ', client: 'РМ Петров', type: 'meeting', result: 'План развития Сибири', robotComment: 'Фокус на новых дистрибьюторах', status: 'done' },
    { time: '10:00', task: 'Аудит BDM — Иванов', client: 'BDM Иванов', type: 'visit', result: 'Активность 92%', robotComment: 'Отличный результат! Пример для остальных', status: 'done' },
    { time: '11:00', task: 'Созвон с ключевым дистрибьютором', client: 'ООО АвтоПартнёр', type: 'call', result: 'Контракт продлён', robotComment: 'Стратегический партнёр — приоритет в поставках', status: 'done' },
    { time: '12:00', task: 'Обед', client: '—', type: 'admin', result: '—', robotComment: '—', status: 'done' },
    { time: '13:00', task: 'Анализ автопрезентаций', client: '—', type: 'admin', result: '15 презентаций сгенерировано', robotComment: 'BDM довольны — экономия 2 часа в день', status: 'done' },
    { time: '14:00', task: 'Встреча с юристом', client: 'Юрист', type: 'meeting', result: 'Договоры на проверке', robotComment: '5 контрактов к подписанию', status: 'done' },
    { time: '15:00', task: 'Контроль Bonus Club', client: '—', type: 'admin', result: '3 200 подключено', robotComment: 'Цель 5 000 — ускорьте через BDM', status: 'pending' },
    { time: '16:00', task: 'Стратегия на квартал', client: '—', type: 'admin', result: 'Черновик готов', robotComment: 'Фокус: рост Platinum точек на 20%', status: 'pending' },
  ],
  rm: [
    { time: '08:00', task: 'Брифинг с BDM команды', client: '10 BDM', type: 'meeting', result: 'Планы на день', robotComment: 'BDM Смирнов отстаёт — индивидуальный план', status: 'done' },
    { time: '09:00', task: 'Совместный выезд с BDM', client: 'BDM Козлов', type: 'visit', result: '2 новые точки', robotComment: 'Передадите дистрибьютору — контроль', status: 'done' },
    { time: '10:00', task: 'Аудит качества BDM', client: '—', type: 'admin', result: 'EasyMerch: 82%', robotComment: 'Цель 95% — 3 BDM нуждаются в тренинге', status: 'done' },
    { time: '11:00', task: 'Созвон с новым дистрибьютором', client: 'ООО СтартАвто', type: 'call', result: 'Встреча назначена', robotComment: 'Потенциал +30 точек — подготовьте КП', status: 'done' },
    { time: '12:00', task: 'Обед', client: '—', type: 'admin', result: '—', robotComment: '—', status: 'done' },
    { time: '13:00', task: 'Анализ рынка региона', client: '—', type: 'admin', result: '3 новые возможности', robotComment: 'Тендер на поставку 500 000 ₽ — готовьте заявку', status: 'done' },
    { time: '14:00', task: 'Тренинг BDM по влиянию', client: 'Тренеры BDM', type: 'training', result: '5 BDM обучены', robotComment: 'Проверьте применение через неделю', status: 'done' },
    { time: '15:00', task: 'Контроль маршрутов BDM', client: '—', type: 'admin', result: 'GPS проверка', robotComment: '2 BDM отклонились от маршрута — разберитесь', status: 'issue' },
    { time: '16:00', task: 'Отчёт РД', client: 'РД Иванов', type: 'meeting', result: 'Регион в плане', robotComment: 'Отличная работа! 2 BDM на премию', status: 'done' },
  ],
  'distributors_bdm': [
    { time: '08:00', task: 'Планирование визитов', client: '5 дистрибьюторов', type: 'admin', result: 'Маршрут построен', robotComment: 'Приоритет: Platinum с падением', status: 'done' },
    { time: '08:30', task: 'CRM: проверка задач', client: '—', type: 'admin', result: '6 задач', robotComment: 'Фокус на Бонус Клуб — KPI', status: 'done' },
    { time: '09:00', task: 'Визит к дистрибьютору', client: 'ООО АвтоПартнёр', type: 'visit', result: 'Заказ 120 000 ₽', robotComment: 'Отлично! Предложите эксклюзив', status: 'done' },
    { time: '10:00', task: 'Совместный выезд с ТП дистр.', client: 'ТП Семёнов', type: 'training', result: 'Обучение техникам', robotComment: 'ТП усвоил — контроль через 2 недели', status: 'done' },
    { time: '10:30', task: 'Подключение к Бонус Клуб', client: 'СТО Гараж', type: 'visit', result: 'Подключено', robotComment: 'Silver — планируйте визит раз в месяц', status: 'done' },
    { time: '11:00', task: 'Аудит ассортимента', client: 'ООО АвтоПартнёр', type: 'admin', result: '78% заполненость', robotComment: 'Добавьте 5 SKU — отправьте заявку', status: 'done' },
    { time: '12:00', task: 'Обед', client: '—', type: 'admin', result: '—', robotComment: '—', status: 'done' },
    { time: '13:00', task: 'Телефонный разбор с РМ', client: 'РМ Петров', type: 'call', result: 'Проблемные точки', robotComment: '3 точки требуют внимания — план к пятнице', status: 'done' },
    { time: '13:30', task: 'Визит к дистрибьютору', client: 'ООО МоторСервис', type: 'visit', result: 'Заказ 85 000 ₽', robotComment: 'Gold статус — поддерживайте частоту', status: 'done' },
    { time: '14:00', task: 'Передача данных клиента', client: 'ООО МоторСервис', type: 'admin', result: 'Информация передана', robotComment: 'Дистрибьютор обработает в течение 24 часов', status: 'done' },
    { time: '15:00', task: 'Заполнение CRM', client: '—', type: 'admin', result: '4 визита, 2 заказа', robotComment: 'Внесите фотоотчёты и Бонус Клуб', status: 'pending' },
    { time: '15:30', task: 'AI Тренажёр: переговоры', client: '—', type: 'training', result: 'Рейтинг 82/100', robotComment: 'Отлично! Практикуйте закрытие сделок', status: 'done' },
    { time: '16:00', task: 'Маршрут домой', client: '—', type: 'admin', result: '—', robotComment: 'Завтра: Platinum точки + новый дистрибьютор', status: 'done' },
  ],
  'directors_brand': [
    { time: '08:00', task: 'Анализ доли рынка', client: '—', type: 'admin', result: '12% (+0.5%)', robotComment: 'Тренд положительный — фокус на регионах', status: 'done' },
    { time: '09:00', task: 'NPS опрос', client: '—', type: 'admin', result: '72 (цель 80+)', robotComment: 'Рост на 3 пункта — усилите программу лояльности', status: 'done' },
    { time: '10:00', task: 'ROMI анализ кампаний', client: '—', type: 'admin', result: '280%', robotComment: 'Цель 300% — оптимизируйте digital', status: 'done' },
    { time: '11:00', task: 'Встреча с рекламным агентством', client: 'Агентство', type: 'meeting', result: 'Креативы согласованы', robotComment: 'Запуск через 2 недели — контроль', status: 'done' },
    { time: '12:00', task: 'Обед', client: '—', type: 'admin', result: '—', robotComment: '—', status: 'done' },
    { time: '13:00', task: 'Анализ конкурентов', client: '—', type: 'admin', result: '3 новых продукта', robotComment: '⚠️ Shell запустил синтетику — ответная акция', status: 'issue' },
    { time: '14:00', task: 'Запуск ROLF Black Edition', client: '—', type: 'admin', result: 'Подготовка к запуску', robotComment: 'Все материалы готовы — старт 15 января', status: 'pending' },
    { time: '15:00', task: 'Контроль контрафакта', client: 'Юрист', type: 'meeting', result: '5 дел в работе', robotComment: 'Цель снизить с 15% до 5% — усильте мониторинг', status: 'done' },
    { time: '16:00', task: 'Brand Awareness отчёт', client: '—', type: 'admin', result: '65% (+2%)', robotComment: 'Рост есть — фокус на digital каналы', status: 'done' },
  ],
  'trainers_management': [
    { time: '08:00', task: 'Планирование тренингов', client: '—', type: 'admin', result: '3 тренинга на неделю', robotComment: 'Фокус на ТП с низкой конверсией', status: 'done' },
    { time: '09:00', task: 'Тренинг: переговоры', client: '5 ТП', type: 'training', result: 'Техники закрытия', robotComment: 'Практикуйте на реальных клиентах', status: 'done' },
    { time: '10:00', task: 'Совместный выезд с ТП', client: 'ТП Васильев', type: 'visit', result: 'Обратная связь', robotComment: 'ТП применил техники — рост +15%', status: 'done' },
    { time: '11:00', task: 'Оценка тренингов', client: '—', type: 'admin', result: 'Средняя оценка 4.7/5', robotComment: 'Отлично! Цель 4.5 — вы в плане', status: 'done' },
    { time: '12:00', task: 'Обед', client: '—', type: 'admin', result: '—', robotComment: '—', status: 'done' },
    { time: '13:00', task: 'Индивидуальный план ТП', client: 'ТП Новиков', type: 'meeting', result: 'План развития', robotComment: 'Фокус на работе с возражениями', status: 'done' },
    { time: '14:00', task: 'Тренинг: лидерство', client: '3 ТМ', type: 'training', result: 'Управление конфликтами', robotComment: 'Примените на практике — разбор через неделю', status: 'done' },
    { time: '15:00', task: 'Отчёт по обучению', client: '—', type: 'admin', result: '45 человек обучено', robotComment: 'Цель 50 — завтра закроете', status: 'pending' },
    { time: '16:00', task: 'Подготовка квартального плана', client: '—', type: 'admin', result: 'Черновик', robotComment: 'Фокус: 100% охват + рост KPI на 10%', status: 'pending' },
  ],
  'trainers_product': [
    { time: '08:00', task: 'Обновление продуктовых материалов', client: '—', type: 'admin', result: '5 новых презентаций', robotComment: 'Добавьте сравнение с конкурентами', status: 'done' },
    { time: '09:00', task: 'Тренинг: новые SKU', client: '8 ТП', type: 'training', result: 'ROLF Black Edition', robotComment: 'Экзамен через 3 дня — подготовьте', status: 'done' },
    { time: '10:00', task: 'Сертификация ТП', client: 'ТП Смирнов', type: 'admin', result: 'Экзамен 92/100', robotComment: 'Отлично! Сертификат выдан', status: 'done' },
    { time: '11:00', task: 'Консультация по продукту', client: 'ТМ Иванова', type: 'call', result: 'Технические вопросы', robotComment: 'Все ответы даны — ТМ уверена', status: 'done' },
    { time: '12:00', task: 'Обед', client: '—', type: 'admin', result: '—', robotComment: '—', status: 'done' },
    { time: '13:00', task: 'Обновление базы знаний', client: '—', type: 'admin', result: '3 новых статьи', robotComment: 'Добавьте FAQ по новым SKU', status: 'done' },
    { time: '14:00', task: 'Тренинг: смазки MIRAX', client: '5 ТП', type: 'training', result: 'Технические характеристики', robotComment: 'Фокус на применимость — практика', status: 'done' },
    { time: '15:00', task: 'Анализ сертификации', client: '—', type: 'admin', result: '85% сдали', robotComment: 'Цель 100% — 3 ТП на пересдачу', status: 'pending' },
  ],
  'trainers_ai': [
    { time: '08:00', task: 'AI анализ: переговоры', client: '—', type: 'training', result: 'ТП Васильев: 78/100', robotComment: 'Практикуйте работу с возражениями', status: 'done' },
    { time: '09:00', task: 'Генерация персонального плана', client: '—', type: 'admin', result: '15 планов создано', robotComment: 'Фокус: закрытие сделок для 5 ТП', status: 'done' },
    { time: '10:00', task: 'Симуляция: сложный клиент', client: '—', type: 'training', result: 'ТП Смирнов: прошёл', robotComment: 'Отличный прогресс! +12 баллов', status: 'done' },
    { time: '11:00', task: 'Обновление сценариев', client: '—', type: 'admin', result: '3 новых сценария', robotComment: 'Добавлены: ценовые возражения', status: 'done' },
    { time: '12:00', task: 'Обед', client: '—', type: 'admin', result: '—', robotComment: '—', status: 'done' },
    { time: '13:00', task: 'Рейтинг сотрудников', client: '—', type: 'admin', result: 'Лидерборд обновлён', robotComment: 'ТП Козлов №1 — премия!', status: 'done' },
    { time: '14:00', task: 'AI анализ: ТП Новиков', client: '—', type: 'training', result: 'Рейтинг 65/100', robotComment: '⚠️ Низкая конверсия — тренинг нужен', status: 'issue' },
    { time: '15:00', task: 'Синхронизация с CRM', client: '—', type: 'admin', result: 'Данные обновлены', robotComment: 'Сценарии подстроены под реальные сделки', status: 'done' },
    { time: '16:00', task: 'Генерация отчёта', client: '—', type: 'admin', result: 'Ежедневный дашборд', robotComment: '120 тренировок сегодня — рекорд!', status: 'done' },
  ],
};

const months = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
const years = ['2024', '2025', '2026'];
const days = Array.from({ length: 31 }, (_, i) => (i + 1).toString());

const typeColors: Record<string, string> = {
  visit: 'bg-blue-100 text-blue-700',
  call: 'bg-green-100 text-green-700',
  order: 'bg-purple-100 text-purple-700',
  training: 'bg-orange-100 text-orange-700',
  admin: 'bg-gray-100 text-gray-600',
  meeting: 'bg-red-100 text-red-700',
};

const typeLabels: Record<string, string> = {
  visit: 'Визит', call: 'Звонок', order: 'Заказ', training: 'Обучение', admin: 'Админ', meeting: 'Встреча',
};

interface Props {
  dept: string;
  roleKey: string;
}

export default function DailyReport({ dept, roleKey }: Props) {
  const [month, setMonth] = useState('Июнь');
  const [year, setYear] = useState('2025');
  const [day, setDay] = useState('15');
  const [clientFilter, setClientFilter] = useState('all');

  const compositeKey = `${dept}_${roleKey}`;
  const entries = reports[compositeKey] || reports['b2c_representative'];

  const filteredEntries = clientFilter === 'all'
    ? entries
    : entries.filter((e) => e.client !== '—' && e.client.toLowerCase().includes(clientFilter.toLowerCase()));

  const clients = [...new Set(entries.map((e) => e.client).filter((c) => c !== '—'))];

  const exportPDF = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    const html = `
      <html><head><meta charset="utf-8"><title>Отчёт SINTEC — ${compositeKey}</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 20px; color: #333; }
        h1 { font-size: 20px; border-bottom: 3px solid #CC0000; padding-bottom: 10px; }
        h2 { font-size: 14px; color: #666; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 11px; }
        th, td { border: 1px solid #ddd; padding: 6px; text-align: left; }
        th { background: #CC0000; color: white; }
        .done { color: green; } .pending { color: orange; } .issue { color: red; }
        .robot { color: #0066cc; font-style: italic; }
        .type { padding: 2px 6px; border-radius: 3px; font-size: 10px; }
      </style></head><body>
      <h1>Ежедневный отчёт — ${roleKey.toUpperCase()}</h1>
      <h2>${day} ${month} ${year}</h2>
      <table>
        <tr><th>Время</th><th>Тип</th><th>Задача</th><th>Клиент</th><th>Результат</th><th>🤖 Робот</th></tr>
        ${filteredEntries.map(e => `
          <tr>
            <td>${e.time}</td>
            <td>${typeLabels[e.type]}</td>
            <td>${e.task}</td>
            <td>${e.client}</td>
            <td class="${e.status}">${e.result}</td>
            <td class="robot">${e.robotComment}</td>
          </tr>
        `).join('')}
      </table>
      <p style="margin-top:20px;font-size:10px;color:#999;">Сгенерировано: ${new Date().toLocaleString('ru-RU')}</p>
      </body></html>`;
    printWindow.document.write(html);
    printWindow.document.close();
    setTimeout(() => printWindow.print(), 500);
  };

  return (
    <div className="mt-4 border-t border-gray-200 pt-4">
      <div className="flex items-center justify-between mb-3">
        <h4 className="font-oswald font-bold text-sm text-black uppercase">📋 Ежедневная отчётность</h4>
        <button onClick={exportPDF} className="px-3 py-1 bg-red-600 text-white text-[10px] font-bold uppercase hover:bg-red-700">⬇️ PDF</button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2 mb-4">
        <select value={day} onChange={(e) => setDay(e.target.value)} className="px-2 py-1 border border-gray-300 text-xs">
          {days.map((d) => <option key={d} value={d}>{d}</option>)}
        </select>
        <select value={month} onChange={(e) => setMonth(e.target.value)} className="px-2 py-1 border border-gray-300 text-xs">
          {months.map((m) => <option key={m} value={m}>{m}</option>)}
        </select>
        <select value={year} onChange={(e) => setYear(e.target.value)} className="px-2 py-1 border border-gray-300 text-xs">
          {years.map((y) => <option key={y} value={y}>{y}</option>)}
        </select>
        <select value={clientFilter} onChange={(e) => setClientFilter(e.target.value)} className="px-2 py-1 border border-gray-300 text-xs">
          <option value="all">Все клиенты</option>
          {clients.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
        <span className="text-xs text-gray-400 self-center ml-auto">{day} {month} {year}</span>
      </div>

      {/* Schedule table */}
      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-gray-100">
              <th className="p-2 text-left font-medium text-gray-500">Время</th>
              <th className="p-2 text-left font-medium text-gray-500">Тип</th>
              <th className="p-2 text-left font-medium text-gray-500">Задача</th>
              <th className="p-2 text-left font-medium text-gray-500">Клиент</th>
              <th className="p-2 text-left font-medium text-gray-500">Результат</th>
              <th className="p-2 text-left font-medium text-gray-500">🤖 Робот</th>
            </tr>
          </thead>
          <tbody>
            {filteredEntries.map((e, i) => (
              <tr key={i} className="border-t border-gray-100">
                <td className="p-2 font-mono text-gray-600">{e.time}</td>
                <td className="p-2"><span className={`px-2 py-0.5 ${typeColors[e.type]}`}>{typeLabels[e.type]}</span></td>
                <td className="p-2 text-gray-700">{e.task}</td>
                <td className="p-2 text-gray-500">{e.client}</td>
                <td className="p-2">
                  <span className={e.status === 'issue' ? 'text-red-600 font-medium' : e.status === 'pending' ? 'text-orange-500' : 'text-green-600'}>{e.result}</span>
                </td>
                <td className="p-2 max-w-[200px]">
                  {e.robotComment && (
                    <span className={e.robotComment.startsWith('⚠️') ? 'text-red-500 text-xs' : e.robotComment.startsWith('Отлично') || e.robotComment.startsWith('Отличная') ? 'text-green-600 text-xs' : 'text-blue-600 text-xs'}>{e.robotComment}</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Summary */}
      <div className="mt-3 p-3 bg-gray-50 border border-gray-200 text-xs text-gray-600">
        <strong>Итого:</strong> {filteredEntries.filter((e) => e.status === 'done').length} выполнено |{' '}
        {filteredEntries.filter((e) => e.status === 'pending').length} в ожидании |{' '}
        {filteredEntries.filter((e) => e.status === 'issue').length} проблем |{' '}
        <span className="text-blue-600 ml-2">🤖 {filteredEntries.filter((e) => e.robotComment && !e.robotComment.startsWith('—')).length} рекомендаций робота</span>
      </div>
    </div>
  );
}
