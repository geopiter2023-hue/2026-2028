import { useState } from 'react';

interface ReportEntry {
  time: string;
  task: string;
  client: string;
  type: 'visit' | 'call' | 'order' | 'training' | 'admin' | 'meeting';
  result: string;
  robotComment: string;
  status: 'done' | 'pending' | 'issue';
}

const scheduleTemplate: Record<string, ReportEntry[]> = {
  'ТП': [
    { time: '08:00', task: 'Планирование маршрута', client: '—', type: 'admin', result: 'Маршрут на 8 точек', robotComment: 'Оптимизируйте маршрут — 2 точки дальше 15 км от основной зоны', status: 'done' },
    { time: '09:00', task: 'Визит в автомагазин «Автомир»', client: 'ООО Автомир', type: 'visit', result: 'Заказ 45 000 ₽', robotComment: 'Отличный результат! Точка Platinum — предложите расширение ассортимента', status: 'done' },
    { time: '10:30', task: 'Визит на рынок «Южный»', client: 'ИП Петров', type: 'visit', result: 'Бонус Клуб подключён', robotComment: 'Gold статус — планируйте визит раз в 2 недели', status: 'done' },
    { time: '12:00', task: 'Обеденный перерыв', client: '—', type: 'admin', result: '—', robotComment: '—', status: 'done' },
    { time: '13:00', task: 'Визит в супермаркет «Перекрёсток»', client: 'ООО Перекрёсток', type: 'visit', result: 'Аудит выкладки', robotComment: 'Выкладка 85% — отправьте фото в EasyMerch', status: 'done' },
    { time: '14:30', task: 'Телефонный звонок дистрибьютору', client: 'ООО Логистика-Юг', type: 'call', result: 'Согласована поставка', robotComment: 'BDM одобрил — контролируйте срок поставки', status: 'done' },
    { time: '15:00', task: 'Визит в строймагазин «СтройДом»', client: 'ИП Сидоров', type: 'visit', result: 'Проблема с ценами', robotComment: '⚠️ Конкурент снизил цены на 10% — сообщите ТМ', status: 'issue' },
    { time: '16:30', task: 'Отчётность в CRM', client: '—', type: 'admin', result: '7 визитов внесены', robotComment: 'Заполните фотоотчёты по 2 точкам', status: 'pending' },
  ],
  'ТМ': [
    { time: '08:00', task: 'Утренний брифинг с ТП', client: 'Команда 5 ТП', type: 'meeting', result: 'Планы на день согласованы', robotComment: 'ТП Васильев рискует не выполнить план — созвон в 16:00', status: 'done' },
    { time: '09:30', task: 'Совместный выезд с ТП', client: 'ИП Кузнецов', type: 'visit', result: 'Обучение техникам продаж', robotComment: 'ТП усвоил 3 новые техники — проверьте через неделю', status: 'done' },
    { time: '11:00', task: 'Анализ KPI команды', client: '—', type: 'admin', result: '4 из 5 ТП в плане', robotComment: 'ТП Новиков отстаёт на 15% — назначьте созвон', status: 'done' },
    { time: '13:00', task: 'Встреча с РД', client: 'РД Иванов', type: 'meeting', result: 'Стратегия квартала', robotComment: 'Фокус на Platinum точках — рост 20%', status: 'done' },
    { time: '14:30', task: 'EasyMerch аудит', client: '15 точек', type: 'admin', result: '82% качество', robotComment: 'Целевой показатель 95% — 3 точки нуждаются в доработке', status: 'done' },
    { time: '16:00', task: 'Индивидуальный созвон с ТП', client: 'ТП Васильев', type: 'call', result: 'План действий на неделю', robotComment: 'Поставьте контроль на пятницу — проверка выполнения', status: 'done' },
    { time: '17:00', task: 'Обучение нового ТП', client: 'ТП Смирнов', type: 'training', result: 'Продуктовый тренинг', robotComment: 'Назначьте экзамен через 3 дня', status: 'done' },
  ],
  'РД': [
    { time: '08:00', task: 'Анализ дашборда региона', client: 'Регион Север', type: 'admin', result: 'Продажи +12% к плану', robotComment: 'Отличная динамика! 2 ТМ могут получить премию', status: 'done' },
    { time: '09:30', task: 'Стратегическая встреча с ТМ', client: 'ТМ Соколова', type: 'meeting', result: 'План развития территории', robotComment: 'Фокус на городе Новосибирск — потенциал +30%', status: 'done' },
    { time: '11:00', task: 'Аудит нового дистрибьютора', client: 'ООО СибТорг', type: 'visit', result: 'Ассортимент 78%', robotComment: 'Недостаёт 5 SKU — отправьте заявку на поставку', status: 'done' },
    { time: '13:00', task: 'Конференция с директором', client: 'Директор B2C', type: 'meeting', result: 'Квартальный отчёт', robotComment: 'Подготовьте детализацию по каждому ТМ', status: 'done' },
    { time: '15:00', task: 'Анализ конкурентов', client: '—', type: 'admin', result: 'Отчёт по 3 брендам', robotComment: 'Shell активен в вашем регионе — контрмеры к пятнице', status: 'done' },
    { time: '16:30', task: 'Разработка мотивации', client: 'Команда 9 ТМ', type: 'admin', result: 'Новая схема премий', robotComment: 'Фокус на Бонус Клуб — KPI на квартал', status: 'pending' },
  ],
  'BDM': [
    { time: '08:00', task: 'Планирование визитов', client: '5 дистрибьюторов', type: 'admin', result: 'Маршрут построен', robotComment: 'Приоритет: Platinum точки с падением заказов', status: 'done' },
    { time: '09:00', task: 'Визит к дистрибьютору «АвтоПартнёр»', client: 'ООО АвтоПартнёр', type: 'visit', result: 'Заказ 120 000 ₽', robotComment: 'Отлично! Предложите эксклюзив на квартал', status: 'done' },
    { time: '10:30', task: 'Совместный выезд с ТП дистрибьютора', client: 'ТП дистрибьютора Семёнов', type: 'training', result: 'Обучение техникам продаж', robotComment: 'ТП усвоил техники — контроль через 2 недели', status: 'done' },
    { time: '12:00', task: 'Обед', client: '—', type: 'admin', result: '—', robotComment: '—', status: 'done' },
    { time: '13:00', task: 'Аудит точки «Гараж»', client: 'СТО Гараж', type: 'visit', result: 'Бонус Клуб подключён', robotComment: 'Silver статус — планируйте визит раз в месяц', status: 'done' },
    { time: '14:30', task: 'Телефонный разбор с РМ', client: 'РМ Петров', type: 'call', result: 'Проблемные точки обсуждены', robotComment: '3 точки требуют внимания — план к пятнице', status: 'done' },
    { time: '15:30', task: 'Заполнение CRM', client: '—', type: 'admin', result: '4 визита, 2 заказа', robotComment: 'Внесите фотоотчёты и обновите статус Бонус Клуб', status: 'pending' },
  ],
  'Директор онлайн': [
    { time: '08:00', task: 'Анализ онлайн-дашборда', client: 'Все каналы', type: 'admin', result: 'Конверсия +5%', robotComment: 'Маркетплейсы растут — удвойте рекламный бюджет WB', status: 'done' },
    { time: '09:30', task: 'Встреча с командой', client: '11 менеджеров', type: 'meeting', result: 'Планы на неделю', robotComment: '3 магазина готовы к подключению — назначьте встречи', status: 'done' },
    { time: '11:00', task: 'Согласование с IT', client: 'Команда разработки', type: 'meeting', result: 'API интеграция на 15 сайтов', robotComment: 'Срок: 2 недели — контроль каждый понедельник', status: 'done' },
    { time: '13:00', task: 'Анализ маркетплейсов', client: 'OZON, WB, Яндекс', type: 'admin', result: 'Рейтинги стабильны', robotComment: 'OZON — цены ниже рыночных на 8%, скорректируйте', status: 'done' },
    { time: '15:00', task: 'Стратегия подборщика', client: 'Партнёры', type: 'meeting', result: 'ТЗ на доработку', robotComment: 'Добавьте фильтр по году авто — увеличит конверсию на 15%', status: 'pending' },
  ],
};

const months = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
const years = ['2024', '2025', '2026'];
const days = Array.from({ length: 31 }, (_, i) => (i + 1).toString());

const typeColors: Record<string, string> = {
  visit: 'bg-blue-100 text-blue-700',
  call: 'bg-green-100 text-green-700',
  order: 'bg-purple-100 text-purple-700',
  training: 'bg-orange-100 text-orange-700',
  admin: 'bg-gray-100 text-gray-600',
  meeting: 'bg-red-100 text-red-700',
};

const typeLabels: Record<string, string> = {
  visit: 'Визит', call: 'Звонок', order: 'Заказ', training: 'Обучение', admin: 'Админ', meeting: 'Встреча',
};

interface Props {
  roleTitle: string;
}

export default function DailyReport({ roleTitle }: Props) {
  const [month, setMonth] = useState('Июнь');
  const [year, setYear] = useState('2025');
  const [day, setDay] = useState('15');
  const [clientFilter, setClientFilter] = useState('all');

  const roleKey = Object.keys(scheduleTemplate).find((k) => roleTitle.includes(k)) || 'ТП';
  const entries = scheduleTemplate[roleKey] || scheduleTemplate['ТП'];

  const filteredEntries = clientFilter === 'all'
    ? entries
    : entries.filter((e) => e.client !== '—' && e.client.toLowerCase().includes(clientFilter.toLowerCase()));

  const clients = [...new Set(entries.map((e) => e.client).filter((c) => c !== '—'))];

  return (
    <div className="mt-4 border-t border-gray-200 pt-4">
      <h4 className="font-oswald font-bold text-sm text-black uppercase mb-3">📋 Ежедневная отчётность</h4>

      {/* Filters */}
      <div className="flex flex-wrap gap-2 mb-4">
        <select value={day} onChange={(e) => setDay(e.target.value)} className="px-2 py-1 border border-gray-300 text-xs">
          {days.map((d) => <option key={d} value={d}>{d}</option>)}
        </select>
        <select value={month} onChange={(e) => setMonth(e.target.value)} className="px-2 py-1 border border-gray-300 text-xs">
          {months.map((m) => <option key={m} value={m}>{m}</option>)}
        </select>
        <select value={year} onChange={(e) => setYear(e.target.value)} className="px-2 py-1 border border-gray-300 text-xs">
          {years.map((y) => <option key={y} value={y}>{y}</option>)}
        </select>
        <select value={clientFilter} onChange={(e) => setClientFilter(e.target.value)} className="px-2 py-1 border border-gray-300 text-xs">
          <option value="all">Все клиенты</option>
          {clients.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
        <span className="text-xs text-gray-400 self-center ml-auto">{day} {month} {year}</span>
      </div>

      {/* Schedule table */}
      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-gray-100">
              <th className="p-2 text-left font-medium text-gray-500">Время</th>
              <th className="p-2 text-left font-medium text-gray-500">Тип</th>
              <th className="p-2 text-left font-medium text-gray-500">Задача</th>
              <th className="p-2 text-left font-medium text-gray-500">Клиент</th>
              <th className="p-2 text-left font-medium text-gray-500">Результат</th>
              <th className="p-2 text-left font-medium text-gray-500">🤖 Робот</th>
            </tr>
          </thead>
          <tbody>
            {filteredEntries.map((e, i) => (
              <tr key={i} className="border-t border-gray-100">
                <td className="p-2 font-mono text-gray-600">{e.time}</td>
                <td className="p-2">
                  <span className={`px-2 py-0.5 ${typeColors[e.type]}`}>{typeLabels[e.type]}</span>
                </td>
                <td className="p-2 text-gray-700">{e.task}</td>
                <td className="p-2 text-gray-500">{e.client}</td>
                <td className="p-2">
                  <span className={e.status === 'issue' ? 'text-red-600 font-medium' : e.status === 'pending' ? 'text-orange-500' : 'text-green-600'}>
                    {e.result}
                  </span>
                </td>
                <td className="p-2 text-gray-500 max-w-[200px]">
                  {e.robotComment && (
                    <span className={e.robotComment.startsWith('⚠️') ? 'text-red-500' : e.robotComment.startsWith('Отлично') || e.robotComment.startsWith('Отличная') ? 'text-green-600' : 'text-blue-600'}>
                      {e.robotComment}
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Summary */}
      <div className="mt-3 p-3 bg-gray-50 border border-gray-200 text-xs text-gray-600">
        <strong>Итого:</strong> {filteredEntries.filter((e) => e.status === 'done').length} выполнено |
        {filteredEntries.filter((e) => e.status === 'pending').length} в ожидании |
        {filteredEntries.filter((e) => e.status === 'issue').length} проблем |
        <span className="text-blue-600 ml-2">🤖 {filteredEntries.filter((e) => e.robotComment && !e.robotComment.startsWith('—')).length} рекомендаций робота</span>
      </div>
    </div>
  );
}
