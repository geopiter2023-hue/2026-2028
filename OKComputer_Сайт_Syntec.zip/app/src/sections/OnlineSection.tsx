import DepartmentCard from '../components/DepartmentCard';
export default function OnlineSection() { return <DepartmentCard id="online" title="Онлайн" director="Директор онлайн-продаж Россия" accentColor="#006b4f" icon={<span className="text-xl">&#x1F310;</span>} index={3} roles={[{ title: 'E-com менеджеры', count: 3, subtitle: 'Офис' }, { title: 'Менеджеры', count: 4, subtitle: 'Офис' }]} />; }
