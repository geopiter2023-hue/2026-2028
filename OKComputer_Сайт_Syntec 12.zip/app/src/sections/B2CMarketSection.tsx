const steps = [
  {
    num: '01',
    title: 'ОПИСАНИЕ ТОЧЕК',
    short: 'Сбор данных: формат, ассортимент, локация, продажи',
    color: '#CC0000',
    details: [
      'Торговый представитель заполняет карточку каждой торговой точки при первом визите',
      'Фиксируется: формат магазина, площадь, ассортимент конкурентов, текущие продажи SINTEC',
      'GPS-координаты точки для построения оптимального маршрута',
      'Фотоотчёт внешнего вида и выкладки продукции',
      'Все данные сохраняются в CRM и доступны менеджеру в реальном времени',
    ],
  },
  {
    num: '02',
    title: 'СЕГМЕНТАЦИЯ',
    short: 'Разделение по потенциалу: высокий, средний, базовый',
    color: '#8B3A00',
    details: [
      'Система автоматически анализирует собранные данные и присваивает точке сегмент',
      'Высокий потенциал — крупные магазины, высокий трафик, готовность расширить ассортимент',
      'Средний потенциал — стабильные продажи, возможность увеличить долю полки',
      'Базовый потенциал — поддержание присутствия, стандартная выкладка',
      'Сегментация обновляется ежемесячно на основе динамики продаж',
    ],
  },
  {
    num: '03',
    title: 'РАЗВИТИЕ В ТТ',
    short: 'Расширение ассортимента, мерчендайзинг, обучение',
    color: '#005f7f',
    details: [
      'Для каждой точки формируется индивидуальный план развития в CRM',
      'Торговый представитель получает задачи на визит: расширить ассортимент, обновить выкладку',
      'Мерчендайзинг — контроль полочного пространства по шахматке продуктов',
      'Обучение персонала магазина — презентация продуктов, акции, бонусная программа',
      'Результат — рост среднего чека и увеличение доли SINTEC в точке',
    ],
  },
];

export default function B2CMarketSection() {
  return (
    <section className="py-16 px-4 bg-white">
      <div className="max-w-[700px] mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 border border-red-200 bg-red-50">
            <span className="text-xs font-medium text-red-600 uppercase tracking-widest">&#x1F4CD; Рынок B2C</span>
          </div>
          <h2 className="font-oswald font-bold text-3xl lg:text-4xl text-black mb-2">60 000+ ТОРГОВЫХ ТОЧЕК</h2>
          <p className="text-sm text-gray-500 mb-8">Российский рынок — десятки тысяч точек различных форматов</p>

          {/* Formats */}
          <div className="flex flex-col gap-3 max-w-[500px] mx-auto mb-10">
            <div className="flex gap-3">
              {['&#x1F698; Автомагазины', '&#x1F3EA; Рынки и прилавки'].map((f, i) => (
                <div key={i} className="flex-1 p-3 border border-gray-200 bg-gray-50 text-center">
                  <span className="text-sm text-black" dangerouslySetInnerHTML={{ __html: f }} />
                </div>
              ))}
            </div>
            <div className="flex gap-3">
              {['&#x1F3EC; Супермаркеты', '&#x1F6E0; Строительные магазины'].map((f, i) => (
                <div key={i} className="flex-1 p-3 border border-gray-200 bg-gray-50 text-center">
                  <span className="text-sm text-black" dangerouslySetInnerHTML={{ __html: f }} />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 3 Steps — clickable accordion */}
        <h3 className="font-oswald font-bold text-xl text-black text-center mb-4">3 ШАГА КАЧЕСТВЕННОЙ БАЗЫ</h3>
        <div className="space-y-3">
          {steps.map((s, i) => (
            <details key={i} className="group border border-gray-200 bg-white cursor-pointer">
              <summary className="flex items-center gap-3 p-4 list-none">
                <span className="w-8 h-8 flex-shrink-0 flex items-center justify-center text-white text-sm font-oswald font-bold" style={{ backgroundColor: s.color }}>{s.num}</span>
                <div className="flex-1">
                  <h4 className="font-oswald font-bold text-base text-black uppercase">{s.title}</h4>
                  <p className="text-xs text-gray-400">{s.short}</p>
                </div>
                <span className="text-gray-400 group-open:rotate-180 transition-transform text-lg">&#x25BC;</span>
              </summary>
              <div className="px-4 pb-4 pt-0">
                <div className="h-px w-full bg-gray-200 mb-3 ml-11" />
                <ul className="space-y-2 ml-11">
                  {s.details.map((d, j) => (
                    <li key={j} className="flex items-start gap-2 text-sm text-gray-600">
                      <span style={{ color: s.color }}>&#x2714;</span>
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}
