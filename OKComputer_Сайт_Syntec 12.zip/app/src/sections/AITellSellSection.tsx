const capabilities = [
  { icon: '\u{1F4DE}', title: 'Телефонные звонки', desc: 'Звонит от лица компании SINTEC' },
  { icon: '\u{1F4CB}', title: 'Сбор заказов', desc: 'Принимает заказы, фиксирует объёмы' },
  { icon: '\u{1F4AC}', title: 'Обратная связь', desc: 'Собирает отзывы клиентов' },
  { icon: '\u{1F3A7}', title: 'Поддержка клиентов', desc: 'Отвечает на вопросы' },
  { icon: '\u{1F4D6}', title: 'Тех. параметры', desc: 'Знает все характеристики' },
  { icon: '\u{1F441}', title: 'Тайные звонки', desc: 'Проверка качества' },
  { icon: '\u{1F465}', title: 'Внутренние звонки', desc: 'Созванивается в компании' },
  { icon: '\u{1F3A4}', title: 'Запись разговоров', desc: 'Фиксирует все диалоги' },
  { icon: '\u{1F4DD}', title: 'Расшифровка в текст', desc: 'Автоперевод аудио' },
  { icon: '\u{1F4C8}', title: 'Ежедневный дашборд', desc: 'Отчёты каждый день' },
  { icon: '\u{1F9D1}\u200D\u{1F4BC}', title: 'Поиск кандидатов', desc: 'Ищет сотрудников' },
  { icon: '\u{1F4BC}', title: 'Собеседования', desc: 'Проводит интервью' },
];

export default function AITellSellSection() {
  return (
    <section className="relative py-20 px-4 overflow-hidden">
      {/* Ярко-красный фон */}
      <div className="absolute inset-0 bg-gradient-to-br from-red-600 via-red-700 to-red-900" />
      <div className="absolute inset-0 opacity-10" style={{
        backgroundImage: 'radial-gradient(circle at 30% 20%, rgba(255,255,255,0.3) 0%, transparent 50%), radial-gradient(circle at 70% 80%, rgba(0,0,0,0.2) 0%, transparent 50%)'
      }} />

      <div className="relative z-10 max-w-[1000px] mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-5 py-2 mb-6 border border-white/30 bg-white/15 rounded-full">
            <span className="text-sm font-medium text-white uppercase tracking-widest">&#x1F916; Искусственный интеллект</span>
          </div>

          <h2 className="font-oswald font-bold text-5xl lg:text-7xl text-white mb-4 tracking-tight">
            AI <span className="text-yellow-300">Tell</span>Sell
          </h2>

          <p className="text-base text-white/80 max-w-lg mx-auto">
            Человекоподобный робот для увеличения продаж. Работает 24/7.
          </p>

          <div className="inline-flex items-center gap-3 px-5 py-3 mt-6 bg-black/20 border border-white/10 rounded-lg">
            <span className="text-2xl">&#x1F916;</span>
            <div className="text-left">
              <p className="text-sm text-white font-medium">AI-ассистент отдела продаж</p>
              <p className="text-xs text-white/60">Звонки · Заказы · Аналитика · HR</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {capabilities.map((c, i) => (
            <div key={i} className="p-4 bg-gray-900/60 border border-white/10 hover:bg-gray-900/80 hover:border-white/25 transition-all duration-300 rounded-lg">
              <span className="text-xl mb-2 block">{c.icon}</span>
              <h4 className="font-oswald font-bold text-sm text-white mb-1 uppercase tracking-wide">{c.title}</h4>
              <p className="text-xs text-white/50 leading-relaxed">{c.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-10 text-center">
          <p className="text-xs text-white/40">AI TellSell — ваш виртуальный сотрудник отдела продаж</p>
        </div>
      </div>
    </section>
  );
}
