const brands = [
  { name: 'SINTEC', desc: 'Основной бренд', color: '#FF0000' },
  { name: 'TAKAYAMA', desc: 'Моторные масла', color: '#CC0000' },
  { name: 'MIRAX', desc: 'Смазочные материалы', color: '#1a2744' },
  { name: 'ROLF', desc: 'Премиум линейка', color: '#000000' },
  { name: 'Автокосметика\nSINTEC', desc: 'Линейка автокосметики', color: '#b3cc00', isText: true },
];

export default function BrandsSection() {
  return (
    <section id="brands" className="py-16 px-4 bg-white">
      <div className="max-w-[800px] mx-auto">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 border border-red-200 bg-red-50">
            <span className="text-xs font-medium text-red-600 uppercase tracking-widest">&#x2B50; Портфель</span>
          </div>
          <h2 className="font-oswald font-bold text-4xl lg:text-5xl text-black mb-2">БРЕНДЫ</h2>
          <p className="text-sm text-gray-500">Стратегическое управление портфелем брендов SINTEC</p>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
          {brands.map((b, i) => (
            <div key={i} className="p-4 lg:p-6 border border-gray-200 bg-gray-50/50 text-center flex flex-col items-center justify-center min-h-[100px] hover:border-gray-300 transition-all">
              {b.isText ? (
                <span className="font-oswald font-bold text-base lg:text-lg leading-tight whitespace-pre-line" style={{ color: b.color }}>{b.name}</span>
              ) : (
                <span className="font-oswald font-bold text-xl lg:text-2xl" style={{ color: b.color }}>{b.name}</span>
              )}
              <div className="h-0.5 w-6 mt-2 mb-1" style={{ backgroundColor: b.color }} />
              <p className="text-[10px] text-gray-400">{b.desc}</p>
            </div>
          ))}
        </div>
        <p className="text-center text-xs text-gray-400 mt-6">{brands.length} брендов под управлением</p>
      </div>
    </section>
  );
}
