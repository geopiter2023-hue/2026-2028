import { useState } from 'react';
import KPIModal from '../components/KPIModal';

const flModules = [
  {
    num: '01',
    emoji: '\u{1F3EA}',
    title: 'Подключение ИП и самозанятых',
    color: '#CC0000',
    details: [
      'Поиск и привлечение индивидуальных предпринимателей — владельцев автомагазинов, шиномонтажей, мелких СТО',
      'Упрощённая процедура подключения: минимальный пакет документов, быстрое согласование условий',
      'Стартовый ассортимент: формирование базового набора SKU под формат точки с фокусом на ходовые позиции',
      'Обучение ИП: базовые техники продаж, преимущества брендов SINTEC, работа с возражениями',
      'Программа «Старт»: скидки на первый заказ, отсрочка платежа, POS-материалы для новых партнёров',
    ],
  },
  {
    num: '02',
    emoji: '\u{1F4B0}',
    title: 'Финансовая поддержка ФЛ',
    color: '#990000',
    details: [
      'Гибкие условия оплаты: отсрочка 14-30 дней для проверенных ИП, работа с предоплатой для новых',
      'Минимальная сумма заказа: сниженный порог для старта — от 10 000 ₽ на первые 3 заказа',
      'Бонус Клуб для ИП: накопительная система скидок, чем больше заказ — тем выгоднее условия',
      'Кредитный лимит: индивидуальное решение по лимиту на основе истории заказов и платежной дисциплины',
      'Программа лояльности: кэшбэк на баланс, подарочные наборы за объём, участие в закрытых распродажах',
    ],
  },
  {
    num: '03',
    emoji: '\u{1F4E6}',
    title: 'Логистика и доставка ФЛ',
    color: '#660000',
    details: [
      'Доставка до двери: собственная логистика или партнёрские службы доставки по всей России',
      'Самовывоз со склада: опция для крупных городов — экономия на доставке и быстрое получение',
      'Отправка транспортными компаниями: ПЭК, Деловые Линии, Байкал Сервис — выбор перевозчика',
      'Отслеживание заказа: номер отслеживания в личном кабинете, SMS-уведомления о статусе',
      'Возврат и обмен: упрощённая процедура для брака или некорректного заказа в течение 14 дней',
    ],
  },
  {
    num: '04',
    emoji: '\u{1F4CA}',
    title: 'Развитие и рост ФЛ',
    color: '#CC0000',
    details: [
      'План развития точки: ежеквартальный аудит ассортимента, рекомендации по расширению SKU',
      'Совместные промо-акции: участие ИП в региональных акциях SINTEC — рост трафика и продаж',
      'Переход на юр. лицо: сопровождение ИП при масштабировании — помощь в оформлении ООО',
      'Менторство от ТП: закрепление торгового представителя за активными ИП для регулярной поддержки',
      'Рейтинг партнёров: публичный рейтинг лучших ИП — премии и приоритет в акциях для топов',
    ],
  },
];

const ulModules = [
  {
    num: '01',
    emoji: '\u{1F3E2}',
    title: 'Подключение юридических лиц',
    color: '#1a2744',
    details: [
      'Работа с ООО и АО: полный цикл от первой встречи до подписания договора поставки',
      'Юридическое сопровождение: согласование договора, спецификаций, приложений с юристами клиента',
      'Тендерные закупки: помощь в подготовке документов для участия в тендерах крупных сетей',
      'Индивидуальные условия: разработка персональных цен, скидок и бонусов под объём заказчика',
      'Выделенный менеджер: закрепление ключевого менеджера для оперативного решения вопросов',
    ],
  },
  {
    num: '02',
    emoji: '\u{1F4CB}',
    title: 'Контракты и условия',
    color: '#243352',
    details: [
      'Долгосрочные договоры: контракты на 12-24 месяца с фиксированными ценами и гарантированными объёмами',
      'Гибкая система скидок: прогрессивная шкала скидок в зависимости от объёма закупок за квартал',
      'Отсрочка платежа: до 60 дней для крупных контрагентов с положительной кредитной историей',
      'Эксклюзивные условия: особые условия для стратегических партнёров — крупнейших дистрибьюторов и сетей',
      'Штрафные санкции: прозрачная система штрафов за нарушение сроков и условий с обеих сторон',
    ],
  },
  {
    num: '03',
    emoji: '\u{1F69B}',
    title: 'Логистика и склад для ЮЛ',
    color: '#2e3f62',
    details: [
      'Прямые поставки на склад: доставка крупными партиями на склад клиента или дистрибьютора',
      'Just-in-Time поставки: точная доставка по графику под производственные потребности клиента',
      'EDI-интеграция: электронный обмен документами — заказы, накладные, счета через API',
      'Управление запасами: совместный прогноз спроса, планирование пополнения, контроль остатков',
      'Мультимодальные перевозки: автомобиль, ЖД, контейнеры — оптимальный способ доставки',
    ],
  },
  {
    num: '04',
    emoji: '\u{1F3AF}',
    title: 'Развитие партнёрства ЮЛ',
    color: '#384d72',
    details: [
      'Квартальные бизнес-ревью: совместный анализ продаж, планов на квартал, корректировка стратегии',
      'Совместный маркетинг: ко-финансирование промо-акций, размещение в каналах коммуникации',
      'Обучение персонала: проведение тренингов для сотрудников клиента по продуктам SINTEC',
      'Программа «Стратегический партнёр»: особые условия, приоритет в поставках, доступ к новинкам',
      'Аудит удовлетворённости: ежегодный опрос NPS среди юридических клиентов — минимальный показатель 80+',
    ],
  },
];

export default function BrandStoresSection() {
  const [activeRole, setActiveRole] = useState<string | null>(null);

  return (
    <section id="brand-stores" className="py-16 px-4 bg-white">
      <div className="max-w-[900px] mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 border border-red-200 bg-red-50">
            <span className="text-xs font-medium text-red-600 uppercase tracking-widest">&#x1F3EA; Развитие магазинов</span>
          </div>
          <h2 className="font-oswald font-bold text-3xl lg:text-4xl text-black mb-2">МАГАЗИНЫ БРЕНДА</h2>
          <p className="text-sm text-gray-500 max-w-lg mx-auto">Развитие сети магазинов бренда SINTEC — физические и юридические лица</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-3 mb-8 max-w-[400px] mx-auto">
          {[
            { val: 'ФЛ', label: 'Физические лица', color: '#CC0000' },
            { val: 'ЮЛ', label: 'Юридические лица', color: '#1a2744' },
          ].map((s, i) => (
            <div key={i} className="p-3 border border-gray-200 bg-gray-50 text-center">
              <span className="font-oswald font-bold text-2xl" style={{ color: s.color }}>{s.val}</span>
              <p className="text-[10px] text-gray-400 uppercase tracking-wider mt-1">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="h-px w-full bg-red-200 mb-6" />

        {/* KPI buttons for directors */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {[
            { key: 'brand', label: 'KPI Бренд-директора', color: '#CC0000' },
            { key: 'commercial', label: 'KPI Коммерческого директора', color: '#1a2744' },
            { key: 'marketing', label: 'KPI Директора по маркетингу', color: '#2e3f62' },
          ].map((d, i) => (
            <button
              key={i}
              onClick={() => setActiveRole(d.key)}
              className="px-4 py-2 text-white text-xs font-bold uppercase hover:opacity-90 transition-opacity"
              style={{ backgroundColor: d.color }}
            >
              {d.label}
            </button>
          ))}
        </div>

        <div className="h-px w-full bg-gray-200 mb-6" />

        {/* FL Section */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <span className="text-2xl">&#x1F464;</span>
            <div>
              <h3 className="font-oswald font-bold text-xl text-black uppercase">ФИЗИЧЕСКИЕ ЛИЦА</h3>
              <p className="text-xs text-gray-400">ИП, самозанятые, частные торговые точки</p>
            </div>
          </div>

          <div className="space-y-3">
            {flModules.map((m, i) => (
              <details key={i} className="group border border-red-200 bg-red-50/30 cursor-pointer">
                <summary className="flex items-center gap-3 p-4 list-none">
                  <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center font-oswald font-bold text-white text-sm" style={{ backgroundColor: m.color }}>
                    {m.num}
                  </div>
                  <span className="text-2xl flex-shrink-0">{m.emoji}</span>
                  <h3 className="font-oswald font-bold text-base text-black uppercase flex-1">{m.title}</h3>
                  <span className="text-gray-400 group-open:rotate-180 transition-transform text-sm">&#x25BC;</span>
                </summary>
                <div className="px-4 pb-4">
                  <div className="h-px w-full bg-red-200 mb-3 ml-16" />
                  <ul className="space-y-2 ml-16">
                    {m.details.map((d, j) => (
                      <li key={j} className="flex items-start gap-2 text-sm text-gray-600">
                        <span style={{ color: m.color }}>&#x2714;</span>
                        <span>{d}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </details>
            ))}
          </div>
        </div>

        <div className="h-px w-full bg-gray-200 mb-6" />

        {/* UL Section */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <span className="text-2xl">&#x1F3E2;</span>
            <div>
              <h3 className="font-oswald font-bold text-xl text-black uppercase">ЮРИДИЧЕСКИЕ ЛИЦА</h3>
              <p className="text-xs text-gray-400">ООО, АО, корпоративные клиенты, дистрибьюторы, сети</p>
            </div>
          </div>

          <div className="space-y-3">
            {ulModules.map((m, i) => (
              <details key={i} className="group border border-blue-200 bg-blue-50/30 cursor-pointer">
                <summary className="flex items-center gap-3 p-4 list-none">
                  <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center font-oswald font-bold text-white text-sm" style={{ backgroundColor: m.color }}>
                    {m.num}
                  </div>
                  <span className="text-2xl flex-shrink-0">{m.emoji}</span>
                  <h3 className="font-oswald font-bold text-base text-black uppercase flex-1">{m.title}</h3>
                  <span className="text-gray-400 group-open:rotate-180 transition-transform text-sm">&#x25BC;</span>
                </summary>
                <div className="px-4 pb-4">
                  <div className="h-px w-full bg-blue-200 mb-3 ml-16" />
                  <ul className="space-y-2 ml-16">
                    {m.details.map((d, j) => (
                      <li key={j} className="flex items-start gap-2 text-sm text-gray-600">
                        <span style={{ color: m.color }}>&#x2714;</span>
                        <span>{d}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </details>
            ))}
          </div>
        </div>

        {/* Bottom principle */}
        <div className="mt-4 p-4 bg-gray-50 border border-gray-200 rounded-lg text-center">
          <p className="text-sm text-gray-700">
            <span className="font-semibold text-red-600">ФЛ:</span> Быстрый старт, гибкие условия, рост до ЮЛ &nbsp;|&nbsp; <span className="font-semibold text-blue-900">ЮЛ:</span> Долгосрочные контракты, EDI, стратегическое партнёрство
          </p>
        </div>
      </div>

      <KPIModal dept="directors" roleKey={activeRole} onClose={() => setActiveRole(null)} />
    </section>
  );
}
