export default function FooterSection() {
  return (
    <footer className="py-16 px-4 bg-gray-50">
      <div className="max-w-[800px] mx-auto text-center">
        <a href="#"><img src="/images/sintec-logo.jpg" alt="SINTEC" className="h-14 w-auto mx-auto mb-4" /></a>
        <h2 className="font-oswald font-bold text-2xl lg:text-3xl text-black mb-2">СТРУКТУРА ОТДЕЛА ПРОДАЖ</h2>
        <p className="text-sm text-gray-500 mb-8">Единая команда профессионалов, работающих на результат</p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8 text-sm text-gray-500">
          <span>&#x1F4DE; +7 (495) 123-45-67</span>
          <span>&#x2709; b2b@sintec.ru</span>
          <span>&#x1F4CD; Москва, Россия</span>
        </div>
        <div className="flex items-center justify-center gap-3 mb-8">
          {['VK', 'Telegram', 'LinkedIn'].map((s) => (
            <a key={s} href="#" className="px-4 py-2 border border-gray-300 text-gray-500 text-xs hover:bg-red-600 hover:text-white hover:border-red-600 transition-all">{s}</a>
          ))}
        </div>
        <div className="h-px w-full bg-gray-200 mb-6" />
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-gray-400">
          <p>&copy; {new Date().getFullYear()} SINTEC. Все права защищены.</p>
          <p>Стратегия продаж B2B Excellence</p>
        </div>
      </div>
    </footer>
  );
}
