const trainers = [
  {
    num: '01',
    emoji: '\u{1F465}',
    title: 'Тренер по управлению\nи продажам',
    subtitle: '3 человека на страну',
    color: '#CC0000',
    details: [
      '3 тренера покрывают всю страну — каждый закреплён за своим регионом',
      'Проводит обучение территориальных менеджеров: управление командой, постановка целей, контроль',
      'Тренинги по техникам продаж: переговоры, возражения, закрытие сделки',
      'Развивает лидерские компетенции: мотивация подчинённых, разрешение конфликтов',
      'Совместные выезды на поле с ТМ — аудит качества работы на территории',
      'EasyMerch — обратная связь после каждого совместного посещения рынка',
    ],
  },
  {
    num: '02',
    emoji: '\u{1F4D6}',
    title: 'Тренер по продукту',
    subtitle: '1 человек в офисе',
    color: '#8B3A00',
    details: [
      '1 тренер в центральном офисе — эксперт по всему продуктовому портфелю SINTEC',
      'Разрабатывает обучающие курсы: характеристики, применимость, преимущества перед конкурентами',
      'Создаёт тесты после каждого курса — проверка усвоения материала',
      'Обучает техническим параметрам: вязкость, допуски, совместимость с автопроизводителями',
      'Знание всех брендов: SINTEC, TAKAYAMA, MIRAX, ROLF, Автокосметика SINTEC',
      'Курсы заточены на результат — после обучения ТП может продать любой продукт',
    ],
  },
  {
    num: '03',
    emoji: '\u{1F916}',
    title: 'AI тренажёр',
    subtitle: 'Регулярное обучение 24/7',
    color: '#005f7f',
    details: [
      'AI-система симулирует сложные переговоры с торговыми точками',
      'Сценарии возражений: "дорого", "у конкурента дешевле", "не нужно" — отрабатывает ответы',
      'Различные сложности на рынке: работа с недовольным клиентом, восстановление отношений',
      'Тренинги по техникам продаж: SPIN, SNAP, Challenger Sale — практика в реальном времени',
      'После каждой сессии — разбор ошибок и рекомендации по улучшению',
      'Доступен 24/7 — каждый сотрудник может тренироваться в любое время',
    ],
  },
];

export default function TrainersSection() {
  return (
    <section className="py-16 px-4 bg-white">
      <div className="max-w-[900px] mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 border border-red-200 bg-red-50">
            <span className="text-xs font-medium text-red-600 uppercase tracking-widest">&#x1F393; Обучение</span>
          </div>
          <h2 className="font-oswald font-bold text-3xl lg:text-4xl text-black mb-2">ОТДЕЛ ОБУЧЕНИЯ</h2>
          <p className="text-sm text-gray-500 max-w-md mx-auto">Тренеры и AI-тренажёр для развития команды продаж</p>
        </div>

        <div className="space-y-3">
          {trainers.map((t, i) => (
            <details key={i} className="group border border-gray-200 bg-gray-50 cursor-pointer">
              <summary className="flex items-center gap-3 p-4 list-none">
                <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center font-oswald font-bold text-white text-sm" style={{ backgroundColor: t.color }}>
                  {t.num}
                </div>
                <span className="text-2xl flex-shrink-0">{t.emoji}</span>
                <div className="flex-1">
                  <h3 className="font-oswald font-bold text-base text-black uppercase whitespace-pre-line leading-tight">{t.title}</h3>
                  <span className="text-xs text-gray-400">{t.subtitle}</span>
                </div>
                <span className="text-gray-400 group-open:rotate-180 transition-transform text-sm">&#x25BC;</span>
              </summary>
              <div className="px-4 pb-4">
                <div className="h-px w-full bg-gray-200 mb-3 ml-16" />
                <ul className="space-y-2 ml-16">
                  {t.details.map((d, j) => (
                    <li key={j} className="flex items-start gap-2 text-sm text-gray-600">
                      <span style={{ color: t.color }}>&#x2714;</span>
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </details>
          ))}
        </div>

        <div className="mt-8 text-center">
          <div className="inline-flex items-center gap-3 px-6 py-3 border border-red-100 bg-red-50">
            <span className="text-sm text-gray-600">Все программы <span className="font-semibold text-red-600">заточены на результат</span></span>
          </div>
        </div>
      </div>
    </section>
  );
}
