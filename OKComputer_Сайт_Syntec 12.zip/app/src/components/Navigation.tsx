const items = [
  { label: 'B2C', href: '#b2c' },
  { label: 'B2B', href: '#b2b' },
  { label: 'СТО', href: '#sto' },
  { label: 'Онлайн', href: '#online' },
  { label: 'Сети', href: '#networks' },
  { label: 'Экспорт', href: '#export' },
  { label: 'Дистрибьюторы', href: '#distributors' },
  { label: 'Бренды', href: '#brands' },
];

export default function Navigation() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 border-b border-gray-200/50">
      <div className="max-w-[1400px] mx-auto px-4 lg:px-8">
        <div className="flex items-center justify-between h-14 lg:h-16">
          <a href="#" className="flex items-center gap-2">
            <img src="/images/sintec-logo.jpg" alt="SINTEC" className="h-7 w-auto" />
            <span className="font-oswald text-sm font-bold tracking-wider hidden sm:block">СТРУКТУРА ПРОДАЖ</span>
          </a>
          <div className="hidden lg:flex items-center gap-0.5">
            {items.map((item) => (
              <a key={item.href} href={item.href} className="px-2 py-1.5 text-xs font-medium text-gray-500 hover:text-black hover:bg-gray-100 transition-all uppercase">{item.label}</a>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
}
