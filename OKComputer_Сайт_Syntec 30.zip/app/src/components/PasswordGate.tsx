import { useState, useEffect } from 'react';

const VALID_PASSWORDS = ['7771', '7773', '0334'];
const STORAGE_KEY_AUTH = 'sintec_auth';
const STORAGE_KEY_DEVICE = 'sintec_device_fp';
const STORAGE_KEY_PASSWORD = 'sintec_used_password';

/* Генерируем отпечаток устройства по доступным характеристикам */
function getDeviceFingerprint(): string {
  const parts = [
    navigator.userAgent,
    screen.width + 'x' + screen.height,
    screen.colorDepth.toString(),
    navigator.language,
    Intl.DateTimeFormat().resolvedOptions().timeZone,
    navigator.hardwareConcurrency?.toString() || '',
    navigator.platform,
  ];
  let hash = 0;
  const str = parts.join('|');
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0;
  }
  return 'fp_' + Math.abs(hash).toString(16);
}

export default function PasswordGate({ children }: { children: React.ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [shake, setShake] = useState(false);
  const [warningMessage, setWarningMessage] = useState('');

  useEffect(() => {
    const storedAuth = localStorage.getItem(STORAGE_KEY_AUTH);
    const storedFp = localStorage.getItem(STORAGE_KEY_DEVICE);
    const currentFp = getDeviceFingerprint();

    if (storedAuth === '1' && storedFp === currentFp) {
      setIsAuthenticated(true);
    } else if (storedAuth === '1' && storedFp && storedFp !== currentFp) {
      /* Аутентификация есть, но с другого устройства — сбрасываем */
      localStorage.removeItem(STORAGE_KEY_AUTH);
      localStorage.removeItem(STORAGE_KEY_DEVICE);
      localStorage.removeItem(STORAGE_KEY_PASSWORD);
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setWarningMessage('');

    if (!VALID_PASSWORDS.includes(password)) {
      setError('Неверный пароль. Попробуйте снова.');
      setShake(true);
      setTimeout(() => setShake(false), 400);
      setPassword('');
      return;
    }

    const currentFp = getDeviceFingerprint();
    const storedFp = localStorage.getItem(STORAGE_KEY_DEVICE);
    const storedPassword = localStorage.getItem(STORAGE_KEY_PASSWORD);

    /* Пароль уже привязан к другому устройству */
    if (storedFp && storedPassword === password && storedFp !== currentFp) {
      setWarningMessage(
        'Информация конфиденциальна и не подлежит передаче другим лицам без подтверждения администратора'
      );
      setShake(true);
      setTimeout(() => setShake(false), 400);
      setPassword('');
      return;
    }

    /* Успешный вход — сохраняем привязку устройства к паролю */
    localStorage.setItem(STORAGE_KEY_AUTH, '1');
    localStorage.setItem(STORAGE_KEY_DEVICE, currentFp);
    localStorage.setItem(STORAGE_KEY_PASSWORD, password);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    /* При выходе удаляем ТОЛЬКО флаг авторизации.
       Привязка пароля к устройству сохраняется.
       Разблокировать пароль можно только через кабинет администратора. */
    localStorage.removeItem(STORAGE_KEY_AUTH);
    setIsAuthenticated(false);
    setPassword('');
    setError('');
    setWarningMessage('');
  };

  if (isAuthenticated) {
    return (
      <>
        {children}
        {/* Logout button - fixed bottom right */}
        <button
          onClick={handleLogout}
          className="fixed bottom-4 right-4 z-[9999] px-3 py-1.5 bg-gray-800/80 text-white text-[10px] font-bold uppercase tracking-wider hover:bg-red-600 transition-colors"
          title="Выйти из системы"
        >
          &#x2715; ВЫХОД
        </button>
      </>
    );
  }

  return (
    <div className="fixed inset-0 z-[10000] bg-black flex items-center justify-center">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5" style={{
        backgroundImage: `repeating-linear-gradient(45deg, #CC0000 0, #CC0000 1px, transparent 0, transparent 50%)`,
        backgroundSize: '20px 20px'
      }} />

      <div className={`relative w-full max-w-sm mx-4 ${shake ? 'animate-shake' : ''}`}>
        {/* Card */}
        <div className="bg-white p-8 shadow-2xl">
          {/* Logo area */}
          <div className="text-center mb-6">
            <div className="inline-block px-4 py-1.5 border border-red-200 bg-red-50 mb-4">
              <span className="text-xs font-medium text-red-600 uppercase tracking-widest">SINTEC 2027</span>
            </div>
            <h1 className="font-oswald font-bold text-2xl text-black uppercase tracking-wide">
              СТРАТЕГИЧЕСКИЙ ПОРТАЛ
            </h1>
            <p className="text-xs text-gray-400 mt-2">
              Доступ ограничен. Введите пароль.
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <input
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError('');
                  setWarningMessage('');
                }}
                placeholder="Введите пароль"
                maxLength={10}
                className="w-full px-4 py-3 border border-gray-300 text-center text-lg font-mono tracking-[0.3em] text-black placeholder:text-gray-300 placeholder:tracking-normal placeholder:text-sm focus:outline-none focus:border-red-600 transition-colors"
                autoFocus
              />
            </div>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 text-xs text-red-600 text-center">
                {error}
              </div>
            )}

            {warningMessage && (
              <div className="p-4 bg-yellow-50 border-2 border-yellow-400 text-center">
                <div className="text-lg mb-1">&#x26A0;&#xFE0F;</div>
                <p className="text-xs text-yellow-800 font-medium leading-relaxed">
                  {warningMessage}
                </p>
                <p className="text-[10px] text-yellow-600 mt-2">
                  Этот пароль уже используется на другом устройстве
                </p>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3 bg-red-600 text-white font-oswald font-bold text-sm uppercase tracking-wider hover:bg-red-700 transition-colors"
            >
              ВОЙТИ
            </button>
          </form>

          {/* Hint */}
          <div className="mt-6 pt-4 border-t border-gray-100 text-center">
            <p className="text-[10px] text-gray-400">
              Если у вас нет пароля — обратитесь к администратору
            </p>
          </div>
        </div>

        {/* Red accent bar */}
        <div className="h-1 bg-red-600" />
      </div>

      {/* Shake animation */}
      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-8px); }
          50% { transform: translateX(8px); }
          75% { transform: translateX(-4px); }
        }
        .animate-shake {
          animation: shake 0.35s ease-in-out;
        }
      `}</style>
    </div>
  );
}
