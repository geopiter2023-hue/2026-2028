import DepartmentCard from '../components/DepartmentCard';
export default function NetworksSection() { return <DepartmentCard id="networks" title="Сети" director="Директор по Сетям Россия" accentColor="#6b238f" icon={<span className="text-xl">&#x1F4E1;</span>} index={4} roles={[{ title: 'Менеджеры по сетям', count: 5, subtitle: 'Офис' }]} />; }
