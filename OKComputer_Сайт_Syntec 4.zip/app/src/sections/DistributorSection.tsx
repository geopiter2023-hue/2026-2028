const modules = [
  {
    num: '01',
    emoji: '\u{1F4E6}',
    title: 'Поддержка ассортимента',
    color: '#1a2744',
    details: [
      'Контроль наличия всех брендов SINTEC на складе дистрибьютора: SINTEC, TAKAYAMA, MIRAX, ROLF, Автокосметика SINTEC',
      'Анализ оборачиваемости SKU: выявление «залежавшихся» позиций и формирование рекомендаций по ассортименту',
      'Планограмма размещения: рекомендации по оптимальному размещению товаров на складе дистрибьютора',
      'Прогноз пополнения: система автоматически рассчитывает потребность в пополнении на основе продаж',
      'Синхронизация через API: остатки на складе дистрибьютора обновляются в реальном времени',
    ],
  },
  {
    num: '02',
    emoji: '\u{1F465}',
    title: 'Развитие команды дистрибьютора',
    color: '#243352',
    details: [
      'Совместные выезды на торговые точки: BDM SINTEC едет в поле с торговыми представителями дистрибьютора',
      'Обучающие собрания для сотрудников дистрибьютора: продуктовые презентации, техники продаж, работа с возражениями',
      'Аудит качества работы: проверка визитов, отчётности, мерчендайзинга — обратная связь через EasyMerch',
      'Менторство BDM: каждый BDM закреплён за своими ТП дистрибьютора — регулярные созвоны и разбор кейсов',
      'Мотивационные программы: совместные акции, конкурсы, бонусные схемы для команды дистрибьютора',
    ],
  },
  {
    num: '03',
    emoji: '\u{1F3AF}',
    title: 'Аудиты рынка & Новые точки',
    color: '#2e3f62',
    details: [
      'Аудит рынка в зоне ответственности дистрибьютора: обход точек, сбор данных, фотоотчёты, анализ конкурентов',
      'Поиск новых торговых точек: BDM идентифицирует потенциальных клиентов и передаёт дистрибьютору для подключения',
      'Развитие существующих точек: план расширения ассортимента, увеличение доли полки, запуск акций',
      'Поиск новых возможностей: мониторинг тендеров, крупных сетей, строительных проектов в регионе дистрибьютора',
      'Отчёт по результатам аудита: автоматическая генерация отчёта с рекомендациями для дистрибьютора',
    ],
  },
  {
    num: '04',
    emoji: '\u{1F504}',
    title: 'Взаимодействие клиент–дистрибьютор',
    color: '#384d72',
    details: [
      'Решение вопросов «клиент–дистрибьютор»: BDM SINTEC выступает связующим звеном между торговой точкой и дистрибьютором',
      'Передача данных по клиентам: BDM передаёт дистрибьютору информацию о новых точках, заказах и потребностях рынка',
      'Определение зон продаж дистрибьютора: чёткие границы территории с картой и списком закреплённых точек',
      'Контроль обслуживания: мониторинг сроков доставки, качества сервиса, реакции на заказы дистрибьютора',
      'Разрешение конфликтов: BDM помогает решать спорные ситуации между клиентом и дистрибьютором',
    ],
  },
  {
    num: '05',
    emoji: '\u{2B50}',
    title: 'Сегментация точек',
    color: '#425b82',
    details: [
      'Платинум: крупнейшие точки с максимальным потенциалом — на прямом обслуживании ТП SINTEC с полным пакетом услуг',
      'Голд: перспективные точки с высоким объёмом — на прямом обслуживании ТП SINTEC с регулярным развитием',
      'Сильвер: стабильные точки среднего потенциала — обслуживаются ТП дистрибьютора с контролем со стороны BDM',
      'Бронза: базовые точки с минимальным потенциалом — обслуживаются ТП дистрибьютора, поддержка через BDM при необходимости',
      'Пересегментация ежеквартально: точки могут переходить между категориями на основе динамики продаж',
    ],
  },
  {
    num: '06',
    emoji: '\u{1F4CB}',
    title: 'Маркетинговые материалы',
    color: '#4c6992',
    details: [
      'Контроль заказов маркетинговых материалов: BDM помогает дистрибьютору правильно сформировать заявку на POS-материалы',
      'Эффективное использование: анализ какие материалы работают лучше в конкретном регионе — фокус на результат',
      'Библиотека материалов: каталоги, стенды, ценники, дисплеи, пробники — доступ к актуальным промо-материалам',
      'Маркетинговый календарь: план промо-активностей на квартал — BDM доводит до дистрибьютора и контролирует выполнение',
      'Отчёт по использованию: процент магазинов с актуальными POS-материалами — KPI BDM',
    ],
  },
  {
    num: '07',
    emoji: '\u{1F3C6}',
    title: 'KPI BDM',
    color: '#5678a2',
    details: [
      'Подключение клиентов к Бонус Клубу: основной KPI — каждый BDM имеет план по подключению новых точек к программе лояльности',
      'Формирование заказа и отправка дистрибьютору: BDM мотивирует точку сформировать заказ и передать его дистрибьютору',
      'Рост выручки по ведомым магазинам: ежемесячный прирост продаж через дистрибьютора не менее 10%',
      'Количество новых подключённых точек в месяц: план по привлечению новых торговых точек через дистрибьютора',
      'Активность Бонус Клуба: процент точек, регулярно использующих программу лояльности — целевой показатель 80%+',
    ],
  },
];

export default function DistributorSection() {
  return (
    <section id="distributors" className="py-16 px-4 bg-gray-50">
      <div className="max-w-[900px] mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 border border-blue-200 bg-blue-50">
            <span className="text-xs font-medium text-blue-800 uppercase tracking-widest">&#x1F69B; Дистрибьюторы</span>
          </div>
          <h2 className="font-oswald font-bold text-3xl lg:text-4xl text-black mb-2">ДИСТРИБЬЮТОРЫ</h2>
          <p className="text-sm text-gray-500 max-w-lg mx-auto mb-2">Развитие дистрибьюторской сети через BDM</p>
          <p className="text-sm text-gray-400">Поддержка ассортимента, обучение команд, аудиты рынка, открытие новых точек</p>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-8 max-w-[600px] mx-auto">
          {[
            { val: '55', label: 'Сотрудников отдела', color: '#1a2744' },
            { val: '5', label: 'Региональных менеджеров', color: '#243352' },
            { val: '50', label: 'BDM на поле', color: '#1a2744' },
            { val: 'BC', label: 'Бонус Клуб — KPI', color: '#243352' },
          ].map((s, i) => (
            <div key={i} className="p-3 border border-gray-200 bg-white text-center">
              <span className="font-oswald font-bold text-2xl" style={{ color: s.color }}>{s.val}</span>
              <p className="text-[10px] text-gray-400 uppercase tracking-wider mt-1">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="h-px w-full bg-blue-200 mb-6" />

        {/* Team */}
        <div className="flex items-center gap-3 mb-6 p-3 border border-gray-200 bg-white max-w-[500px] mx-auto">
          <span className="text-2xl">&#x1F69B;</span>
          <div>
            <h3 className="font-oswald font-bold text-sm text-black uppercase">ОТДЕЛ ПО ДИСТРИБЬЮТОРАМ</h3>
            <p className="text-xs text-gray-400">Директор по дистрибьюторам</p>
          </div>
          <div className="ml-auto text-right">
            <span className="font-oswald font-bold text-xl text-blue-900">55</span>
            <p className="text-[10px] text-gray-400 uppercase">человек</p>
          </div>
        </div>

        {/* Team structure pills */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {[
            { label: 'Региональные менеджеры', count: '5' },
            { label: 'BDM (торговые дистрибьютеры)', count: '50' },
          ].map((r, i) => (
            <div key={i} className="flex items-center gap-2 px-4 py-2 border border-gray-200 bg-white">
              <span className="font-oswald font-bold text-sm text-blue-900">{r.count}</span>
              <span className="text-xs text-gray-500">{r.label}</span>
            </div>
          ))}
        </div>

        {/* Modules accordion */}
        <div className="space-y-3">
          {modules.map((m, i) => (
            <details key={i} className="group border border-gray-200 bg-white cursor-pointer">
              <summary className="flex items-center gap-3 p-4 list-none">
                <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center font-oswald font-bold text-white text-sm" style={{ backgroundColor: m.color }}>
                  {m.num}
                </div>
                <span className="text-2xl flex-shrink-0">{m.emoji}</span>
                <h3 className="font-oswald font-bold text-base text-black uppercase flex-1">{m.title}</h3>
                <span className="text-gray-400 group-open:rotate-180 transition-transform text-sm">&#x25BC;</span>
              </summary>
              <div className="px-4 pb-4">
                <div className="h-px w-full bg-gray-200 mb-3 ml-16" />
                <ul className="space-y-2 ml-16">
                  {m.details.map((d, j) => (
                    <li key={j} className="flex items-start gap-2 text-sm text-gray-600">
                      <span style={{ color: m.color }}>&#x2714;</span>
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </details>
          ))}
        </div>

        {/* Bottom principle */}
        <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg text-center">
          <p className="text-sm text-gray-700">
            <span className="font-semibold text-blue-900">Принцип:</span> Платинум &amp; Голд → ТП SINTEC &nbsp;|&nbsp; Сильвер &amp; Бронза → ТП дистрибьютора &nbsp;|&nbsp; Основной KPI BDM — Бонус Клуб + заказ дистрибьютору
          </p>
        </div>
      </div>
    </section>
  );
}
