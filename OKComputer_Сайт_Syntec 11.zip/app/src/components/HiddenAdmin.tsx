import { useState, useEffect, useCallback } from 'react';

interface Session {
  id: string;
  userAgent: string;
  device: string;
  screen: string;
  ip: string;
  city: string;
  country: string;
  isp: string;
  entryTime: string;
  exitTime: string | null;
  duration: string;
}

function detectDevice(ua: string): string {
  if (/iPhone|iPod/.test(ua)) return 'iPhone';
  if (/iPad/.test(ua)) return 'iPad';
  if (/Android.*Mobile/.test(ua)) return 'Android Phone';
  if (/Android/.test(ua)) return 'Android Tablet';
  if (/Windows Phone/.test(ua)) return 'Windows Phone';
  if (/Macintosh|Mac OS/.test(ua)) return 'Mac';
  if (/Windows/.test(ua)) return 'Windows PC';
  if (/Linux/.test(ua)) return 'Linux';
  return 'Other';
}

function formatDuration(ms: number): string {
  if (ms < 0) return '—';
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  if (h > 0) return `${h}ч ${m % 60}м ${s % 60}с`;
  if (m > 0) return `${m}м ${s % 60}с`;
  return `${s}с`;
}

/* --- Geo lookup with multiple fallbacks --- */
async function fetchGeo(): Promise<{ ip: string; city: string; country: string; isp: string }> {
  const fallback = { ip: '—', city: '—', country: '—', isp: '—' };

  // Try 1: ipapi.co
  try {
    const res = await fetch('https://ipapi.co/json/', { signal: AbortSignal.timeout(4000) });
    if (res.ok) {
      const d = await res.json();
      return {
        ip: d.ip || '—',
        city: d.city || '—',
        country: d.country_name || d.country || '—',
        isp: d.org || d.asn || '—',
      };
    }
  } catch { /* empty */ }

  // Try 2: ip-api.com (no HTTPS, but works on HTTP sites)
  try {
    const res = await fetch('http://ip-api.com/json/?fields=status,query,city,country,isp', { signal: AbortSignal.timeout(4000) });
    if (res.ok) {
      const d = await res.json();
      if (d.status === 'success') {
        return { ip: d.query || '—', city: d.city || '—', country: d.country || '—', isp: d.isp || '—' };
      }
    }
  } catch { /* empty */ }

  // Try 3: ipify for IP only
  try {
    const res = await fetch('https://api64.ipify.org?format=json', { signal: AbortSignal.timeout(3000) });
    if (res.ok) {
      const d = await res.json();
      return { ...fallback, ip: d.ip || '—' };
    }
  } catch { /* empty */ }

  return fallback;
}

/* --- Session tracking --- */
export async function trackSession() {
  const STORAGE_KEY = 'sintec_analytics';
  const SESSION_KEY = 'sintec_current_session';
  const sessionId = Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
  const startTime = Date.now();

  // Check if there's already an active session from this visit (page refresh)
  const existingSessionId = sessionStorage.getItem(SESSION_KEY);
  if (existingSessionId) {
    // Close the existing session first
    const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    const existing = all.find((s: Session) => s.id === existingSessionId);
    if (existing && !existing.exitTime) {
      existing.exitTime = new Date().toISOString();
      existing.duration = formatDuration(Date.now() - new Date(existing.entryTime).getTime());
      localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
    }
  }
  sessionStorage.setItem(SESSION_KEY, sessionId);

  // Fetch geo data
  const geo = await fetchGeo();

  // Save new session
  const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  all.push({
    id: sessionId,
    userAgent: navigator.userAgent,
    device: detectDevice(navigator.userAgent),
    screen: `${window.screen.width}x${window.screen.height}`,
    ip: geo.ip,
    city: geo.city,
    country: geo.country,
    isp: geo.isp,
    entryTime: new Date().toISOString(),
    exitTime: null,
    duration: null,
  });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(all));

  // Heartbeat: update duration every 5 seconds for live sessions
  const heartbeat = setInterval(() => {
    const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    const s = data.find((x: Session) => x.id === sessionId);
    if (s && !s.exitTime) {
      s.duration = formatDuration(Date.now() - new Date(s.entryTime).getTime());
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    }
  }, 5000);

  // Close session on visibility change (tab switch, app background)
  const handleVisibility = () => {
    if (document.visibilityState === 'hidden') {
      const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
      const s = data.find((x: Session) => x.id === sessionId);
      if (s && !s.exitTime) {
        s.exitTime = new Date().toISOString();
        s.duration = formatDuration(Date.now() - startTime);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      }
      clearInterval(heartbeat);
    }
  };
  document.addEventListener('visibilitychange', handleVisibility);

  // Also try beacon on page unload
  window.addEventListener('beforeunload', () => {
    clearInterval(heartbeat);
    const payload = JSON.stringify({
      id: sessionId,
      exitTime: new Date().toISOString(),
      duration: formatDuration(Date.now() - startTime),
    });
    navigator.sendBeacon?.('data:text/plain,' + encodeURIComponent(payload));

    // Also try direct update
    try {
      const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
      const s = data.find((x: Session) => x.id === sessionId);
      if (s && !s.exitTime) {
        s.exitTime = new Date().toISOString();
        s.duration = formatDuration(Date.now() - startTime);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      }
    } catch { /* empty */ }
  });
}

export default function HiddenAdmin() {
  const [showLogin, setShowLogin] = useState(false);
  const [password, setPassword] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [sessions, setSessions] = useState<Session[]>([]);

  const loadData = useCallback(() => {
    const data = JSON.parse(localStorage.getItem('sintec_analytics') || '[]');
    const now = Date.now();
    data.forEach((s: Session) => {
      if (!s.exitTime && s.entryTime) {
        const elapsed = now - new Date(s.entryTime).getTime();
        s.duration = formatDuration(elapsed);
      }
    });
    setSessions(data.reverse());
  }, []);

  useEffect(() => {
    if (isAuthenticated) loadData();
  }, [isAuthenticated, loadData]);

  useEffect(() => {
    const interval = setInterval(() => {
      if (isAuthenticated) loadData();
    }, 5000);
    return () => clearInterval(interval);
  }, [isAuthenticated, loadData]);

  const handleLogin = () => {
    if (password === '1987') {
      setIsAuthenticated(true);
      setShowLogin(false);
      loadData();
    } else {
      setPassword('');
    }
  };

  const clearData = () => {
    if (window.confirm('Удалить все данные аналитики?')) {
      localStorage.removeItem('sintec_analytics');
      sessionStorage.removeItem('sintec_current_session');
      setSessions([]);
    }
  };

  const handleClose = () => {
    setIsAuthenticated(false);
    setPassword('');
  };

  if (isAuthenticated) {
    return (
      <div className="fixed inset-0 z-[9999] bg-black/80 flex items-start justify-center overflow-y-auto py-8">
        <div className="bg-white w-full max-w-[1000px] mx-4 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-oswald font-bold text-2xl text-black uppercase">&#x1F4E1; Аналитика посещений</h2>
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-400">{sessions.length} сессий</span>
              <button onClick={loadData} className="px-3 py-1 bg-blue-900 text-white text-xs font-medium">Обновить</button>
              <button onClick={clearData} className="px-3 py-1 bg-red-600 text-white text-xs font-medium">Очистить</button>
              <button onClick={handleClose} className="px-3 py-1 bg-gray-200 text-black text-xs font-medium">Закрыть</button>
            </div>
          </div>

          {sessions.length === 0 ? (
            <p className="text-gray-400 text-center py-8">Пока нет данных о посещениях</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="p-2 text-left font-medium text-gray-500">#</th>
                    <th className="p-2 text-left font-medium text-gray-500">IP</th>
                    <th className="p-2 text-left font-medium text-gray-500">Локация</th>
                    <th className="p-2 text-left font-medium text-gray-500">Провайдер</th>
                    <th className="p-2 text-left font-medium text-gray-500">Устройство</th>
                    <th className="p-2 text-left font-medium text-gray-500">Экран</th>
                    <th className="p-2 text-left font-medium text-gray-500">Вход</th>
                    <th className="p-2 text-left font-medium text-gray-500">Выход</th>
                    <th className="p-2 text-left font-medium text-gray-500">Время</th>
                  </tr>
                </thead>
                <tbody>
                  {sessions.map((s, i) => (
                    <tr key={s.id} className="border-t border-gray-100">
                      <td className="p-2 text-gray-400">{sessions.length - i}</td>
                      <td className="p-2">
                        <span className="px-2 py-0.5 bg-gray-100 text-gray-700 font-mono text-[10px]">{s.ip}</span>
                      </td>
                      <td className="p-2">
                        <span className="text-blue-700 font-medium">{s.city}</span>
                        <span className="text-gray-400">, {s.country}</span>
                      </td>
                      <td className="p-2 text-gray-500 max-w-[120px] truncate" title={s.isp}>{s.isp}</td>
                      <td className="p-2">
                        <span className="px-2 py-0.5 bg-blue-50 text-blue-800 font-medium">{s.device}</span>
                      </td>
                      <td className="p-2 text-gray-600">{s.screen}</td>
                      <td className="p-2 text-gray-600">{new Date(s.entryTime).toLocaleTimeString('ru-RU')}</td>
                      <td className="p-2 text-gray-600">{s.exitTime ? new Date(s.exitTime).toLocaleTimeString('ru-RU') : 'Онлайн'}</td>
                      <td className="p-2">
                        <span className={!s.exitTime ? 'text-green-600 font-medium' : 'text-gray-600'}>{s.duration}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <>
      <button
        onClick={() => setShowLogin(true)}
        className="fixed bottom-4 right-4 w-10 h-10 bg-gray-800 hover:bg-red-600 text-white rounded-full flex items-center justify-center shadow-lg z-[9998] transition-all duration-300 hover:scale-110"
        title="Админ-панель"
      >
        <span className="text-sm">&#x2699;</span>
      </button>

      {showLogin && (
        <div className="fixed inset-0 z-[9999] bg-black/60 flex items-center justify-center">
          <div className="bg-white p-6 w-[280px]">
            <h3 className="font-oswald font-bold text-lg text-black uppercase mb-4 text-center">&#x1F510; Вход</h3>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
              placeholder="Пароль"
              className="w-full p-2 border border-gray-300 text-sm mb-4 focus:outline-none focus:border-red-500"
              autoFocus
            />
            <div className="flex gap-2">
              <button onClick={handleLogin} className="flex-1 p-2 bg-red-600 text-white text-sm font-medium">Войти</button>
              <button onClick={() => { setShowLogin(false); setPassword(''); }} className="flex-1 p-2 bg-gray-200 text-black text-sm">Отмена</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
